import { useEffect, useState } from "react";

type ApiStatus = "checking" | "online" | "offline";
type DerivAccount = { account_id: string; environment: "DEMO" | "REAL"; external_ref: string; currency: string | null; status: string };
type BalanceView = { balance: number; currency: string; capturedAt: string };

const API_BASE = import.meta.env.VITE_API_BASE_URL ?? "http://localhost:8080";

export function App() {
  const [apiStatus, setApiStatus] = useState<ApiStatus>("checking");
  const [accounts, setAccounts] = useState<DerivAccount[]>([]);
  const [derivMessage, setDerivMessage] = useState("Deriv account not connected");
  const [connecting, setConnecting] = useState(false);
  const [balances, setBalances] = useState<Record<string, BalanceView>>({});
  const [balanceLoading, setBalanceLoading] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    fetch(`${API_BASE}/health`)
      .then((response) => {
        if (!response.ok) throw new Error("API health check failed");
        return response.json();
      })
      .then(() => active && setApiStatus("online"))
      .catch(() => active && setApiStatus("offline"));
    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    fetch(`${API_BASE}/api/v1/deriv/connection`, { credentials: "include" })
      .then((response) => response.ok ? response.json() : { connected: false })
      .then((result) => { if (result.connected) void loadAccounts(); })
      .catch(() => undefined);
  }, []);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get("deriv") === "connected") {
      window.history.replaceState({}, "", window.location.pathname);
      void loadAccounts();
    }
  }, []);

  async function loadAccounts() {
    try {
      const response = await fetch(`${API_BASE}/api/v1/deriv/accounts`, { credentials: "include" });
      if (!response.ok) throw new Error("Could not retrieve authorized accounts");
      const result = await response.json();
      setAccounts(result.accounts ?? []);
      setDerivMessage(`Connected · ${result.accounts?.length ?? 0} account(s) discovered`);
    } catch {
      setDerivMessage("Account discovery unavailable. Check OAuth connection and API logs.");
    }
  }

  async function loadBalance(account: DerivAccount) {
    setBalanceLoading(account.account_id);
    try {
      const response = await fetch(`${API_BASE}/api/v1/deriv/accounts/${account.account_id}/balance?environment=${account.environment}`, { credentials: "include" });
      if (!response.ok) throw new Error("Balance unavailable");
      const result = await response.json();
      setBalances((current) => ({ ...current, [account.account_id]: result }));
    } catch {
      setDerivMessage(`Could not retrieve ${account.environment} balance. Check account permissions and connection.`);
    } finally {
      setBalanceLoading(null);
    }
  }

  async function connectDeriv() {
    setConnecting(true);
    try {
      const response = await fetch(`${API_BASE}/api/v1/auth/deriv/start`, { credentials: "include" });
      if (!response.ok) throw new Error("Could not start Deriv OAuth");
      const result = await response.json();
      window.location.assign(result.authorizationUrl);
    } catch {
      setDerivMessage("Unable to start Deriv authorization. Check server OAuth configuration.");
      setConnecting(false);
    }
  }

  return (
    <main className="shell">
      <aside className="sidebar">
        <div className="brand"><span className="brand-mark">DQ</span><span>DERIV QUANT<br />INTELLIGENCE</span></div>
        <nav aria-label="Main navigation">
          {["Overview", "Markets", "Trading terminal", "AI signals", "Strategy lab", "Portfolio", "Risk centre", "Trade history", "Developer console"].map((item, index) => (
            <button className={index === 0 ? "nav-item active" : "nav-item"} key={item} type="button">
              <span className="nav-dot" />{item}
            </button>
          ))}
        </nav>
        <div className="sidebar-footer">PHASE 1 · FOUNDATION</div>
      </aside>

      <section className="content">
        <header className="topbar">
          <div><span className="eyebrow">QUANTITATIVE TRADING WORKSPACE</span><h1>Overview</h1></div>
          <div className="top-actions">
            <span className="mode-pill">DEMO-FIRST</span>
            <span className={`status ${apiStatus}`}>API {apiStatus}</span>
            <button className="connect-button" type="button" onClick={connectDeriv} disabled={connecting}>{connecting ? "Connecting…" : "Connect Deriv"}</button>
          </div>
        </header>

        <section className="notice">
          <strong>Research foundation only</strong>
          <span>Trading execution is disabled. No live account is connected and no market data is being represented as live.</span>
        </section>

        <section className="panel deriv-panel">
          <div className="panel-heading"><div><span className="eyebrow">BROKER CONNECTION</span><h2>Deriv accounts</h2></div><span className="tag">OAUTH · READ ONLY</span></div>
          <p className="deriv-message">{derivMessage}</p>
          {accounts.length > 0 && <div className="account-list">{accounts.map((account) => <div className="account-row" key={account.account_id}><span><b className={account.environment === "REAL" ? "real-label" : "demo-label"}>{account.environment}</b> {account.external_ref}</span><span>{balances[account.account_id] ? `${balances[account.account_id].balance.toLocaleString()} ${balances[account.account_id].currency}` : account.currency ?? "Balance not fetched"}</span><button type="button" className="balance-button" disabled={balanceLoading === account.account_id} onClick={() => void loadBalance(account)}>{balanceLoading === account.account_id ? "Loading…" : "Fetch balance"}</button></div>)}</div>}
        </section>

        <section className="metric-grid" aria-label="Account metrics">
          {[
            ["Account balance", "—", "Connect account in Phase 2"],
            ["Equity", "—", "Awaiting authorized account data"],
            ["Today's P/L", "—", "No trades recorded"],
            ["Open positions", "0", "Execution not enabled"]
          ].map(([label, value, detail]) => (
            <article className="metric-card" key={label}>
              <span className="muted">{label}</span>
              <strong>{value}</strong>
              <small>{detail}</small>
            </article>
          ))}
        </section>

        <section className="main-grid">
          <article className="panel chart-panel">
            <div className="panel-heading"><div><span className="eyebrow">MARKET WORKSPACE</span><h2>Market intelligence</h2></div><span className="tag">DATA NOT CONNECTED</span></div>
            <div className="empty-chart">
              <div className="chart-icon">⌁</div>
              <strong>Market feed awaits integration</strong>
              <p>Phase 2 will connect authorized Deriv market streams and historical data.</p>
            </div>
          </article>
          <article className="panel">
            <div className="panel-heading"><div><span className="eyebrow">CAPITAL PROTECTION</span><h2>Risk guardian</h2></div><span className="safe">SAFE</span></div>
            <div className="risk-state"><span className="shield">✓</span><div><strong>Execution locked</strong><p>Trading and live trading flags are false.</p></div></div>
            <div className="rule-row"><span>Demo execution</span><b>Disabled</b></div>
            <div className="rule-row"><span>Real execution</span><b>Disabled</b></div>
            <div className="rule-row"><span>Emergency stop</span><b>Armed by default</b></div>
          </article>
        </section>

        <section className="panel bottom-panel">
          <div className="panel-heading"><div><span className="eyebrow">SYSTEM FOUNDATION</span><h2>Service health</h2></div></div>
          <div className="service-grid">
            <div><span className="service-indicator" />Web application <b>Running</b></div>
            <div><span className="service-indicator" />API <b>{apiStatus}</b></div>
            <div><span className="service-indicator pending" />Quant service <b>See service health</b></div>
            <div><span className="service-indicator pending" />Database <b>See API readiness</b></div>
          </div>
        </section>
        <footer>DQI v0.1.0 · Phase 1 foundation · Not financial advice · No trade execution</footer>
      </section>
    </main>
  );
}
