from fastapi.testclient import TestClient
from app.main import app


def test_health_is_non_trading():
    response=TestClient(app).get('/health')
    assert response.status_code==200 and response.json()['trading_enabled'] is False


def test_quant_endpoints_require_admin_session():
    client=TestClient(app)
    assert client.get('/api/v1/quant/symbols').status_code==401
    assert client.post('/api/v1/quant/analyze',json={'symbol':'R_100','timeframe':'M5'}).status_code==401


def test_login_sets_httponly_cookie(monkeypatch):
    from app.security import hash_password
    monkeypatch.setenv('QUANT_ADMIN_PASSWORD_HASH',hash_password('Strong-Admin-Password-2026!'))
    monkeypatch.setenv('QUANT_SESSION_SECRET','s'*48)
    monkeypatch.setenv('QUANT_COOKIE_SECURE','false')
    client=TestClient(app)
    response=client.post('/api/v1/quant/auth/login',json={'password':'Strong-Admin-Password-2026!'})
    assert response.status_code==200
    assert 'httponly' in response.headers['set-cookie'].lower()
    assert client.get('/api/v1/quant/session').json()['authenticated'] is True


def test_login_is_rate_limited(monkeypatch):
    from app.main import LOGIN_ATTEMPTS
    from app.security import hash_password
    monkeypatch.setenv('QUANT_ADMIN_PASSWORD_HASH',hash_password('Strong-Admin-Password-2026!'))
    monkeypatch.setenv('QUANT_SESSION_SECRET','s'*48)
    LOGIN_ATTEMPTS.clear()
    client=TestClient(app)
    for _ in range(8):
        assert client.post('/api/v1/quant/auth/login',json={'password':'wrong'}).status_code==401
    assert client.post('/api/v1/quant/auth/login',json={'password':'wrong'}).status_code==429
    LOGIN_ATTEMPTS.clear()


def test_paper_endpoints_require_admin_session():
    client=TestClient(app)
    assert client.get('/api/v1/paper/account').status_code==401
    assert client.get('/api/v1/paper/positions').status_code==401
    assert client.get('/api/v1/paper/performance').status_code==401
    assert client.post('/api/v1/paper/trades',json={
        'symbol':'R_100','timeframe':'M5','direction':'BUY','stake':10
    }).status_code==401
