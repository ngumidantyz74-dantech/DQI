import asyncio
import pytest
from app.engine import deriv


def test_discover_symbols_uses_deriv_active_symbols(monkeypatch):
    async def fake_request(payload, timeout=15.0):
        assert payload == {"active_symbols": "full"}
        return {"active_symbols": [{"symbol": "R_100", "display_name": "Volatility 100 Index"}]}
    monkeypatch.setattr(deriv, "deriv_request", fake_request)
    result=asyncio.run(deriv.discover_symbols())
    assert result[0]["symbol"] == "R_100"


def test_fetch_candles_requests_deriv_ohlc(monkeypatch):
    async def fake_request(payload, timeout=15.0):
        assert payload["ticks_history"] == "R_100"
        assert payload["granularity"] == 300
        assert payload["style"] == "candles"
        return {"candles": [{"epoch": 1, "open": 1, "high": 2, "low": 1, "close": 2}]}
    monkeypatch.setattr(deriv, "deriv_request", fake_request)
    result=asyncio.run(deriv.fetch_candles("R_100",300,100))
    assert len(result)==1


def test_fetch_candles_rejects_unsupported_timeframe():
    with pytest.raises(ValueError): asyncio.run(deriv.fetch_candles("R_100",120,100))


def test_fetch_candles_rejects_invalid_symbol():
    with pytest.raises(ValueError): asyncio.run(deriv.fetch_candles("R-100",300,100))
