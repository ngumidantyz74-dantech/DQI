import pytest
from app.security import hash_password, verify_password, create_session, valid_session


def test_password_hash_and_verification():
    encoded=hash_password("Correct-Horse-Battery-2026!")
    assert verify_password("Correct-Horse-Battery-2026!",encoded)
    assert not verify_password("wrong",encoded)


def test_password_minimum_length():
    with pytest.raises(ValueError): hash_password("short")


def test_signed_session(monkeypatch):
    monkeypatch.setenv("QUANT_SESSION_SECRET","x"*48)
    token=create_session()
    assert valid_session(token)
    assert not valid_session(token+"tampered")
