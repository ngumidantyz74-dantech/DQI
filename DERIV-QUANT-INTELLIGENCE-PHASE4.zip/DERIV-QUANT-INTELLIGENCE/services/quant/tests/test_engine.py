import math
import pytest
from app.engine.indicators import sma, ema, rsi, bollinger
from app.engine.analysis import analyze_candles, calibrate_confidence, fit_platt_calibration, multi_timeframe
from app.engine.backtest import performance_metrics, run_backtest, walk_forward, BacktestConfig


def candles(n=240, drift=0.15):
    rows=[]; price=100.0
    for i in range(n):
        op=price; price += drift + math.sin(i/5)*0.12
        rows.append({"epoch":1700000000+i*60,"open":op,"high":max(op,price)+0.2,"low":min(op,price)-0.2,"close":price})
    return rows


def test_sma_ema_rsi_bollinger_shapes():
    values=[float(i) for i in range(1,31)]
    assert sma(values,3)[2] == 2.0
    assert ema(values,3)[2] == 2.0
    assert rsi(values,14)[-1] == 100.0
    assert bollinger(values,20)[-1]["upper"] > bollinger(values,20)[-1]["middle"]


def test_analysis_generates_valid_regime_and_direction():
    result=analyze_candles("R_100","M5",candles())
    assert result["direction"] in {"BUY","SELL","NEUTRAL"}
    assert result["regime"] in {"TREND_UP","TREND_DOWN","RANGE","HIGH_VOLATILITY","LOW_VOLATILITY_RANGE"}
    assert 0 <= result["raw_confidence"] <= 1


def test_multi_timeframe_consensus():
    data=candles()
    result=multi_timeframe("R_100",{"M5":data,"M15":data,"H1":data})
    assert set(result["timeframes"]) == {"M5","M15","H1"}


def test_confidence_calibration_is_bounded_and_monotonic():
    assert calibrate_confidence(0.8) > calibrate_confidence(0.6)
    assert 0 <= calibrate_confidence(0.7) <= 1
    with pytest.raises(ValueError): calibrate_confidence(1.2)


def test_performance_metrics_drawdown_and_win_rate():
    metrics=performance_metrics([100,110,90,120],[{"pnl":10},{"pnl":-20},{"pnl":30}])
    assert metrics["max_drawdown"] == pytest.approx(20/110)
    assert metrics["win_rate"] == pytest.approx(2/3, abs=1e-4)


def test_backtest_uses_next_bar_and_returns_metrics():
    result=run_backtest("R_100","M5",candles(),BacktestConfig())
    assert "total_return" in result["metrics"]
    assert result["disclaimer"].startswith("Hypothetical research")


def test_walk_forward_produces_out_of_sample_folds():
    result=walk_forward("R_100","M5",candles(800),train_size=400,test_size=100,step=100)
    assert result["fold_count"] >= 1
    assert "out_of_sample" in result["folds"][0]


def test_rejects_invalid_ohlc():
    data=candles(); data[-1]["high"]=-1
    with pytest.raises(ValueError): analyze_candles("R_100","M5",data)


def test_untrained_confidence_is_not_claimed_as_probability():
    assert calibrate_confidence(0.73) == 0.73

def test_platt_calibration_requires_both_classes_and_enough_samples():
    observations=[{"confidence":0.55 + (i%10)*0.03,"outcome":1 if i%3 else 0} for i in range(90)]
    fitted=fit_platt_calibration(observations)
    assert fitted["sample_count"]==90
    assert fitted["slope"]>0
    with pytest.raises(ValueError): fit_platt_calibration(observations[:10])
