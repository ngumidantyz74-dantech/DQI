import pytest
from app.engine.paper import PaperRiskPolicy, validate_paper_order, settle_directional_contract, summarize_paper_performance


def test_paper_order_respects_stake_and_daily_loss_limits():
    approved=validate_paper_order(equity=10000,available_balance=10000,stake=100,expiry_seconds=300,open_positions=0,daily_realized_pnl=0)
    assert approved['approved'] is True
    assert approved['risk_fraction']==0.01
    with pytest.raises(ValueError,match='2.0%'):
        validate_paper_order(equity=10000,available_balance=10000,stake=201,expiry_seconds=300,open_positions=0,daily_realized_pnl=0)
    with pytest.raises(ValueError,match='Daily loss limit'):
        validate_paper_order(equity=10000,available_balance=10000,stake=10,expiry_seconds=300,open_positions=0,daily_realized_pnl=-500)


def test_paper_order_enforces_open_position_and_expiry_limits():
    with pytest.raises(ValueError,match='Maximum number'):
        validate_paper_order(equity=10000,available_balance=10000,stake=10,expiry_seconds=300,open_positions=5,daily_realized_pnl=0)
    with pytest.raises(ValueError,match='Expiry'):
        validate_paper_order(equity=10000,available_balance=10000,stake=10,expiry_seconds=10,open_positions=0,daily_realized_pnl=0)


def test_directional_contract_win_and_loss_settlement():
    win=settle_directional_contract(direction='BUY',entry_price=100,exit_price=101,stake=10,payout_multiplier=.85)
    loss=settle_directional_contract(direction='SELL',entry_price=100,exit_price=101,stake=10,payout_multiplier=.85)
    assert win['status']=='WON' and win['profit_loss']==8.5
    assert loss['status']=='LOST' and loss['profit_loss']==-10
    assert win['model']=='FIXED_PAYOUT_DIRECTIONAL_RESEARCH_SIMULATION'


def test_paper_performance_metrics_ignore_open_positions():
    metrics=summarize_paper_performance([
        {'status':'WON','profit_loss':8.5},
        {'status':'LOST','profit_loss':-10},
        {'status':'OPEN','profit_loss':0},
    ],1000)
    assert metrics['closed_trades']==2
    assert metrics['open_trades']==1
    assert metrics['net_profit']==-1.5
    assert metrics['wins']==1 and metrics['losses']==1
    assert metrics['current_equity']==998.5
