from __future__ import annotations
import base64, hashlib, hmac, os, secrets, time
from fastapi import HTTPException, Request, Response

COOKIE_NAME="dqi_quant_session"
SESSION_TTL=int(os.getenv("QUANT_SESSION_TTL_SECONDS","28800"))


def hash_password(password: str, iterations: int=310000) -> str:
    if len(password)<14: raise ValueError("Admin password must contain at least 14 characters")
    salt=secrets.token_bytes(16)
    digest=hashlib.pbkdf2_hmac("sha256",password.encode(),salt,iterations)
    return f"pbkdf2_sha256${iterations}${base64.urlsafe_b64encode(salt).decode()}${base64.urlsafe_b64encode(digest).decode()}"


def verify_password(password: str, encoded: str) -> bool:
    try:
        algorithm,iterations,salt,digest=encoded.split("$",3)
        if algorithm!="pbkdf2_sha256": return False
        actual=hashlib.pbkdf2_hmac("sha256",password.encode(),base64.urlsafe_b64decode(salt),int(iterations))
        return hmac.compare_digest(actual,base64.urlsafe_b64decode(digest))
    except (ValueError,TypeError): return False


def _secret() -> bytes:
    value=os.getenv("QUANT_SESSION_SECRET","")
    if len(value)<32: raise RuntimeError("QUANT_SESSION_SECRET must contain at least 32 characters")
    return value.encode()


def _sign(payload: str) -> str:
    signature=hmac.new(_secret(),payload.encode(),hashlib.sha256).digest()
    return base64.urlsafe_b64encode(signature).decode().rstrip("=")


def create_session() -> str:
    payload=f"{int(time.time())+SESSION_TTL}.{secrets.token_urlsafe(32)}"
    return f"{payload}.{_sign(payload)}"


def valid_session(value: str | None) -> bool:
    if not value: return False
    try:
        expiry,nonce,signature=value.split(".",2); payload=f"{expiry}.{nonce}"
        return int(expiry)>int(time.time()) and hmac.compare_digest(signature,_sign(payload))
    except (ValueError,RuntimeError): return False


def require_session(request: Request) -> None:
    if not valid_session(request.cookies.get(COOKIE_NAME)):
        raise HTTPException(status_code=401,detail="Quant site authentication required")


def set_session_cookie(response: Response, token: str) -> None:
    response.set_cookie(COOKIE_NAME,token,httponly=True,secure=os.getenv("QUANT_COOKIE_SECURE","true").lower()=="true",samesite="lax",max_age=SESSION_TTL,path="/")
