from __future__ import annotations
from dataclasses import dataclass
from math import sqrt
from .analysis import analyze_candles

@dataclass
class BacktestConfig:
    initial_equity: float = 10000.0
    risk_fraction: float = 0.005
    fee_rate: float = 0.0
    slippage_bps: float = 0.0
    threshold: float = 0.35


def performance_metrics(equity_curve: list[float], trades: list[dict]) -> dict:
    if not equity_curve: raise ValueError("equity curve cannot be empty")
    returns=[equity_curve[i]/equity_curve[i-1]-1 for i in range(1,len(equity_curve)) if equity_curve[i-1]]
    peak=equity_curve[0]; max_dd=0.0
    for value in equity_curve:
        peak=max(peak,value); max_dd=max(max_dd,(peak-value)/peak if peak else 0)
    wins=[t for t in trades if t["pnl"]>0]; losses=[t for t in trades if t["pnl"]<0]
    gross_profit=sum(t["pnl"] for t in wins); gross_loss=abs(sum(t["pnl"] for t in losses))
    avg= sum(returns)/len(returns) if returns else 0
    std=(sum((x-avg)**2 for x in returns)/(len(returns)-1))**0.5 if len(returns)>1 else 0
    return {"total_return":round(equity_curve[-1]/equity_curve[0]-1,6) if equity_curve[0] else 0,"max_drawdown":round(max_dd,6),"trade_count":len(trades),"win_rate":round(len(wins)/len(trades),4) if trades else 0,"profit_factor":round(gross_profit/gross_loss,4) if gross_loss else (None if gross_profit==0 else "infinite"),"average_trade_pnl":round(sum(t['pnl'] for t in trades)/len(trades),6) if trades else 0,"sharpe_per_bar":round(avg/std*sqrt(len(returns)),4) if std else 0,"ending_equity":round(equity_curve[-1],6)}


def run_backtest(symbol: str, timeframe: str, candles: list[dict], config: BacktestConfig | None = None) -> dict:
    cfg=config or BacktestConfig()
    if cfg.initial_equity<=0 or not 0<cfg.risk_fraction<=0.02 or cfg.fee_rate<0 or cfg.slippage_bps<0: raise ValueError("Invalid backtest configuration")
    candles=sorted(candles,key=lambda x:int(x['epoch']))
    equity=cfg.initial_equity; curve=[equity]; trades=[]
    # Strict next-bar execution: signal uses data ending at i; entry is next bar open; exit is following close.
    for i in range(35,len(candles)-1):
        sample=candles[:i+1]
        signal=analyze_candles(symbol,timeframe,sample)
        if signal['direction']=="NEUTRAL" or abs(signal['score'])<cfg.threshold: continue
        entry=float(candles[i+1]['open']); exit_price=float(candles[i+1]['close'])
        side=1 if signal['direction']=="BUY" else -1
        stop_distance=float(signal['indicators']['atr14'] or 0)
        if stop_distance<=0 or entry<=0: continue
        risk_cash=equity*cfg.risk_fraction; units=risk_cash/stop_distance
        gross=side*(exit_price-entry)*units
        costs=abs(entry*units)*(cfg.fee_rate*2+cfg.slippage_bps/10000*2)
        pnl=gross-costs; equity+=pnl
        trades.append({"entry_epoch":int(candles[i+1]['epoch']),"side":signal['direction'],"entry":entry,"exit":exit_price,"units":units,"pnl":pnl,"regime":signal['regime']})
        curve.append(equity)
    return {"symbol":symbol,"timeframe":timeframe,"config":cfg.__dict__,"metrics":performance_metrics(curve,trades),"equity_curve":curve,"trades":trades,"disclaimer":"Hypothetical research only. Results exclude broker-specific contract rules and may not represent executable Deriv outcomes. No profit is guaranteed."}


def walk_forward(symbol: str, timeframe: str, candles: list[dict], train_size: int=500, test_size: int=100, step: int=100) -> dict:
    if train_size<100 or test_size<20 or step<1: raise ValueError("Invalid walk-forward windows")
    folds=[]; start=0
    while start+train_size+test_size<=len(candles):
        train=candles[start:start+train_size]; test=candles[start+train_size:start+train_size+test_size]
        # Training window estimates a conservative score threshold; test remains strictly out-of-sample.
        scores=[]
        for i in range(35,len(train)-1, max(1,len(train)//100)):
            result=analyze_candles(symbol,timeframe,train[:i+1]); scores.append(abs(result['score']))
        threshold=max(0.35,sorted(scores)[len(scores)//2] if scores else 0.35)
        result=run_backtest(symbol,timeframe,test,BacktestConfig(threshold=threshold)) if len(test)>=36 else None
        folds.append({"fold":len(folds)+1,"train_start":int(train[0]['epoch']),"train_end":int(train[-1]['epoch']),"test_start":int(test[0]['epoch']),"test_end":int(test[-1]['epoch']),"selected_threshold":threshold,"out_of_sample":result['metrics'] if result else None})
        start+=step
    return {"symbol":symbol,"timeframe":timeframe,"folds":folds,"fold_count":len(folds),"method":"rolling-origin walk-forward; no future bars used in each fold"}
