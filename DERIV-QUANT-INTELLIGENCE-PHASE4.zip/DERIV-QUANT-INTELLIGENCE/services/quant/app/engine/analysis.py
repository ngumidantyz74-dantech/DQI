from __future__ import annotations
from collections import Counter
from statistics import mean, pstdev
from .indicators import sma, ema, rsi, atr, bollinger, macd, realized_volatility

TIMEFRAMES = {"M1":60,"M5":300,"M15":900,"M30":1800,"H1":3600,"H4":14400,"D1":86400}


def _regime(closes: list[float], atr_values: list[float | None], bb: list[dict | None]) -> tuple[str,float]:
    if len(closes)<30: return "INSUFFICIENT_DATA",0.0
    fast,slow=ema(closes,12),ema(closes,26)
    f,s=fast[-1],slow[-1]
    vol=realized_volatility(closes,20) or 0.0
    bandwidth=(bb[-1] or {}).get("bandwidth",0.0)
    trend=abs((f-s)/s) if f is not None and s else 0.0
    if vol > 0.025 or (atr_values[-1] or 0)/closes[-1] > 0.02: return "HIGH_VOLATILITY",min(1.0,vol*20)
    if trend > 0.0015: return ("TREND_UP" if f>s else "TREND_DOWN"),min(1.0,trend*200)
    if bandwidth < 0.003: return "LOW_VOLATILITY_RANGE",max(0.0,1-bandwidth*200)
    return "RANGE",max(0.0,1-trend*200)


def analyze_candles(symbol: str, timeframe: str, candles: list[dict]) -> dict:
    if timeframe not in TIMEFRAMES: raise ValueError("Unsupported timeframe")
    if len(candles)<35: raise ValueError("At least 35 candles are required")
    candles=sorted(candles,key=lambda x:int(x["epoch"]))
    closes=[float(c["close"]) for c in candles]
    if any(not (float(c['high'])>=float(c['low']) and float(c['high'])>=float(c['open']) and float(c['high'])>=float(c['close']) and float(c['low'])<=float(c['open']) and float(c['low'])<=float(c['close'])) for c in candles):
        raise ValueError("Invalid OHLC candle")
    e12,e26=ema(closes,12),ema(closes,26); r=rsi(closes); a=atr(candles); b=bollinger(closes); m=macd(closes)
    regime,regime_strength=_regime(closes,a,b)
    last=closes[-1]; score=0.0; reasons=[]
    if e12[-1] and e26[-1]:
        if e12[-1]>e26[-1]: score+=0.30; reasons.append("EMA12 above EMA26")
        else: score-=0.30; reasons.append("EMA12 below EMA26")
    if r[-1] is not None:
        if r[-1]>55: score+=0.20; reasons.append("RSI bullish momentum")
        elif r[-1]<45: score-=0.20; reasons.append("RSI bearish momentum")
    if m[-1] and m[-1]["histogram"]>0: score+=0.20; reasons.append("MACD positive histogram")
    elif m[-1]: score-=0.20; reasons.append("MACD negative histogram")
    if b[-1] and last>b[-1]["middle"]: score+=0.15; reasons.append("Price above Bollinger midline")
    elif b[-1]: score-=0.15; reasons.append("Price below Bollinger midline")
    if regime in ("HIGH_VOLATILITY","INSUFFICIENT_DATA"): score*=0.5
    direction="BUY" if score>=0.35 else "SELL" if score<=-0.35 else "NEUTRAL"
    raw_confidence=min(0.90,0.50+abs(score)*0.35+regime_strength*0.10)
    return {"symbol":symbol,"timeframe":timeframe,"as_of_epoch":int(candles[-1]["epoch"]),"price":last,"direction":direction,"raw_confidence":round(raw_confidence,4),"score":round(score,4),"regime":regime,"regime_strength":round(regime_strength,4),"indicators":{"ema12":e12[-1],"ema26":e26[-1],"rsi14":r[-1],"atr14":a[-1],"bollinger":b[-1],"macd":m[-1],"realized_volatility_20":realized_volatility(closes,20)},"reasons":reasons,"sample_size":len(candles)}


def multi_timeframe(symbol: str, candles_by_tf: dict[str,list[dict]]) -> dict:
    analyses={tf:analyze_candles(symbol,tf,data) for tf,data in candles_by_tf.items() if tf in TIMEFRAMES}
    weighted=sum((1 if x["direction"]=="BUY" else -1 if x["direction"]=="SELL" else 0)*x["raw_confidence"] for x in analyses.values())
    denominator=sum(x["raw_confidence"] for x in analyses.values()) or 1
    consensus=weighted/denominator
    return {"symbol":symbol,"timeframes":analyses,"consensus":"BUY" if consensus>=0.25 else "SELL" if consensus<=-0.25 else "MIXED","consensus_score":round(consensus,4),"alignment":round(abs(consensus),4)}


def calibrate_confidence(raw: float, calibration: dict | None = None) -> float:
    """Platt-scale a score only when fitted parameters exist; otherwise preserve raw score."""
    if not 0<=raw<=1: raise ValueError("confidence must be between 0 and 1")
    if calibration is None: return round(raw,4)
    slope=float(calibration.get("slope",1)); intercept=float(calibration.get("intercept",0))
    if slope<=0: raise ValueError("calibration slope must be positive")
    import math
    x=max(1e-6,min(1-1e-6,raw)); z=max(-30,min(30,slope*math.log(x/(1-x))+intercept))
    return round(1/(1+math.exp(-z)),4)


def fit_platt_calibration(observations: list[dict], max_iterations: int=100) -> dict:
    """Fit logistic calibration to (predicted confidence, binary outcome) observations."""
    if len(observations)<30: raise ValueError("At least 30 labelled outcomes are required")
    xs=[]; ys=[]
    import math
    for item in observations:
        p=float(item["confidence"]); y=int(item["outcome"])
        if not 0<p<1 or y not in (0,1): raise ValueError("Each observation needs confidence in (0,1) and outcome 0 or 1")
        xs.append(math.log(p/(1-p))); ys.append(y)
    if len(set(ys))<2: raise ValueError("Calibration requires both winning and losing outcomes")
    slope,intercept=1.0,0.0
    for _ in range(max_iterations):
        g0=g1=h00=h01=h11=0.0
        for x,y in zip(xs,ys):
            z=max(-30,min(30,slope*x+intercept)); q=1/(1+math.exp(-z)); w=max(q*(1-q),1e-8)
            error=q-y; g0+=error*x; g1+=error; h00+=w*x*x; h01+=w*x; h11+=w
        det=h00*h11-h01*h01
        if abs(det)<1e-12: break
        d0=(h11*g0-h01*g1)/det; d1=(-h01*g0+h00*g1)/det
        slope=max(0.01,min(20.0,slope-d0)); intercept=max(-20.0,min(20.0,intercept-d1))
        if abs(d0)+abs(d1)<1e-7: break
    predictions=[1/(1+math.exp(-max(-30,min(30,slope*x+intercept)))) for x in xs]
    brier=sum((prediction-y)**2 for prediction,y in zip(predictions,ys))/len(xs)
    return {"slope":round(slope,8),"intercept":round(intercept,8),"sample_count":len(xs),"brier_score":round(brier,8)}
