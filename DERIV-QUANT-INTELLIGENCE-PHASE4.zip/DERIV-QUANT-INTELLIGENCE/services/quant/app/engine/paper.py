from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from math import isfinite
from typing import Any


@dataclass(frozen=True)
class PaperRiskPolicy:
    max_stake_fraction: float = 0.02
    max_daily_loss_fraction: float = 0.05
    max_open_positions: int = 5
    min_expiry_seconds: int = 30
    max_expiry_seconds: int = 86400


def validate_paper_order(*, equity: float, available_balance: float, stake: float,
                         expiry_seconds: int, open_positions: int,
                         daily_realized_pnl: float, policy: PaperRiskPolicy | None = None) -> dict[str, Any]:
    policy = policy or PaperRiskPolicy()
    values = (equity, available_balance, stake, daily_realized_pnl)
    if any(not isfinite(float(v)) for v in values):
        raise ValueError("All monetary values must be finite")
    if equity <= 0 or available_balance < 0 or stake <= 0:
        raise ValueError("Equity and stake must be positive; available balance cannot be negative")
    if stake > available_balance:
        raise ValueError("Stake exceeds available paper balance")
    if stake > equity * policy.max_stake_fraction:
        raise ValueError(f"Stake exceeds the {policy.max_stake_fraction:.1%} per-position risk limit")
    if not policy.min_expiry_seconds <= expiry_seconds <= policy.max_expiry_seconds:
        raise ValueError("Expiry must be between 30 seconds and 24 hours")
    if open_positions >= policy.max_open_positions:
        raise ValueError("Maximum number of open paper positions reached")
    if daily_realized_pnl <= -(equity * policy.max_daily_loss_fraction):
        raise ValueError("Daily loss limit reached; paper trading is paused until the next UTC day")
    return {"approved": True, "stake": round(stake, 8), "max_loss": round(stake, 8),
            "risk_fraction": round(stake / equity, 8), "policy": {
                "max_stake_fraction": policy.max_stake_fraction,
                "max_daily_loss_fraction": policy.max_daily_loss_fraction,
                "max_open_positions": policy.max_open_positions}}


def settle_directional_contract(*, direction: str, entry_price: float, exit_price: float,
                                stake: float, payout_multiplier: float) -> dict[str, Any]:
    if direction not in ("BUY", "SELL"):
        raise ValueError("Direction must be BUY or SELL")
    if not all(isfinite(float(x)) for x in (entry_price, exit_price, stake, payout_multiplier)):
        raise ValueError("Contract values must be finite")
    if entry_price <= 0 or exit_price <= 0 or stake <= 0 or not 0 < payout_multiplier <= 10:
        raise ValueError("Invalid contract settlement parameters")
    won = exit_price > entry_price if direction == "BUY" else exit_price < entry_price
    # Flat settlement is a loss in this conservative research model.
    pnl = stake * payout_multiplier if won else -stake
    return {"status": "WON" if won else "LOST", "won": won,
            "gross_payout": round(stake * (1 + payout_multiplier), 8) if won else 0.0,
            "profit_loss": round(pnl, 8), "entry_price": entry_price,
            "exit_price": exit_price, "direction": direction,
            "payout_multiplier": payout_multiplier,
            "settled_at": datetime.now(timezone.utc).isoformat(),
            "model": "FIXED_PAYOUT_DIRECTIONAL_RESEARCH_SIMULATION"}


def summarize_paper_performance(trades: list[dict[str, Any]], starting_equity: float) -> dict[str, Any]:
    closed = [t for t in trades if t.get("status") in ("WON", "LOST")]
    pnls = [float(t.get("profit_loss", 0)) for t in closed]
    wins = [p for p in pnls if p > 0]
    losses = [p for p in pnls if p < 0]
    equity = starting_equity
    peak = starting_equity
    max_drawdown = 0.0
    for pnl in pnls:
        equity += pnl
        peak = max(peak, equity)
        if peak > 0:
            max_drawdown = max(max_drawdown, (peak - equity) / peak)
    gross_profit, gross_loss = sum(wins), abs(sum(losses))
    return {"starting_equity": round(starting_equity, 8), "current_equity": round(starting_equity + sum(pnls), 8),
            "net_profit": round(sum(pnls), 8), "return_fraction": round(sum(pnls) / starting_equity, 8) if starting_equity else 0,
            "closed_trades": len(closed), "open_trades": sum(1 for t in trades if t.get("status") == "OPEN"),
            "wins": len(wins), "losses": len(losses), "win_rate": round(len(wins) / len(closed), 6) if closed else 0.0,
            "profit_factor": round(gross_profit / gross_loss, 6) if gross_loss else (None if gross_profit else 0.0),
            "max_drawdown": round(max_drawdown, 8), "gross_profit": round(gross_profit, 8),
            "gross_loss": round(gross_loss, 8), "note": "Paper simulation only; fixed payout assumptions are not Deriv contract quotes."}
