"""Deterministic technical indicators. All functions accept chronological candles."""
from __future__ import annotations
from math import sqrt
from typing import Sequence


def sma(values: Sequence[float], period: int) -> list[float | None]:
    if period < 1: raise ValueError("period must be positive")
    out: list[float | None] = [None] * len(values)
    for i in range(period - 1, len(values)):
        out[i] = sum(values[i-period+1:i+1]) / period
    return out


def ema(values: Sequence[float], period: int) -> list[float | None]:
    if period < 1: raise ValueError("period must be positive")
    out: list[float | None] = [None] * len(values)
    if len(values) < period: return out
    seed = sum(values[:period]) / period
    out[period-1] = seed
    alpha = 2 / (period + 1)
    previous = seed
    for i in range(period, len(values)):
        previous = values[i] * alpha + previous * (1-alpha)
        out[i] = previous
    return out


def rsi(values: Sequence[float], period: int = 14) -> list[float | None]:
    out: list[float | None] = [None] * len(values)
    if period < 2 or len(values) <= period: return out
    gains = [max(values[i]-values[i-1], 0.0) for i in range(1, len(values))]
    losses = [max(values[i-1]-values[i], 0.0) for i in range(1, len(values))]
    avg_gain, avg_loss = sum(gains[:period])/period, sum(losses[:period])/period
    out[period] = 100.0 if avg_loss == 0 and avg_gain > 0 else (50.0 if avg_loss == 0 else 100-100/(1+avg_gain/avg_loss))
    for i in range(period+1, len(values)):
        avg_gain = (avg_gain*(period-1)+gains[i-1])/period
        avg_loss = (avg_loss*(period-1)+losses[i-1])/period
        out[i] = 100.0 if avg_loss == 0 and avg_gain > 0 else (50.0 if avg_loss == 0 else 100-100/(1+avg_gain/avg_loss))
    return out


def true_ranges(candles: Sequence[dict]) -> list[float]:
    result=[]
    for i,c in enumerate(candles):
        high, low = float(c['high']), float(c['low'])
        result.append(high-low if i == 0 else max(high-low, abs(high-float(candles[i-1]['close'])), abs(low-float(candles[i-1]['close']))))
    return result


def atr(candles: Sequence[dict], period: int = 14) -> list[float | None]:
    return ema(true_ranges(candles), period)


def bollinger(values: Sequence[float], period: int = 20, deviations: float = 2.0) -> list[dict | None]:
    result: list[dict | None] = [None] * len(values)
    for i in range(period-1, len(values)):
        window=values[i-period+1:i+1]; mean=sum(window)/period
        variance=sum((x-mean)**2 for x in window)/period
        sd=sqrt(variance)
        result[i]={"middle":mean,"upper":mean+deviations*sd,"lower":mean-deviations*sd,"bandwidth":(4*sd/mean if mean else 0)}
    return result


def macd(values: Sequence[float], fast: int = 12, slow: int = 26, signal: int = 9) -> list[dict | None]:
    a,b=ema(values,fast),ema(values,slow); line=[(x-y if x is not None and y is not None else None) for x,y in zip(a,b)]
    valid_start=next((i for i,x in enumerate(line) if x is not None),len(line))
    compact=[x for x in line[valid_start:] if x is not None]; sig=ema(compact,signal)
    result: list[dict | None]=[None]*len(values)
    for j,x in enumerate(compact):
        k=valid_start+j
        if sig[j] is not None: result[k]={"macd":x,"signal":sig[j],"histogram":x-sig[j]}
    return result


def realized_volatility(values: Sequence[float], period: int = 20) -> float | None:
    if len(values) <= period: return None
    returns=[(values[i]/values[i-1])-1 for i in range(len(values)-period+1,len(values)) if values[i-1] != 0]
    if len(returns)<2: return None
    mean=sum(returns)/len(returns)
    return sqrt(sum((r-mean)**2 for r in returns)/(len(returns)-1))*sqrt(period)
