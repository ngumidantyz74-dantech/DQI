from __future__ import annotations
import asyncio, json
from typing import Any
import websockets

WS_URL="wss://api.derivws.com/trading/v1/options/ws/public"

async def deriv_request(payload: dict[str,Any], timeout: float=15.0) -> dict:
    async with websockets.connect(WS_URL, open_timeout=timeout, close_timeout=3, ping_interval=20, ping_timeout=20) as ws:
        await ws.send(json.dumps(payload))
        async with asyncio.timeout(timeout):
            while True:
                message=json.loads(await ws.recv())
                if message.get("error"): raise RuntimeError(message["error"].get("message","Deriv API error"))
                if message.get("msg_type") in ("active_symbols","candles","history","tick"): return message

async def discover_symbols() -> list[dict]:
    response=await deriv_request({"active_symbols":"full"})
    return response.get("active_symbols",[])

async def fetch_candles(symbol: str, granularity: int, count: int=500) -> list[dict]:
    if not symbol.isalnum() and not all(c.isalnum() or c=='_' for c in symbol): raise ValueError("Invalid symbol")
    if granularity not in (60,300,900,1800,3600,14400,86400): raise ValueError("Unsupported granularity")
    response=await deriv_request({"ticks_history":symbol,"count":min(max(count,35),5000),"end":"latest","style":"candles","granularity":granularity})
    return response.get("candles",[])
