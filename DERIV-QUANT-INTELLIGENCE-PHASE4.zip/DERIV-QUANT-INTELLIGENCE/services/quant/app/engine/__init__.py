"""DQI quantitative research engine."""
