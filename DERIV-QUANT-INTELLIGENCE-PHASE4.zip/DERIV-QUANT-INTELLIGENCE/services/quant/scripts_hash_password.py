"""Generate QUANT_ADMIN_PASSWORD_HASH. Run: python scripts_hash_password.py"""
from getpass import getpass
from app.security import hash_password

if __name__ == "__main__":
    first=getpass("New quant-site admin password (14+ characters): ")
    second=getpass("Confirm password: ")
    if first != second: raise SystemExit("Passwords do not match")
    print("Set this value as QUANT_ADMIN_PASSWORD_HASH in your deployment secret store:\n")
    print(hash_password(first))
