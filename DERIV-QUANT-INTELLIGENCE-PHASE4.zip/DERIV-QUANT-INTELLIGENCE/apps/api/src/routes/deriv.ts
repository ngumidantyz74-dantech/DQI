import type { FastifyInstance } from "fastify";
import { pool } from "../db/pool.js";
import { config, assertDerivConfigured } from "../config.js";
import { randomToken, sha256 } from "../security/crypto.js";
import { SESSION_COOKIE, getActiveSession, requireSession } from "../security/session.js";
import { createOAuthStart, completeOAuth } from "../deriv/oauth.js";
import { discoverAndStoreAccounts, getAccountBalance } from "../deriv/accounts.js";
import { marketFeed } from "../deriv/market.js";

function sessionCookieOptions(secure: boolean) {
  return {
    path: "/",
    httpOnly: true,
    sameSite: "lax" as const,
    secure,
    signed: true,
    maxAge: 60 * 60 * 24 * 14
  };
}

export async function registerDerivRoutes(app: FastifyInstance): Promise<void> {
  app.get("/api/v1/auth/deriv/start", async (request, reply) => {
    assertDerivConfigured();
    let session = await getActiveSession(request);
    if (!session) {
      const rawSessionToken = randomToken(32);
      const owner = await pool.query(
        "SELECT user_id FROM app_users WHERE email = 'dqi-operator@localhost' AND status = 'ACTIVE'"
      );
      if (!owner.rowCount) return reply.code(503).send({ error: "DQI_OPERATOR_NOT_BOOTSTRAPPED" });
      const inserted = await pool.query(
        `INSERT INTO dqi_sessions(session_token_hash, owner_user_id, expires_at)
         VALUES ($1, $2, now() + interval '14 days')
         RETURNING session_id`,
        [sha256(rawSessionToken), owner.rows[0].user_id]
      );
      reply.setCookie(SESSION_COOKIE, rawSessionToken, sessionCookieOptions(config.NODE_ENV === "production"));
      session = {
        session_id: inserted.rows[0].session_id,
        owner_user_id: owner.rows[0].user_id,
        deriv_credential_id: null
      };
    }
    const authorizationUrl = await createOAuthStart(session.session_id);
    return reply.send({ authorizationUrl });
  });

  app.get("/api/v1/auth/deriv/callback", async (request, reply) => {
    const query = request.query as { code?: string; state?: string; error?: string; error_description?: string };
    if (query.error) return reply.code(400).send({ error: "DERIV_OAUTH_DENIED", description: query.error });
    if (!query.code || !query.state) return reply.code(400).send({ error: "INVALID_OAUTH_CALLBACK" });
    const session = await getActiveSession(request);
    if (!session) return reply.code(401).send({ error: "OAUTH_SESSION_MISSING", message: "Restart the Deriv connection flow." });

    try {
      const result = await completeOAuth(query.code, query.state, session.session_id, session.owner_user_id);
      request.log.info({ credentialExpiresAt: result.expiresAt.toISOString() }, "Deriv OAuth connected");
      return reply.redirect(`${config.WEB_ORIGIN}/?deriv=connected`);
    } catch (error) {
      request.log.warn({ err: error }, "Deriv OAuth callback failed");
      return reply.code(400).send({ error: "DERIV_OAUTH_CALLBACK_FAILED" });
    }
  });

  app.post("/api/v1/auth/deriv/disconnect", { preHandler: requireSession }, async (request, reply) => {
    const session = (request as any).dqiSession;
    if (session.deriv_credential_id) {
      await pool.query(
        "UPDATE deriv_credentials SET status = 'REVOKED', updated_at = now() WHERE credential_id = $1 AND owner_user_id = $2",
        [session.deriv_credential_id, session.owner_user_id]
      );
    }
    await pool.query("UPDATE dqi_sessions SET deriv_credential_id = NULL WHERE session_id = $1", [session.session_id]);
    await pool.query(
      "UPDATE dqi_sessions SET revoked_at = now() WHERE session_id = $1",
      [session.session_id]
    );
    reply.clearCookie(SESSION_COOKIE, { path: "/" });
    return reply.send({ disconnected: true });
  });

  app.get("/api/v1/deriv/accounts", { preHandler: requireSession }, async (request, reply) => {
    const session = (request as any).dqiSession;
    if (!session.deriv_credential_id) return reply.code(409).send({ error: "DERIV_NOT_CONNECTED" });
    try {
      const accounts = await discoverAndStoreAccounts(session.deriv_credential_id, session.owner_user_id);
      return { accounts };
    } catch (error) {
      request.log.error({ err: error }, "Deriv account discovery failed");
      return reply.code(502).send({ error: "DERIV_ACCOUNT_DISCOVERY_FAILED" });
    }
  });

  app.get("/api/v1/deriv/accounts/:accountId/balance", { preHandler: requireSession }, async (request, reply) => {
    const session = (request as any).dqiSession;
    if (!session.deriv_credential_id) return reply.code(409).send({ error: "DERIV_NOT_CONNECTED" });
    const params = request.params as { accountId: string };
    const query = request.query as { environment?: string };
    if (query.environment !== "DEMO" && query.environment !== "REAL") {
      return reply.code(400).send({ error: "ENVIRONMENT_REQUIRED", allowed: ["DEMO", "REAL"] });
    }
    try {
      const balance = await getAccountBalance(
        params.accountId, session.owner_user_id, session.deriv_credential_id, query.environment
      );
      return balance;
    } catch (error) {
      request.log.warn({ err: error }, "Deriv balance retrieval failed");
      return reply.code(502).send({ error: "DERIV_BALANCE_UNAVAILABLE" });
    }
  });

  app.get("/api/v1/deriv/connection", { preHandler: requireSession }, async (request) => {
    const session = (request as any).dqiSession;
    const result = await pool.query(
      `SELECT credential_id, token_expires_at, status, scopes
         FROM deriv_credentials
        WHERE credential_id = $1 AND owner_user_id = $2`,
      [session.deriv_credential_id, session.owner_user_id]
    );
    if (!result.rowCount) return { connected: false };
    return {
      connected: result.rows[0].status === "ACTIVE" && new Date(result.rows[0].token_expires_at) > new Date(),
      expiresAt: result.rows[0].token_expires_at,
      status: result.rows[0].status,
      scopes: result.rows[0].scopes
    };
  });

  app.get("/api/v1/markets/symbols", async (_request, reply) => {
    try {
      const symbols = await marketFeed.activeSymbols();
      return { symbols, source: "DERIV_PUBLIC_WEBSOCKET" };
    } catch {
      return reply.code(502).send({ error: "DERIV_SYMBOL_DISCOVERY_FAILED" });
    }
  });

  app.get("/api/v1/markets/history/:symbol", async (request, reply) => {
    const params = request.params as { symbol: string };
    const query = request.query as {
      count?: string; start?: string; end?: string; style?: string; granularity?: string;
    };
    const count = query.count ? Number(query.count) : 500;
    const start = query.start ? Number(query.start) : undefined;
    const granularity = query.granularity ? Number(query.granularity) : 60;
    if (!Number.isInteger(count) || count < 1 || count > 5000 ||
        (start !== undefined && (!Number.isInteger(start) || start < 0)) ||
        ![60,120,180,300,600,900,1800,3600,7200,14400,28800,86400].includes(granularity)) {
      return reply.code(400).send({ error: "INVALID_HISTORY_PARAMETERS" });
    }
    try {
      const history = await marketFeed.history(params.symbol, {
        count, start, end: query.end === undefined ? "latest" : query.end,
        style: query.style === "ticks" ? "ticks" : "candles", granularity
      });
      return history;
    } catch {
      return reply.code(502).send({ error: "DERIV_HISTORY_UNAVAILABLE" });
    }
  });

  app.post("/api/v1/markets/subscribe", async (request, reply) => {
    const body = request.body as { symbol?: string };
    if (!body?.symbol || !/^[A-Za-z0-9_]{2,30}$/.test(body.symbol)) {
      return reply.code(400).send({ error: "INVALID_SYMBOL" });
    }
    try {
      await marketFeed.subscribe(body.symbol);
      return { subscribed: true, symbol: body.symbol };
    } catch {
      return reply.code(502).send({ error: "DERIV_SUBSCRIPTION_FAILED" });
    }
  });

  app.get("/api/v1/markets/ticks/:symbol", async (request) => {
    const params = request.params as { symbol: string };
    const result = await pool.query(
      `SELECT symbol_code AS symbol, quote::text AS quote, epoch,
              received_at AS "receivedAt"
         FROM market_ticks
        WHERE symbol_code = $1
        ORDER BY epoch DESC
        LIMIT 100`,
      [params.symbol]
    );
    return { ticks: result.rows.reverse() };
  });

  app.get("/api/v1/markets/stream", async (request, reply) => {
    const query = request.query as { symbol?: string };
    if (!query.symbol || !/^[A-Za-z0-9_]{2,30}$/.test(query.symbol)) {
      return reply.code(400).send({ error: "VALID_SYMBOL_REQUIRED" });
    }
    try { await marketFeed.subscribe(query.symbol); }
    catch { return reply.code(502).send({ error: "MARKET_FEED_UNAVAILABLE" }); }

    reply.hijack();
    reply.raw.writeHead(200, {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache, no-transform",
      "Connection": "keep-alive",
      "X-Accel-Buffering": "no"
    });
    reply.raw.write(`event: ready\ndata: ${JSON.stringify({ symbol: query.symbol })}\n\n`);
    const onTick = (tick: { symbol: string }) => {
      if (tick.symbol === query.symbol) reply.raw.write(`event: tick\ndata: ${JSON.stringify(tick)}\n\n`);
    };
    const heartbeat = setInterval(() => reply.raw.write(": keep-alive\n\n"), 20_000);
    marketFeed.on("tick", onTick);
    reply.raw.on("close", () => {
      clearInterval(heartbeat);
      marketFeed.off("tick", onTick);
    });
  });
}
