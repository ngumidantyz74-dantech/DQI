import type { FastifyReply, FastifyRequest } from "fastify";
import { pool } from "../db/pool.js";
import { sha256 } from "./crypto.js";

export const SESSION_COOKIE = "dqi_session";

export async function getActiveSession(request: FastifyRequest) {
  const signedCookie = request.cookies[SESSION_COOKIE];
  if (!signedCookie) return null;
  const unsigned = request.unsignCookie(signedCookie);
  if (!unsigned.valid || !unsigned.value) return null;
  const token = unsigned.value;

  const result = await pool.query(
    `SELECT s.session_id, s.owner_user_id, s.deriv_credential_id
       FROM dqi_sessions s
      WHERE s.session_token_hash = $1
        AND s.revoked_at IS NULL
        AND s.expires_at > now()`,
    [sha256(token)]
  );
  if (!result.rowCount) return null;

  await pool.query(
    "UPDATE dqi_sessions SET last_seen_at = now() WHERE session_id = $1",
    [result.rows[0].session_id]
  );
  return result.rows[0] as {
    session_id: string;
    owner_user_id: string;
    deriv_credential_id: string | null;
  };
}

export async function requireSession(request: FastifyRequest, reply: FastifyReply): Promise<void> {
  const session = await getActiveSession(request);
  if (!session) {
    reply.code(401).send({ error: "AUTHENTICATION_REQUIRED" });
    return;
  }
  (request as FastifyRequest & { dqiSession: typeof session }).dqiSession = session;
}
