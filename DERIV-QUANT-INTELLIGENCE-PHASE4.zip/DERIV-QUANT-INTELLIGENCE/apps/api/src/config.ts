import { z } from "zod";

const schema = z.object({
  NODE_ENV: z.enum(["development", "test", "production"]).default("development"),
  API_HOST: z.string().default("0.0.0.0"),
  API_PORT: z.coerce.number().int().min(1).max(65535).default(8080),
  WEB_ORIGIN: z.string().url().default("http://localhost:5173"),
  DATABASE_URL: z.string().default("postgresql://dqi_app:local-development-only@localhost:5432/dqi"),
  REDIS_URL: z.string().default("redis://localhost:6379/0"),
  QUANT_BASE_URL: z.string().url().default("http://localhost:8000"),
  DQI_TRADING_ENABLED: z.string().default("false"),
  DQI_LIVE_TRADING_ENABLED: z.string().default("false"),
  DERIV_CLIENT_ID: z.string().optional(),
  DERIV_REDIRECT_URI: z.string().url().optional(),
  DERIV_OAUTH_SCOPES: z.string().default("trade"),
  DERIV_API_BASE_URL: z.string().url().default("https://api.derivws.com"),
  DERIV_AUTH_BASE_URL: z.string().url().default("https://auth.deriv.com"),
  DQI_ENCRYPTION_KEY_BASE64: z.preprocess((value) => value === "" ? undefined : value, z.string().optional()),
  DQI_SESSION_SECRET: z.preprocess((value) => value === "" ? undefined : value, z.string().min(32).optional())
});

export const config = schema.parse(process.env);

if (config.DQI_TRADING_ENABLED !== "false" || config.DQI_LIVE_TRADING_ENABLED !== "false") {
  throw new Error("Trading execution is not implemented; both trading flags must remain false.");
}

export function assertDerivConfigured(): void {
  const missing = [
    ["DERIV_CLIENT_ID", config.DERIV_CLIENT_ID],
    ["DERIV_REDIRECT_URI", config.DERIV_REDIRECT_URI],
    ["DQI_ENCRYPTION_KEY_BASE64", config.DQI_ENCRYPTION_KEY_BASE64],
    ["DQI_SESSION_SECRET", config.DQI_SESSION_SECRET]
  ].filter(([, value]) => !value).map(([name]) => name);
  if (missing.length) {
    throw new Error(`Deriv integration is not configured. Missing: ${missing.join(", ")}`);
  }
  if ((config.DQI_SESSION_SECRET ?? "").length < 32) {
    throw new Error("DQI_SESSION_SECRET must contain at least 32 characters");
  }
  const encryptionKey = Buffer.from(config.DQI_ENCRYPTION_KEY_BASE64!, "base64");
  if (encryptionKey.length !== 32) {
    throw new Error("DQI_ENCRYPTION_KEY_BASE64 must decode to exactly 32 bytes");
  }
  if (config.NODE_ENV === "production" && !config.DERIV_REDIRECT_URI!.startsWith("https://")) {
    throw new Error("DERIV_REDIRECT_URI must use HTTPS in production");
  }
}
