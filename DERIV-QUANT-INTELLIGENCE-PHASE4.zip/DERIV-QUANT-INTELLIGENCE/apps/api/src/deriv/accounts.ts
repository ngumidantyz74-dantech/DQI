import { pool } from "../db/pool.js";
import { accessTokenForCredential, listDerivAccounts } from "./oauth.js";
import { derivRequest } from "./rest.js";
import { DerivSocket } from "./websocket.js";
import { classifyAccountEnvironment, normalizeAccountType } from "./account-environment.js";

type DerivAccount = {
  account_id?: string;
  loginid?: string;
  currency?: string;
  account_type?: string;
  is_virtual?: number | boolean;
  landing_company_name?: string;
  [key: string]: unknown;
};

export async function discoverAndStoreAccounts(
  credentialId: string,
  ownerUserId: string
): Promise<unknown[]> {
  const token = await accessTokenForCredential(credentialId, ownerUserId);
  const response = await listDerivAccounts(token);
  const rawAccounts = (response.data ?? response.accounts ?? []) as DerivAccount[];
  const accounts: unknown[] = [];

  for (const account of rawAccounts) {
    const externalRef = String(account.account_id ?? account.loginid ?? "");
    if (!externalRef) continue;
    const environment = classifyAccountEnvironment(account);
    if (!environment) continue; // Fail closed: never guess DEMO vs REAL.
    const saved = await pool.query(
      `INSERT INTO trading_accounts
        (owner_user_id, deriv_credential_id, provider, environment, external_ref, currency,
         broker_currency, account_type, is_virtual, display_label, status, last_seen_at)
       VALUES ($1, $2, 'DERIV_OPTIONS', $3, $4, $5, $5, $6, $7, $8, 'CONNECTED', now())
       ON CONFLICT (deriv_credential_id, provider, environment, external_ref)
       DO UPDATE SET owner_user_id = EXCLUDED.owner_user_id,
                     currency = EXCLUDED.currency,
                     broker_currency = EXCLUDED.broker_currency,
                     account_type = EXCLUDED.account_type,
                     is_virtual = EXCLUDED.is_virtual,
                     status = 'CONNECTED',
                     last_seen_at = now(),
                     updated_at = now()
       RETURNING account_id, provider, environment, external_ref, currency,
                 account_type, is_virtual, display_label, status`,
      [
        ownerUserId, credentialId, environment, externalRef, account.currency ?? null,
        normalizeAccountType(account.account_type), environment === "DEMO", externalRef
      ]
    );
    accounts.push(saved.rows[0]);
  }

  await pool.query(
    `INSERT INTO deriv_connection_events(owner_user_id, event_type, outcome, details)
     VALUES ($1, 'ACCOUNT_DISCOVERY', 'SUCCESS', $2::jsonb)`,
    [ownerUserId, JSON.stringify({ count: accounts.length })]
  );
  return accounts;
}

export async function getOwnedAccount(accountId: string, ownerUserId: string, credentialId: string, environment?: string) {
  const result = await pool.query(
    `SELECT account_id, owner_user_id, provider, environment, external_ref,
            currency, status
       FROM trading_accounts
      WHERE account_id = $1 AND owner_user_id = $2 AND provider = 'DERIV_OPTIONS'
        AND deriv_credential_id = $3
        AND ($4::text IS NULL OR environment = $4)`,
    [accountId, ownerUserId, credentialId, environment ?? null]
  );
  if (!result.rowCount) throw new Error("Account not found or environment mismatch");
  return result.rows[0];
}

export async function getAccountBalance(
  accountId: string,
  ownerUserId: string,
  credentialId: string,
  requestedEnvironment: "DEMO" | "REAL"
) {
  const account = await getOwnedAccount(accountId, ownerUserId, credentialId, requestedEnvironment);
  if (account.environment !== requestedEnvironment) throw new Error("Account environment mismatch");

  const token = await accessTokenForCredential(credentialId, ownerUserId);
  const otpResponse = await derivRequest<{ data?: { url?: string } }>(
    `/trading/v1/options/accounts/${encodeURIComponent(account.external_ref)}/otp`,
    token,
    { method: "POST" }
  );
  const wsUrl = otpResponse.data?.url;
  if (!wsUrl || !wsUrl.startsWith("wss://api.derivws.com/trading/v1/options/ws/")) {
    throw new Error("Deriv returned an unexpected authenticated WebSocket URL");
  }
  const expectedPath = requestedEnvironment === "DEMO" ? "/ws/demo" : "/ws/real";
  if (!new URL(wsUrl).pathname.endsWith(expectedPath)) {
    throw new Error("Deriv WebSocket environment does not match the selected account");
  }

  const socket = await DerivSocket.connect(wsUrl);
  try {
    const response = await socket.request({ balance: 1 });
    const balance = response.balance;
    const numericBalance = Number(balance?.balance);
    if (!balance || !Number.isFinite(numericBalance) || typeof balance.currency !== "string") {
      throw new Error("Deriv returned an invalid balance payload");
    }
    await pool.query(
      `UPDATE trading_accounts
          SET last_balance = $1, currency = $2, broker_currency = $2,
              last_balance_at = now(), last_seen_at = now(), status = 'CONNECTED',
              updated_at = now()
        WHERE account_id = $3 AND owner_user_id = $4`,
      [numericBalance, balance.currency, accountId, ownerUserId]
    );
    await pool.query(
      `INSERT INTO account_balance_snapshots(account_id, balance, currency, broker_epoch)
       VALUES ($1, $2, $3, $4)`,
      [accountId, numericBalance, balance.currency, balance.epoch ?? null]
    );
    return {
      accountId,
      environment: requestedEnvironment,
      balance: numericBalance,
      currency: balance.currency,
      epoch: balance.epoch ?? null,
      source: "DERIV",
      capturedAt: new Date().toISOString()
    };
  } finally {
    socket.close();
  }
}
