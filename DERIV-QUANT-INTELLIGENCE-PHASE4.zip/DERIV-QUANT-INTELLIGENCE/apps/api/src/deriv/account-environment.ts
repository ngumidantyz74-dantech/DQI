import type { DerivAccountEnvironmentInput } from "./types.js";

export type AccountEnvironment = "DEMO" | "REAL";

export function classifyAccountEnvironment(account: DerivAccountEnvironmentInput): AccountEnvironment | null {
  if (account.is_virtual === true || account.is_virtual === 1) return "DEMO";
  if (account.is_virtual === false || account.is_virtual === 0) return "REAL";
  const type = String(account.account_type ?? "").toLowerCase();
  if (type.includes("demo") || type.includes("virtual")) return "DEMO";
  if (type.includes("real") || type.includes("standard") || type.includes("financial") || type.includes("crypto")) return "REAL";
  const id = String(account.account_id ?? account.loginid ?? "").toUpperCase();
  if (id.startsWith("VRTC") || id.startsWith("VR")) return "DEMO";
  if (/^(CR|MF|MLT|MTR)/.test(id)) return "REAL";
  return null;
}

export function normalizeAccountType(value: unknown): "STANDARD" | "VIRTUAL" | "CRYPTO" | "FINANCIAL" | "UNKNOWN" {
  const type = String(value ?? "").toLowerCase();
  if (type.includes("demo") || type.includes("virtual")) return "VIRTUAL";
  if (type.includes("crypto")) return "CRYPTO";
  if (type.includes("financial")) return "FINANCIAL";
  if (type.includes("standard") || type.includes("real")) return "STANDARD";
  return "UNKNOWN";
}
