import { EventEmitter } from "node:events";
import { pool } from "../db/pool.js";
import { DerivSocket, type DerivMessage } from "./websocket.js";

const PUBLIC_WS_URL = "wss://api.derivws.com/trading/v1/options/ws/public";

export class DerivMarketFeed extends EventEmitter {
  private socket: DerivSocket | null = null;
  private stopped = true;
  private connecting: Promise<void> | null = null;
  private reconnectAttempt = 0;
  private desiredSymbols = new Set<string>();
  private unsubscribeMessage?: () => void;
  private retryTimer?: NodeJS.Timeout;

  async start(): Promise<void> {
    this.stopped = false;
  }

  async stop(): Promise<void> {
    this.stopped = true;
    if (this.retryTimer) clearTimeout(this.retryTimer);
    this.unsubscribeMessage?.();
    this.socket?.close();
    this.socket = null;
  }

  async subscribe(symbol: string): Promise<void> {
    if (!/^[A-Za-z0-9_]{2,30}$/.test(symbol)) throw new Error("Invalid Deriv symbol");
    if (!this.desiredSymbols.has(symbol) && this.desiredSymbols.size >= 100) {
      throw new Error("Market subscription limit reached (100 symbols)");
    }
    this.desiredSymbols.add(symbol);
    await this.ensureConnected();
    this.socket!.send({ ticks: symbol, subscribe: 1 });
  }

  async activeSymbols(): Promise<unknown[]> {
    await this.ensureConnected();
    const response = await this.socket!.request({ active_symbols: "full" });
    const symbols = Array.isArray(response.active_symbols) ? response.active_symbols : [];
    if (symbols.length) {
      const client = await pool.connect();
      try {
        await client.query("BEGIN");
        await client.query("UPDATE market_symbols SET is_active = false WHERE provider = 'DERIV'");
        for (const item of symbols as Array<Record<string, unknown>>) {
          const code = String(item.symbol ?? "");
          if (!code) continue;
          const displayName = String(item.display_name ?? item.symbol ?? code);
          const category = String(item.market_display_name ?? item.market ?? "UNKNOWN");
          await client.query(
            `INSERT INTO market_symbols(provider, symbol_code, display_name, market_category, is_active, metadata)
             VALUES ('DERIV', $1, $2, $3, true, $4::jsonb)
             ON CONFLICT (provider, symbol_code) DO UPDATE
               SET display_name = EXCLUDED.display_name,
                   market_category = EXCLUDED.market_category,
                   is_active = true,
                   metadata = EXCLUDED.metadata`,
            [code, displayName, category, JSON.stringify(item)]
          );
        }
        await client.query("COMMIT");
      } catch (error) {
        await client.query("ROLLBACK");
        throw error;
      } finally {
        client.release();
      }
    }
    return symbols;
  }

  async history(symbol: string, options: {
    count?: number; start?: number; end?: number | "latest"; style?: "ticks" | "candles"; granularity?: number;
  }): Promise<DerivMessage> {
    if (!/^[A-Za-z0-9_]{2,30}$/.test(symbol)) throw new Error("Invalid Deriv symbol");
    await this.ensureConnected();
    return this.socket!.request({
      ticks_history: symbol,
      count: options.count ?? 500,
      start: options.start,
      end: options.end ?? "latest",
      style: options.style ?? "candles",
      granularity: options.granularity ?? 60
    });
  }

  private async ensureConnected(): Promise<void> {
    if (this.socket) return;
    await this.connect();
    if (!this.socket) throw new Error("Deriv public market feed is not connected");
  }

  private async connect(): Promise<void> {
    if (this.connecting) return this.connecting;
    this.connecting = (async () => {
      let attempts = 0;
      while (!this.stopped && !this.socket && attempts < 8) {
        attempts += 1;
        try {
          const socket = await DerivSocket.connect(PUBLIC_WS_URL);
          this.socket = socket;
          this.reconnectAttempt = 0;
          this.unsubscribeMessage = socket.onMessage((message) => void this.handleMessage(message));
          this.emit("connected");
          for (const symbol of this.desiredSymbols) socket.send({ ticks: symbol, subscribe: 1 });
          socket.request({ active_symbols: "full" })
            .then((result) => this.emit("symbols", result.active_symbols ?? []))
            .catch((error) => this.emit("feedError", error));
          socket.onMessage((message) => {
            if (message.msg_type === "ping") socket.send({ ping: 1 });
          });
          socket.onMessage((message) => {
            if (message.error) this.emit("feedError", new Error(message.error.message ?? "Deriv stream error"));
          });
          const timer = setInterval(async () => {
            if (this.stopped || this.socket !== socket) {
              clearInterval(timer);
              return;
            }
            if (!socket.isOpen()) {
              clearInterval(timer);
              this.socket = null;
              void this.connect();
              return;
            }
            try {
              await socket.request({ ping: 1 }, 8_000);
            } catch {
              clearInterval(timer);
              socket.close();
              if (this.socket === socket) this.socket = null;
              void this.connect();
            }
          }, 25_000);
          return;
        } catch (error) {
          this.emit("feedError", error);
          this.reconnectAttempt += 1;
          const delay = Math.min(30_000, 500 * (2 ** Math.min(this.reconnectAttempt, 6))) + Math.floor(Math.random() * 300);
          if (attempts < 8) await new Promise((resolve) => setTimeout(resolve, delay));
        }
      }
    })().finally(() => {
      this.connecting = null;
      if (!this.stopped && !this.socket && !this.retryTimer) {
        this.retryTimer = setTimeout(() => {
          this.retryTimer = undefined;
          void this.connect();
        }, 30_000);
        this.retryTimer.unref();
      }
    });
    return this.connecting;
  }

  private async handleMessage(message: DerivMessage): Promise<void> {
    if (message.msg_type !== "tick" || !message.tick) return;
    const tick = message.tick;
    const symbol = String(tick.symbol ?? "");
    const quote = Number(tick.quote);
    const epoch = Number(tick.epoch);
    if (!symbol || !Number.isFinite(quote) || !Number.isInteger(epoch)) return;
    try {
      await pool.query(
        `INSERT INTO market_ticks(provider, symbol_code, quote, epoch)
         VALUES ('DERIV', $1, $2, $3)
         ON CONFLICT (provider, symbol_code, epoch, quote) DO NOTHING`,
        [symbol, quote, epoch]
      );
    } catch (error) {
      this.emit("feedError", error);
    }
    this.emit("tick", { symbol, quote, epoch, receivedAt: new Date().toISOString() });
  }
}

export const marketFeed = new DerivMarketFeed();
