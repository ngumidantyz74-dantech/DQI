import WebSocket from "ws";

export type DerivMessage = Record<string, any>;

export class DerivSocket {
  private ws: WebSocket;
  private nextId = 1;
  private pending = new Map<number, {
    resolve: (value: DerivMessage) => void;
    reject: (error: Error) => void;
    timer: NodeJS.Timeout;
  }>();
  private listeners = new Set<(message: DerivMessage) => void>();

  private constructor(url: string) {
    this.ws = new WebSocket(url, { handshakeTimeout: 10_000, perMessageDeflate: false });
    this.ws.on("message", (raw) => {
      let message: DerivMessage;
      try { message = JSON.parse(raw.toString()); } catch { return; }
      const id = message.req_id;
      if (typeof id === "number" && this.pending.has(id)) {
        const waiter = this.pending.get(id)!;
        clearTimeout(waiter.timer);
        this.pending.delete(id);
        if (message.error) waiter.reject(new Error(message.error.message ?? "Deriv WebSocket error"));
        else waiter.resolve(message);
      }
      for (const listener of this.listeners) listener(message);
    });
    this.ws.on("close", () => this.rejectAll(new Error("Deriv WebSocket closed")));
    this.ws.on("error", () => this.rejectAll(new Error("Deriv WebSocket transport error")));
  }

  static async connect(url: string): Promise<DerivSocket> {
    const socket = new DerivSocket(url);
    await new Promise<void>((resolve, reject) => {
      const timeout = setTimeout(() => reject(new Error("Deriv WebSocket open timeout")), 12_000);
      socket.ws.once("open", () => { clearTimeout(timeout); resolve(); });
      socket.ws.once("error", (error) => { clearTimeout(timeout); reject(error); });
    });
    return socket;
  }

  request(payload: Record<string, unknown>, timeoutMs = 12_000): Promise<DerivMessage> {
    if (this.ws.readyState !== WebSocket.OPEN) return Promise.reject(new Error("WebSocket is not open"));
    const reqId = this.nextId++;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pending.delete(reqId);
        reject(new Error("Deriv WebSocket request timed out"));
      }, timeoutMs);
      this.pending.set(reqId, { resolve, reject, timer });
      this.ws.send(JSON.stringify({ ...payload, req_id: reqId }));
    });
  }

  send(payload: Record<string, unknown>): void {
    if (this.ws.readyState !== WebSocket.OPEN) throw new Error("WebSocket is not open");
    this.ws.send(JSON.stringify(payload));
  }

  onMessage(listener: (message: DerivMessage) => void): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  isOpen(): boolean { return this.ws.readyState === WebSocket.OPEN; }

  isClosed(): boolean { return this.ws.readyState === WebSocket.CLOSED || this.ws.readyState === WebSocket.CLOSING; }

  close(): void {
    this.rejectAll(new Error("Socket closed by application"));
    this.ws.close();
  }

  private rejectAll(error: Error): void {
    for (const waiter of this.pending.values()) {
      clearTimeout(waiter.timer);
      waiter.reject(error);
    }
    this.pending.clear();
  }
}
