export type DerivAccountEnvironmentInput = {
  is_virtual?: number | boolean;
  account_type?: string;
  account_id?: string;
  loginid?: string;
};
