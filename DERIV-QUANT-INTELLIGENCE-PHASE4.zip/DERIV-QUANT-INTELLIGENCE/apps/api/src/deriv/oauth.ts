import { createHash } from "node:crypto";
import { config, assertDerivConfigured } from "../config.js";
import { encryptSecret, randomToken, sha256 } from "../security/crypto.js";
import { pool } from "../db/pool.js";
import { derivRequest } from "./rest.js";

type TokenResponse = {
  access_token: string;
  token_type: string;
  expires_in: number;
  scope?: string;
};

export function pkceChallenge(verifier: string): string {
  return createHash("sha256").update(verifier).digest("base64url");
}

export async function createOAuthStart(sessionId: string): Promise<string> {
  assertDerivConfigured();
  const verifier = randomToken(48);
  const state = randomToken(32);
  const redirectUri = config.DERIV_REDIRECT_URI!;

  await pool.query(
    `INSERT INTO deriv_oauth_transactions
       (session_id, state_hash, encrypted_code_verifier, redirect_uri, expires_at)
     VALUES ($1, $2, $3, $4, now() + interval '10 minutes')`,
    [sessionId, sha256(state), encryptSecret(verifier), redirectUri]
  );

  const url = new URL("/oauth2/auth", config.DERIV_AUTH_BASE_URL);
  url.searchParams.set("response_type", "code");
  url.searchParams.set("client_id", config.DERIV_CLIENT_ID!);
  url.searchParams.set("redirect_uri", redirectUri);
  url.searchParams.set("scope", config.DERIV_OAUTH_SCOPES);
  url.searchParams.set("state", state);
  url.searchParams.set("code_challenge", pkceChallenge(verifier));
  url.searchParams.set("code_challenge_method", "S256");
  return url.toString();
}

export async function completeOAuth(
  code: string,
  state: string,
  sessionId: string,
  ownerUserId: string
): Promise<{ credentialId: string; expiresAt: Date }> {
  assertDerivConfigured();

  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const tx = await client.query(
      `SELECT transaction_id, encrypted_code_verifier, redirect_uri
         FROM deriv_oauth_transactions
        WHERE session_id = $1 AND state_hash = $2
          AND consumed_at IS NULL AND expires_at > now()
        FOR UPDATE`,
      [sessionId, sha256(state)]
    );
    if (!tx.rowCount) throw new Error("OAuth state is invalid, expired, or already used");

    await client.query(
      "UPDATE deriv_oauth_transactions SET consumed_at = now() WHERE transaction_id = $1",
      [tx.rows[0].transaction_id]
    );
    await client.query("COMMIT");

    const verifier = (await import("../security/crypto.js")).decryptSecret(
      tx.rows[0].encrypted_code_verifier
    );

    const form = new URLSearchParams({
      grant_type: "authorization_code",
      client_id: config.DERIV_CLIENT_ID!,
      code,
      code_verifier: verifier,
      redirect_uri: tx.rows[0].redirect_uri
    });

    const response = await fetch(new URL("/oauth2/token", config.DERIV_AUTH_BASE_URL), {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded", "Accept": "application/json" },
      body: form,
      signal: AbortSignal.timeout(15_000)
    });
    if (!response.ok) throw new Error(`Deriv token exchange failed with HTTP ${response.status}`);
    const token = await response.json() as TokenResponse;
    if (!token.access_token || !Number.isFinite(token.expires_in) || token.expires_in <= 0) {
      throw new Error("Deriv returned an invalid OAuth token response");
    }

    const expiresAt = new Date(Date.now() + token.expires_in * 1000);
    const saved = await pool.query(
      `INSERT INTO deriv_credentials
         (owner_user_id, auth_method, encrypted_access_token, token_expires_at, scopes)
       VALUES ($1, 'OAUTH2', $2, $3, $4)
       RETURNING credential_id`,
      [ownerUserId, (await import("../security/crypto.js")).encryptSecret(token.access_token),
       expiresAt, config.DERIV_OAUTH_SCOPES.split(/\s+/).filter(Boolean)]
    );

    await pool.query(
      "UPDATE dqi_sessions SET deriv_credential_id = $1 WHERE session_id = $2",
      [saved.rows[0].credential_id, sessionId]
    );
    await pool.query(
      `INSERT INTO deriv_connection_events(owner_user_id, event_type, outcome, details)
       VALUES ($1, 'OAUTH_CONNECTED', 'SUCCESS', $2::jsonb)`,
      [ownerUserId, JSON.stringify({ expiresAt: expiresAt.toISOString(), scopes: config.DERIV_OAUTH_SCOPES.split(/\s+/) })]
    );

    return { credentialId: saved.rows[0].credential_id as string, expiresAt };
  } catch (error) {
    try { await client.query("ROLLBACK"); } catch { /* transaction may already be committed */ }
    throw error;
  } finally {
    client.release();
  }
}

export async function accessTokenForCredential(credentialId: string, ownerUserId: string): Promise<string> {
  const result = await pool.query(
    `SELECT encrypted_access_token, token_expires_at, status
       FROM deriv_credentials
      WHERE credential_id = $1 AND owner_user_id = $2`,
    [credentialId, ownerUserId]
  );
  if (!result.rowCount) throw new Error("Deriv credential not found");
  const credential = result.rows[0];
  if (credential.status !== "ACTIVE" || new Date(credential.token_expires_at).getTime() <= Date.now()) {
    await pool.query("UPDATE deriv_credentials SET status = 'EXPIRED' WHERE credential_id = $1", [credentialId]);
    throw new Error("Deriv access token expired. Reconnect through OAuth; Deriv does not issue refresh tokens.");
  }
  const { decryptSecret } = await import("../security/crypto.js");
  return decryptSecret(credential.encrypted_access_token);
}

export async function listDerivAccounts(accessToken: string) {
  return derivRequest<{ data?: unknown[]; accounts?: unknown[] }>(
    "/trading/v1/options/accounts", accessToken
  );
}
