import { config } from "../config.js";

export class DerivHttpError extends Error {
  constructor(public readonly status: number, message: string) {
    super(message);
    this.name = "DerivHttpError";
  }
}

export async function derivRequest<T>(
  path: string,
  accessToken: string,
  init: RequestInit = {}
): Promise<T> {
  const url = new URL(path, config.DERIV_API_BASE_URL);
  const headers = new Headers(init.headers);
  headers.set("Authorization", `Bearer ${accessToken}`);
  headers.set("Accept", "application/json");

  const response = await fetch(url, {
    ...init,
    headers,
    signal: init.signal ?? AbortSignal.timeout(15_000)
  });
  const text = await response.text();
  let body: unknown = {};
  try { body = text ? JSON.parse(text) : {}; } catch { body = { message: "Invalid JSON from Deriv" }; }

  if (!response.ok) {
    throw new DerivHttpError(response.status, `Deriv request failed with HTTP ${response.status}`);
  }
  return body as T;
}
