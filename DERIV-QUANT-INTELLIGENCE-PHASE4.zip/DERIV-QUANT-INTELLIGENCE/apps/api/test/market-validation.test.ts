import { describe, expect, it } from "vitest";

describe("market request validation", () => {
  it("accepts Deriv symbol format", () => {
    expect(/^[A-Za-z0-9_]{2,30}$/.test("1HZ100V")).toBe(true);
  });
  it("rejects path injection and query strings", () => {
    expect(/^[A-Za-z0-9_]{2,30}$/.test("../balance")).toBe(false);
    expect(/^[A-Za-z0-9_]{2,30}$/.test("R_100?x=1")).toBe(false);
  });
});
