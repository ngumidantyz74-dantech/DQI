import { describe, expect, it } from "vitest";
import { pkceChallenge } from "../src/deriv/oauth.js";

describe("Deriv OAuth PKCE", () => {
  it("generates a base64url SHA-256 challenge", () => {
    const challenge = pkceChallenge("a-code-verifier-that-is-long-enough-for-pkce");
    expect(challenge).toMatch(/^[A-Za-z0-9_-]{43}$/);
    expect(challenge).not.toContain("=");
    expect(pkceChallenge("same-verifier")).toBe(pkceChallenge("same-verifier"));
    expect(pkceChallenge("same-verifier")).not.toBe(pkceChallenge("different-verifier"));
  });
});
