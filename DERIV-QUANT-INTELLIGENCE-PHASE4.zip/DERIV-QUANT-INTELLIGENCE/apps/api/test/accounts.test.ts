import { describe, expect, it } from "vitest";
import { classifyAccountEnvironment, normalizeAccountType } from "../src/deriv/account-environment.js";

describe("Deriv environment classification", () => {
  it("classifies explicit virtual accounts as demo", () => {
    expect(classifyAccountEnvironment({ is_virtual: 1, account_id: "VRTC123" })).toBe("DEMO");
  });
  it("classifies explicit real accounts as real", () => {
    expect(classifyAccountEnvironment({ is_virtual: 0, account_type: "standard", account_id: "CR123" })).toBe("REAL");
  });
  it("does not guess when the broker response is ambiguous", () => {
    expect(classifyAccountEnvironment({ account_id: "UNKNOWN123" })).toBeNull();
  });
  it("maps provider account types to the database constraint", () => {
    expect(normalizeAccountType("demo")).toBe("VIRTUAL");
    expect(normalizeAccountType("financial")).toBe("FINANCIAL");
    expect(normalizeAccountType("unknown-value")).toBe("UNKNOWN");
  });
});
