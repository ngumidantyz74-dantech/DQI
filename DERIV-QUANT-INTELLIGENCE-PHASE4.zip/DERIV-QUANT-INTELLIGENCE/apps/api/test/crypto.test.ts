import { afterEach, describe, expect, it, vi } from "vitest";

describe("secret encryption", () => {
  afterEach(() => vi.unstubAllEnvs());

  it("encrypts and decrypts secrets with AES-256-GCM", async () => {
    vi.stubEnv("DQI_ENCRYPTION_KEY_BASE64", Buffer.alloc(32, 7).toString("base64"));
    vi.resetModules();
    const crypto = await import("../src/security/crypto.js");
    const encrypted = crypto.encryptSecret("sensitive-deriv-access-token");
    expect(encrypted).not.toContain("sensitive-deriv-access-token");
    expect(crypto.decryptSecret(encrypted)).toBe("sensitive-deriv-access-token");
  });

  it("rejects an invalid encryption key length", async () => {
    vi.stubEnv("DQI_ENCRYPTION_KEY_BASE64", Buffer.alloc(12, 1).toString("base64"));
    vi.resetModules();
    const crypto = await import("../src/security/crypto.js");
    expect(() => crypto.encryptSecret("secret")).toThrow(/exactly 32 bytes/);
  });
});
