import { afterEach, describe, expect, it, vi } from "vitest";
import { derivRequest, DerivHttpError } from "../src/deriv/rest.js";

afterEach(() => vi.unstubAllGlobals());

describe("Deriv REST client", () => {
  it("adds bearer authorization and parses JSON", async () => {
    const fetchMock = vi.fn().mockResolvedValue(new Response(JSON.stringify({ data: [1] }), { status: 200 }));
    vi.stubGlobal("fetch", fetchMock);
    const result = await derivRequest<{data:number[]}>("/trading/v1/options/accounts", "token-value");
    expect(result.data).toEqual([1]);
    const request = fetchMock.mock.calls[0][1] as RequestInit;
    expect(new Headers(request.headers).get("Authorization")).toBe("Bearer token-value");
  });

  it("throws a status-only error without leaking broker response body", async () => {
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue(new Response("secret upstream body", { status: 401 })));
    await expect(derivRequest("/private", "bad-token")).rejects.toBeInstanceOf(DerivHttpError);
    try { await derivRequest("/private", "bad-token"); } catch (error) {
      expect((error as Error).message).not.toContain("secret upstream body");
    }
  });
});
