import { afterEach, describe, expect, it } from "vitest";
import { WebSocketServer } from "ws";
import { DerivSocket } from "../src/deriv/websocket.js";

let server: WebSocketServer | undefined;
let port = 0;
afterEach(async () => {
  if (server) await new Promise<void>((resolve) => server!.close(() => resolve()));
  server = undefined;
});

describe("Deriv WebSocket transport", () => {
  it("correlates request responses by req_id", async () => {
    server = new WebSocketServer({ port: 0 });
    await new Promise<void>((resolve) => server!.once("listening", resolve));
    port = (server.address() as any).port;
    server.on("connection", (client) => client.on("message", (raw) => {
      const request = JSON.parse(raw.toString());
      client.send(JSON.stringify({ req_id: request.req_id, msg_type: "ping", ping: "pong" }));
    }));
    const socket = await DerivSocket.connect(`ws://127.0.0.1:${port}`);
    const response = await socket.request({ ping: 1 });
    expect(response.ping).toBe("pong");
    socket.close();
  });
});
