# DQI Phase 3 — Quantitative Intelligence Engine

## 1. Delivery scope

Phase 3 adds a separately deployable Quant Intelligence site and research API to the Phase 2 repository. It does not place, modify, or close trades. There are no buy/sell order endpoints, no Deriv trade-authorisation scope, and no order-execution code in this phase.

The separate site is served by `apps/quant-web` and its API by `services/quant`. Example production topology:

- Existing DQI account site: `https://app.example.com`
- Independent Quant workspace: `https://quant.example.com`
- Existing Phase 2 Node API: internal service `api:8080`
- Quant API: internal service `quant:8000`
- Quant web/Nginx: internal service `quant-web:80`
- PostgreSQL: shared Phase 2 database, private network only

The existing site has an **Open Quant Site** link. Configure its `VITE_QUANT_SITE_URL` build argument to the quant hostname. The Quant site is not embedded in the main application and can be deployed/scaled separately. The Quant web Nginx serves the SPA and reverse-proxies `/api/` to the private quant API, keeping the browser on one origin and the API off the public network.

## 2. Administrator-controlled access

The Quant site has a separate password gate. The administrator generates a PBKDF2-SHA256 password hash; the plaintext password is never stored in PostgreSQL or delivered to the browser.

Generate the hash in the quant service environment:

```bash
cd services/quant
python scripts_hash_password.py
```

Set the generated value as `QUANT_ADMIN_PASSWORD_HASH` in the deployment secret manager / `.env` file. Also set `QUANT_SESSION_SECRET` to at least 32 random characters. Never commit either value. Login issues a signed, HttpOnly, SameSite=Lax cookie; production must set `QUANT_COOKIE_SECURE=true` and serve the site over HTTPS. Failed logins are rate-limited in-process (8 attempts / 15 minutes per source IP); enforce an additional rate limit at the public reverse proxy/WAF when running multiple replicas. Password rotation is performed by generating a new hash and updating the deployment secret followed by a quant-service restart.

The Phase 2 Deriv OAuth credential remains encrypted and server-side in the existing API. Phase 3 market data uses Deriv's public market-data WebSocket endpoint and does not need the user's OAuth token. No Deriv access token or OTP is sent to the Quant browser.

## 3. Market data

The service discovers instruments dynamically from Deriv `active_symbols: "full"`; it does not rely on a hard-coded synthetic-index list. Returned symbols are cached for five minutes and synchronized to `market_symbols` when PostgreSQL is configured.

Supported public data operations:

- Active instrument discovery across the catalogue returned to the connected Deriv API application.
- Historical OHLC candles using `ticks_history` with candle style.
- Timeframes: M1, M5, M15, M30, H1, H4, D1.
- Live tick stream using the `/api/v1/quant/stream/{symbol}` WebSocket endpoint. The endpoint checks the signed Quant-site session cookie and persists received ticks to `market_ticks` when DB persistence is enabled.
- Scanner requests fan out with bounded concurrency (1–10 concurrent history requests, maximum 2,000 symbols per request).

Deriv API availability, application permissions, regional availability, symbol trading status, rate limits, and historical-data availability remain external dependencies. The API returns errors for symbols/history that Deriv does not provide; it does not fabricate data.

## 4. Quantitative engine

### Indicators

- SMA
- EMA
- RSI (Wilder smoothing)
- ATR (EMA-smoothed true range)
- Bollinger Bands and bandwidth
- MACD and signal histogram
- Rolling realized volatility

### Regimes and signals

Regime classifier labels: `TREND_UP`, `TREND_DOWN`, `RANGE`, `LOW_VOLATILITY_RANGE`, `HIGH_VOLATILITY`, and `INSUFFICIENT_DATA`. Signal score combines EMA alignment, RSI momentum, MACD histogram, and Bollinger midline location. It emits `BUY`, `SELL`, or `NEUTRAL` as a research signal only. High-volatility and insufficient-data regimes dampen the score.

### Confidence calibration

An untrained raw score is returned unchanged and labelled `UNTRAINED_RAW_SCORE`. It must not be interpreted as a win probability. The `/api/v1/quant/calibration/fit` endpoint fits Platt logistic calibration from at least 30 supplied labelled outcomes, persists the fitted slope/intercept and Brier score, and activates one calibration per model/timeframe. The training observations should be from a chronologically prior calibration sample; reserve a separate untouched holdout period to test calibration. Calibration quality can decay as market conditions change, so refit and validate by time period and regime. The initial default is deliberately untrained.

### Scanner and multi-timeframe analysis

- `POST /api/v1/quant/scan`: scans up to 500 supplied discovered symbols with bounded concurrency.
- `POST /api/v1/quant/analyze`: one instrument/timeframe technical analysis.
- `POST /api/v1/quant/multi-timeframe`: independent analysis across requested timeframes and weighted directional consensus.
- `WS /api/v1/quant/stream/{symbol}`: authenticated live ticks.

## 5. Backtesting and validation

`POST /api/v1/quant/backtest` provides a reproducible research harness with initial equity, fractional risk, fee rate, and slippage inputs. It calculates total return, maximum drawdown, trade count, win rate, profit factor, average trade P/L, Sharpe-like per-bar statistic, and ending equity. Signals use bars available at the signal time and enter on the next bar open; the current simple reference strategy exits at that bar's close. This is an illustrative benchmark, not a fully optimized or broker-faithful Deriv contract simulator.

`POST /api/v1/quant/walk-forward` uses rolling train/test windows and reports each out-of-sample fold. The current baseline selects a score threshold from the training window and evaluates only on the following test window. It does not yet optimize a large strategy parameter space. Use multiple symbols, timeframes, regimes, and untouched holdout periods; account for data snooping, survivorship, costs, and multiple testing before treating results as evidence.

## 6. API inventory

All `/api/v1/quant/*` endpoints below require the administrator password session, except the login/logout/session status endpoints.

| Method | Path | Purpose |
|---|---|---|
| GET | `/health` | Liveness |
| GET | `/ready` | Readiness and DB status |
| GET | `/api/v1/quant/session` | Session status |
| POST | `/api/v1/quant/auth/login` | Password login |
| POST | `/api/v1/quant/auth/logout` | Logout |
| GET | `/api/v1/quant/symbols` | Deriv active symbols; `?refresh=true` bypasses cache |
| POST | `/api/v1/quant/analyze` | Technical analysis and signal |
| POST | `/api/v1/quant/multi-timeframe` | Multi-timeframe consensus |
| POST | `/api/v1/quant/scan` | Market scanner |
| POST | `/api/v1/quant/calibration/fit` | Fit and persist confidence calibration |
| POST | `/api/v1/quant/backtest` | Historical simulation and metrics |
| POST | `/api/v1/quant/walk-forward` | Rolling out-of-sample validation |
| WS | `/api/v1/quant/stream/{symbol}` | Authenticated live tick stream |
| POST | `/api/v1/research/risk-preview` | Theoretical risk sizing preview |

## 7. Database migration

New migration: `database/migrations/0003_quant_intelligence.sql`

Creates:
- `quant_signals` — immutable signal analysis snapshots.
- `quant_backtests` — configuration, metrics, and full backtest result JSON.
- `quant_calibrations` — Platt parameters, sample count, Brier score, active model/timeframe.
- `quant_walk_forward_runs` — walk-forward configuration and fold results.

Existing Phase 2 `market_symbols` and `market_ticks` are reused. Apply migrations with the existing migration runner after building the API image:

```bash
docker compose exec api npm run db:migrate
```

The runner detects modified historical migrations by checksum. Do not edit an already-applied migration; add a new numbered migration instead.

## 8. Local deployment

1. Copy `.env.example` to `.env` and configure PostgreSQL/Redis passwords, Phase 2 Deriv OAuth values, encryption key and cookie/session secrets.
2. Generate the quant password hash as shown above. Set `QUANT_ADMIN_PASSWORD_HASH`, `QUANT_SESSION_SECRET`, `QUANT_COOKIE_SECURE=false` for local HTTP only, and `QUANT_ALLOWED_ORIGINS=http://localhost:5174`.
3. Set `VITE_QUANT_SITE_URL=http://localhost:5174`.
4. Build and start:

```bash
docker compose config
docker compose up --build -d
docker compose exec api npm run db:migrate
```

5. Open the existing DQI site at `http://localhost:5173`, choose **Open Quant Site**, and enter the administrator-set password. Direct local Quant URL: `http://localhost:5174`.

For cloud deployment, point `quant.example.com` at the host reverse proxy and route to `127.0.0.1:5174`; terminate TLS there. Set `QUANT_COOKIE_SECURE=true`, `QUANT_ALLOWED_ORIGINS=https://quant.example.com`, and rebuild the main web app with `VITE_QUANT_SITE_URL=https://quant.example.com`. Do not expose port 8000, PostgreSQL, or Redis publicly. Compose is a deployment starting point, not a substitute for managed secrets, backups, monitoring, WAF/rate limits, vulnerability scanning, and production load tests.

## 9. Verification and known limitations

Automated Python tests cover indicator calculations, OHLC validation, regime/signal shape, multi-timeframe consensus, confidence calibration, performance metrics, backtest, walk-forward folds, password hashing, signed sessions, login rate limiting, and auth boundaries. The suite can be run with:

```bash
cd services/quant
python -m pytest -q
```

The build image installs pinned dependencies including `asyncpg` and `websockets`. A local full Docker build, cloud hostname/TLS routing, PostgreSQL migration execution, Deriv live API request, and frontend package build must be run in the deployment environment; they cannot be certified from source-only tests. The public Deriv market-data integration is not a promise of uninterrupted feed availability.

No strategy can guarantee profit or eliminate losses. Backtests can overfit, signals can be wrong, spreads/slippage and contract settlement rules can change outcomes. Phase 3 is research/analytics only and intentionally has no trade execution functionality.
