# Phase 4 Acceptance Checklist

- [x] Paper-only directional simulation engine.
- [x] Server-side stake, expiry, open-position and daily-loss controls.
- [x] Fresh public Deriv quote at paper entry and explicit expiry settlement.
- [x] Paper account, position ledger, strategy metadata and equity snapshots.
- [x] Performance summary and equity-curve endpoint.
- [x] Quant-site Paper Trading workspace.
- [x] Explicit exclusion of Deriv trading endpoints and OAuth credentials.
- [x] Unit tests for risk validation, settlement and performance metrics.
- [ ] Apply migration 0004 to a real PostgreSQL instance.
- [ ] Run full Docker build and dependency-aware API/frontend checks.
- [ ] Verify public Deriv tick request/response in target network.
- [ ] Verify secure cookie and reverse-proxy configuration on the separate HTTPS Quant hostname.
