# DQI Phase 2 — Deriv API connectivity

## What this phase implements

- Deriv OAuth 2.0 Authorization Code with PKCE.
- State validation, one-use OAuth transactions and server-side code exchange.
- AES-256-GCM encryption for access tokens and PKCE verifier material.
- Session-bound Deriv connection for the single-operator Phase 2 deployment.
- Deriv Options account discovery and environment classification.
- Account ownership, exact OAuth-credential binding and requested DEMO/REAL environment checks.
- Actual broker-reported balance retrieval using account OTP and account-scoped WebSocket.
- Public WebSocket market symbol discovery, tick subscriptions and historical tick/candle requests.
- Tick persistence and Server-Sent Events (SSE) streaming to clients.
- OAuth expiration handling; reconnect requires the user to authorize again because Deriv OAuth does not issue refresh tokens.

## Deriv API facts used

Deriv currently documents OAuth Authorization Code + PKCE at:
https://developers.deriv.com/docs/intro/oauth/

- Authorization endpoint: `https://auth.deriv.com/oauth2/auth`
- Token endpoint: `https://auth.deriv.com/oauth2/token`
- API base: `https://api.derivws.com`
- Account list: `GET /trading/v1/options/accounts`
- Account WebSocket OTP: `POST /trading/v1/options/accounts/{accountId}/otp`
- Public WebSocket: `wss://api.derivws.com/trading/v1/options/ws/public`
- Account WebSocket endpoints are selected by Deriv from the OTP URL. OTPs are single-use and expire after 120 seconds.
- OAuth access token expiry is taken from `expires_in`. Deriv does not provide a refresh token for this third-party OAuth flow.
- `active_symbols`, `ticks`, and `ticks_history` are public market-data calls.

## Register a Deriv OAuth application

1. Register an OAuth 2.0 application in the Deriv developer dashboard.
2. Set its redirect URL to the exact value in `DERIV_REDIRECT_URI`.
3. Enable the `trade` scope for account list and OTP operations. Do not request `account_manage` or `payment` in this phase.
4. Copy the client ID into the server-side environment.
5. Never place the client ID secret material or access token in frontend source. OAuth token exchange is server-side.

## Required environment

```dotenv
DERIV_CLIENT_ID=your_registered_oauth_client_id
DERIV_REDIRECT_URI=https://your-domain.example/api/v1/auth/deriv/callback
DERIV_OAUTH_SCOPES=trade
DERIV_API_BASE_URL=https://api.derivws.com
DERIV_AUTH_BASE_URL=https://auth.deriv.com
DQI_ENCRYPTION_KEY_BASE64=base64_of_exactly_32_random_bytes
DQI_SESSION_SECRET=at_least_32_random_bytes
```

Generate secrets:

```bash
openssl rand -base64 32
openssl rand -hex 48
```

Store these values in your cloud secret manager. Do not commit them. Back up the encryption key separately: losing it makes stored tokens permanently undecryptable. Rotate keys only with a controlled decrypt/re-encrypt migration.

## Routes

### OAuth

- `GET /api/v1/auth/deriv/start` — creates a session if needed and returns an authorization URL. Browser must retain the signed `dqi_session` cookie.
- `GET /api/v1/auth/deriv/callback` — validates session + OAuth state and exchanges the code on the backend.
- `POST /api/v1/auth/deriv/disconnect` — revokes local credential use and clears the current session.

### Account information

- `GET /api/v1/deriv/connection`
- `GET /api/v1/deriv/accounts`
- `GET /api/v1/deriv/accounts/{internalAccountUuid}/balance?environment=DEMO`
- `GET /api/v1/deriv/accounts/{internalAccountUuid}/balance?environment=REAL`

The balance route requires the DQI session cookie and an explicit environment. It checks the selected internal account belongs to the current operator and that its environment matches the request.

### Market data

- `GET /api/v1/markets/symbols`
- `POST /api/v1/markets/subscribe` with `{"symbol":"R_100"}`
- `GET /api/v1/markets/history/R_100?count=500&style=candles&granularity=60`
- `GET /api/v1/markets/ticks/R_100`
- `GET /api/v1/markets/stream?symbol=R_100` — Server-Sent Events.

## Local flow

1. Apply migration 0002.
2. Start API, database and Redis.
3. Open `http://localhost:8080/api/v1/auth/deriv/start` in a browser. This sets the HttpOnly session cookie and returns an `authorizationUrl` JSON field.
4. Copy/open that URL in the same browser profile.
5. Approve the requested Deriv permissions.
6. Deriv redirects to the callback on localhost.
7. Call `/api/v1/deriv/accounts` in the same browser profile.
8. Select a returned internal account UUID and explicitly pass DEMO or REAL when requesting its balance.
9. Subscribe to a symbol and consume its SSE stream.

The Phase 2 starter UI includes a Connect Deriv action and account discovery list. The browser retains the signed HttpOnly DQI session cookie and returns to the dashboard after OAuth. Each discovered account has a Fetch balance action. The request includes the internal account UUID and explicit DEMO/REAL environment; the balance is fetched from Deriv on demand, never fabricated or inferred.

## Reconnection and market feed

The market feed reconnects to Deriv's public WebSocket with bounded exponential backoff and jitter. Desired tick symbols are re-subscribed after a reconnect. Each reconnect requests the active symbol catalogue again. Historical requests use bounded count and documented candle granularities.

Account balance reads request a fresh one-time OTP and close the account WebSocket after the balance response. A future persistent account monitor must obtain a new OTP after every reconnect; never cache or reuse OTP URLs.

## Phase 2 non-goals

- No proposal, buy, sell, contract update or trading execution endpoints.
- No deposits, withdrawals, transfers or account creation.
- No PAT token entry endpoint.
- No MT5 integration.
- No multi-tenant identity provider. This phase uses a single-operator bootstrap principal; production public access requires a full user identity and authorization layer.
- No claim that market data availability is guaranteed at all times.

## Production deployment notes

- Serve the callback only over HTTPS in cloud deployments. Keep the web UI and API on the same site (for example, app.example.com and api.example.com) so the HttpOnly SameSite=Lax session cookie works without weakening cookie policy.
- Set cookie secure mode through `NODE_ENV=production`.
- Configure exact CORS origin; do not use wildcard origins with credentials.
- Put API and quant services behind private networking. Do not expose PostgreSQL or Redis.
- Use managed PostgreSQL and Redis with TLS.
- Use a secret manager for encryption/session secrets.
- Add rate limiting, reverse-proxy request limits and observability before public exposure.
- Add a dedicated user authentication and authorization layer before multi-user operation.
- The included Phase 1 Compose environment remains a development deployment, not production certification. Phase 2 uses a single-operator bootstrap principal with per-browser sessions and per-session Deriv credential isolation; add a full DQI user identity provider and roles before offering public multi-user SaaS access.
