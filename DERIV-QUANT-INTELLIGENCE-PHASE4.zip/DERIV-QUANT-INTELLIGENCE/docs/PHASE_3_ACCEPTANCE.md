# DQI Phase 3 Acceptance Checklist

- [x] Independent Quant site application (`apps/quant-web`).
- [x] Main DQI site launches the separate Quant hostname via `VITE_QUANT_SITE_URL`.
- [x] Administrator-configured PBKDF2 password gate and signed HttpOnly session cookie.
- [x] Login throttling, logout, protected HTTP routes, and protected WebSocket route.
- [x] Deriv active-symbol discovery from public API.
- [x] Deriv OHLC historical candle retrieval for M1/M5/M15/M30/H1/H4/D1.
- [x] Authenticated live tick stream and optional PostgreSQL tick persistence.
- [x] Technical indicators, volatility estimates, and market regime classification.
- [x] Single-timeframe and multi-timeframe statistical signal generation.
- [x] Confidence calibration fit and persistence; untrained state explicitly marked.
- [x] Market scanner with bounded concurrency and 2,000-symbol request ceiling.
- [x] Backtesting interface, cost inputs, and performance metrics.
- [x] Rolling-origin walk-forward validation interface and persistence.
- [x] Phase 3 PostgreSQL migration.
- [x] Python test suite: 23 passed in local test environment.
- [x] TypeScript/TSX syntax transpilation: 27 files, zero syntax diagnostics.
- [x] Docker Compose YAML parsed successfully; six services declared.
- [x] Trade execution intentionally absent; trading flags remain disabled.

## Deployment acceptance still required

- [ ] Install pinned Python/npm dependencies in deployment build environment.
- [ ] Build all Docker images and run Compose health checks.
- [ ] Apply migrations against the target PostgreSQL instance.
- [ ] Configure HTTPS, public DNS, reverse proxy, WAF and secret manager.
- [ ] Verify Deriv active-symbol and candle requests with live network access.
- [ ] Verify authenticated WebSocket tick stream through the production proxy.
- [ ] Verify password rotation, backup/restore, monitoring and rate limits under multi-replica deployment.
