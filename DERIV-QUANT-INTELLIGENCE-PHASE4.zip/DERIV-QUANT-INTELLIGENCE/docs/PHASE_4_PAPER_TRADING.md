# DQI Phase 4 — Strategy Research and Paper Trading

## Scope
Phase 4 adds a paper-only research ledger to the independent Quant Intelligence service. It uses public Deriv quotes for paper-position entry and expiry settlement. It does not call `buy`, `sell`, `proposal`, `proposal_open_contract`, authenticated trading endpoints, Deriv OAuth credentials, or any live-account endpoint. It cannot place a real trade.

## Paper contract model
A paper position records a symbol, BUY/SELL direction, stake, entry quote, expiry timestamp, and an assumed fixed profit multiplier. At or after expiry, an operator explicitly requests settlement; the service obtains a fresh public Deriv tick and compares it with the entry quote. A favourable move wins the assumed profit multiplier; an unfavourable or flat move loses the stake. This is a deliberately transparent directional research abstraction, not a Deriv contract proposal, quoted payout, purchase, or exact broker settlement model. The expiry quote is the first fresh public tick obtained at settlement request time; it is not guaranteed to be the exact first tick at the expiry boundary.

## Risk controls
- Maximum stake is 2% of current paper equity per position.
- Maximum five open positions.
- Maximum realized daily loss is 5% of current equity; new positions are rejected after the threshold.
- Expiry range is 30 seconds to 24 hours.
- Stake is reserved from available paper balance while a position is open.
- Risk rejections are recorded in `paper_risk_events`.
- Closed outcomes and equity snapshots are persisted.

These controls are server-side. They are not broker controls and do not protect real money because no real money is involved.

## API (administrator session required)
- `GET /api/v1/paper/account` — create-on-first-access default paper account and return balances/metrics.
- `POST /api/v1/paper/account` — create a paper account if no active account exists.
- `GET /api/v1/paper/positions?status=ALL&limit=100` — position history.
- `POST /api/v1/paper/trades` — open a paper position using a fresh public Deriv quote.
- `POST /api/v1/paper/positions/{id}/settle` — settle an expired position using a fresh public quote.
- `GET /api/v1/paper/performance` — metrics and equity curve.
- `GET /api/v1/paper/strategies` — list research strategy definitions.
- `POST /api/v1/paper/strategies` — create a strategy definition. Creation does not enable autonomous execution.

## Database
Apply `database/migrations/0004_paper_trading.sql` after migrations 0001–0003. The migration creates paper accounts, strategy definitions, positions, equity snapshots and risk events.

## Deployment
The paper API remains part of the separately hosted Quant site and shares its administrator session. The existing main DQI application links to the Quant site; no new public route is required. Keep PostgreSQL and Quant API private behind the reverse proxy. Set HTTPS and `QUANT_COOKIE_SECURE=true` in production.

## Explicit exclusions
- No real account access or live-account credential use.
- No Deriv `proposal`, `buy`, `sell`, contract purchase or order management.
- No deposits, withdrawals, wallet movements or account balance changes.
- No autonomous strategy runner in this phase. Strategy records are research metadata; a human explicitly opens each paper position.
- Fixed payout assumptions are not live Deriv payouts. Results are not predictive or guaranteed.

## Verification
Run `python -m pytest -q` from `services/quant`. Run the full Docker build, migration, dependency-aware frontend/backend checks and live public-data smoke tests in the target deployment environment before production release.
