# Phase 1 acceptance checklist

## Repository
- [ ] Repository is initialized and pushed to a private Git remote.
- [ ] `.env` is ignored and `.env.example` contains placeholders only.
- [ ] Branch protection and CI checks are enabled.

## Runtime
- [ ] `docker compose config` succeeds.
- [ ] PostgreSQL health check passes.
- [ ] Redis health check passes.
- [ ] API `/health` returns HTTP 200.
- [ ] API `/ready` returns HTTP 200 when PostgreSQL and Redis are reachable.
- [ ] Quant `/health` returns HTTP 200.
- [ ] Web application loads on desktop and mobile viewport.

## Database
- [ ] Migration runner applies 0001.
- [ ] Re-running migrations skips already-applied migrations.
- [ ] A changed applied migration checksum causes a hard failure.
- [ ] Schema tables and indexes exist.

## Safety
- [ ] No Deriv tokens or passwords are present in repository history.
- [ ] API refuses to start if trading flags are enabled.
- [ ] No endpoint can place a trade in Phase 1.
- [ ] PostgreSQL and Redis are bound to localhost in the development Compose file.

## Tests
- [ ] API build and tests pass.
- [ ] Web build and tests pass.
- [ ] Quant tests pass.
