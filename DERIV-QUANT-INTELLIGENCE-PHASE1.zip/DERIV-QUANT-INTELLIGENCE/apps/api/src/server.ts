import "dotenv/config";
import Fastify from "fastify";
import cors from "@fastify/cors";
import { config } from "./config.js";
import { registerHealthRoutes } from "./health.js";
import { pool } from "./db/pool.js";

const app = Fastify({
  logger: {
    level: process.env.LOG_LEVEL ?? "info",
    redact: {
      paths: ["req.headers.authorization", "req.headers.cookie"],
      censor: "[REDACTED]"
    }
  },
  requestIdHeader: "x-request-id",
  genReqId: () => crypto.randomUUID()
});

await app.register(cors, {
  origin: config.WEB_ORIGIN,
  credentials: true
});

await registerHealthRoutes(app);

app.get("/api/v1", async () => ({
  name: "Deriv Quant Intelligence API",
  version: "0.1.0",
  phase: 1,
  capabilities: ["health", "readiness"],
  trading: {
    enabled: false,
    liveEnabled: false
  }
}));

const shutdown = async (signal: string) => {
  app.log.info({ signal }, "Shutting down DQI API");
  await app.close();
  await pool.end();
  process.exit(0);
};

process.on("SIGINT", () => void shutdown("SIGINT"));
process.on("SIGTERM", () => void shutdown("SIGTERM"));

try {
  await app.listen({ host: config.API_HOST, port: config.API_PORT });
} catch (error) {
  app.log.error(error);
  await pool.end();
  process.exit(1);
}
