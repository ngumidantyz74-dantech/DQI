import type { FastifyInstance } from "fastify";
import { pool } from "./db/pool.js";
import { createClient } from "redis";
import { config } from "./config.js";

export async function registerHealthRoutes(app: FastifyInstance): Promise<void> {
  app.get("/health", async (_request, reply) => {
    return reply.code(200).send({
      status: "ok",
      service: "dqi-api",
      tradingEnabled: false,
      liveTradingEnabled: false,
      timestamp: new Date().toISOString()
    });
  });

  app.get("/ready", async (_request, reply) => {
    const checks: Record<string, string> = {};
    try {
      await pool.query("SELECT 1");
      checks.database = "ok";
    } catch {
      checks.database = "error";
    }

    const redis = createClient({ url: config.REDIS_URL });
    redis.on("error", () => undefined);
    try {
      await redis.connect();
      await redis.ping();
      checks.redis = "ok";
    } catch {
      checks.redis = "error";
    } finally {
      if (redis.isOpen) await redis.quit();
    }

    const ready = Object.values(checks).every((value) => value === "ok");
    return reply.code(ready ? 200 : 503).send({
      status: ready ? "ready" : "not_ready",
      checks,
      timestamp: new Date().toISOString()
    });
  });
}
