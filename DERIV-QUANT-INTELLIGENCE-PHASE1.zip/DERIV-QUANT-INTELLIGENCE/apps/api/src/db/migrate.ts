import "dotenv/config";
import { createHash } from "node:crypto";
import { readdir, readFile } from "node:fs/promises";
import path from "node:path";
import pg from "pg";
import { config } from "../config.js";

const client = new pg.Client({ connectionString: config.DATABASE_URL });

async function main(): Promise<void> {
  await client.connect();
  await client.query(`
    CREATE TABLE IF NOT EXISTS schema_migrations (
      version varchar(255) PRIMARY KEY,
      applied_at timestamptz NOT NULL DEFAULT now(),
      checksum varchar(64) NOT NULL
    )
  `);

  const lockKey = 741920261;
  await client.query("SELECT pg_advisory_lock($1)", [lockKey]);

  try {
    const migrationDir = process.env.MIGRATIONS_DIR ?? path.resolve(process.cwd(), "../../database/migrations");
    const entries = (await readdir(migrationDir))
      .filter((name) => name.endsWith(".sql"))
      .sort();

    for (const name of entries) {
      const sql = await readFile(path.join(migrationDir, name), "utf8");
      const checksum = createHash("sha256").update(sql).digest("hex");
      const existing = await client.query(
        "SELECT checksum FROM schema_migrations WHERE version = $1",
        [name]
      );

      if (existing.rowCount) {
        if (existing.rows[0].checksum !== checksum) {
          throw new Error(`Applied migration was modified: ${name}. Create a new migration instead.`);
        }
        console.log(`SKIP ${name}`);
        continue;
      }

      await client.query("BEGIN");
      try {
        await client.query(sql);
        await client.query(
          "INSERT INTO schema_migrations(version, checksum) VALUES ($1, $2)",
          [name, checksum]
        );
        await client.query("COMMIT");
        console.log(`APPLIED ${name}`);
      } catch (error) {
        await client.query("ROLLBACK");
        throw error;
      }
    }
  } finally {
    await client.query("SELECT pg_advisory_unlock($1)", [lockKey]);
  }
}

main()
  .catch((error: unknown) => {
    console.error("Migration failed", error);
    process.exitCode = 1;
  })
  .finally(async () => {
    await client.end();
  });
