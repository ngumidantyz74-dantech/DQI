import { z } from "zod";

const schema = z.object({
  NODE_ENV: z.enum(["development", "test", "production"]).default("development"),
  API_HOST: z.string().default("0.0.0.0"),
  API_PORT: z.coerce.number().int().min(1).max(65535).default(8080),
  WEB_ORIGIN: z.string().url().default("http://localhost:5173"),
  DATABASE_URL: z.string().min(1),
  REDIS_URL: z.string().min(1),
  QUANT_BASE_URL: z.string().url().default("http://localhost:8000"),
  DQI_TRADING_ENABLED: z.string().default("false"),
  DQI_LIVE_TRADING_ENABLED: z.string().default("false")
});

export const config = schema.parse(process.env);

if (config.DQI_TRADING_ENABLED !== "false" || config.DQI_LIVE_TRADING_ENABLED !== "false") {
  throw new Error("Trading execution is not implemented in Phase 1; both trading flags must remain false.");
}
