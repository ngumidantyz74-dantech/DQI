import { describe, expect, it } from "vitest";

describe("Phase 1 safety defaults", () => {
  it("keeps real trading disabled in the foundation", () => {
    expect(process.env.DQI_TRADING_ENABLED ?? "false").toBe("false");
    expect(process.env.DQI_LIVE_TRADING_ENABLED ?? "false").toBe("false");
  });

  it("uses UTC-compatible ISO timestamps", () => {
    const timestamp = new Date().toISOString();
    expect(timestamp.endsWith("Z")).toBe(true);
  });
});
