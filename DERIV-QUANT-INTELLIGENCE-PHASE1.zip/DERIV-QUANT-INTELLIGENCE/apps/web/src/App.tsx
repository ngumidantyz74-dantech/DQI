import { useEffect, useState } from "react";

type ApiStatus = "checking" | "online" | "offline";

const API_BASE = import.meta.env.VITE_API_BASE_URL ?? "http://localhost:8080";

export function App() {
  const [apiStatus, setApiStatus] = useState<ApiStatus>("checking");

  useEffect(() => {
    let active = true;
    fetch(`${API_BASE}/health`)
      .then((response) => {
        if (!response.ok) throw new Error("API health check failed");
        return response.json();
      })
      .then(() => active && setApiStatus("online"))
      .catch(() => active && setApiStatus("offline"));
    return () => {
      active = false;
    };
  }, []);

  return (
    <main className="shell">
      <aside className="sidebar">
        <div className="brand"><span className="brand-mark">DQ</span><span>DERIV QUANT<br />INTELLIGENCE</span></div>
        <nav aria-label="Main navigation">
          {["Overview", "Markets", "Trading terminal", "AI signals", "Strategy lab", "Portfolio", "Risk centre", "Trade history", "Developer console"].map((item, index) => (
            <button className={index === 0 ? "nav-item active" : "nav-item"} key={item} type="button">
              <span className="nav-dot" />{item}
            </button>
          ))}
        </nav>
        <div className="sidebar-footer">PHASE 1 · FOUNDATION</div>
      </aside>

      <section className="content">
        <header className="topbar">
          <div><span className="eyebrow">QUANTITATIVE TRADING WORKSPACE</span><h1>Overview</h1></div>
          <div className="top-actions">
            <span className="mode-pill">DEMO-FIRST</span>
            <span className={`status ${apiStatus}`}>API {apiStatus}</span>
          </div>
        </header>

        <section className="notice">
          <strong>Research foundation only</strong>
          <span>Trading execution is disabled. No live account is connected and no market data is being represented as live.</span>
        </section>

        <section className="metric-grid" aria-label="Account metrics">
          {[
            ["Account balance", "—", "Connect account in Phase 2"],
            ["Equity", "—", "Awaiting authorized account data"],
            ["Today's P/L", "—", "No trades recorded"],
            ["Open positions", "0", "Execution not enabled"]
          ].map(([label, value, detail]) => (
            <article className="metric-card" key={label}>
              <span className="muted">{label}</span>
              <strong>{value}</strong>
              <small>{detail}</small>
            </article>
          ))}
        </section>

        <section className="main-grid">
          <article className="panel chart-panel">
            <div className="panel-heading"><div><span className="eyebrow">MARKET WORKSPACE</span><h2>Market intelligence</h2></div><span className="tag">DATA NOT CONNECTED</span></div>
            <div className="empty-chart">
              <div className="chart-icon">⌁</div>
              <strong>Market feed awaits integration</strong>
              <p>Phase 2 will connect authorized Deriv market streams and historical data.</p>
            </div>
          </article>
          <article className="panel">
            <div className="panel-heading"><div><span className="eyebrow">CAPITAL PROTECTION</span><h2>Risk guardian</h2></div><span className="safe">SAFE</span></div>
            <div className="risk-state"><span className="shield">✓</span><div><strong>Execution locked</strong><p>Trading and live trading flags are false.</p></div></div>
            <div className="rule-row"><span>Demo execution</span><b>Disabled</b></div>
            <div className="rule-row"><span>Real execution</span><b>Disabled</b></div>
            <div className="rule-row"><span>Emergency stop</span><b>Armed by default</b></div>
          </article>
        </section>

        <section className="panel bottom-panel">
          <div className="panel-heading"><div><span className="eyebrow">SYSTEM FOUNDATION</span><h2>Service health</h2></div></div>
          <div className="service-grid">
            <div><span className="service-indicator" />Web application <b>Running</b></div>
            <div><span className="service-indicator" />API <b>{apiStatus}</b></div>
            <div><span className="service-indicator pending" />Quant service <b>See service health</b></div>
            <div><span className="service-indicator pending" />Database <b>See API readiness</b></div>
          </div>
        </section>
        <footer>DQI v0.1.0 · Phase 1 foundation · Not financial advice · No trade execution</footer>
      </section>
    </main>
  );
}
