import { describe, expect, it } from "vitest";

describe("DQI web foundation", () => {
  it("keeps trading disabled in the Phase 1 product scope", () => {
    const tradingEnabled = false;
    const liveTradingEnabled = false;
    expect(tradingEnabled).toBe(false);
    expect(liveTradingEnabled).toBe(false);
  });
});
