from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_health_is_healthy_and_non_trading():
    response = client.get("/health")
    assert response.status_code == 200
    body = response.json()
    assert body["status"] == "ok"
    assert body["trading_enabled"] is False

def test_risk_preview_calculates_theoretical_size():
    response = client.post(
        "/api/v1/research/risk-preview",
        json={
            "equity": 1000,
            "risk_fraction": 0.005,
            "stop_distance": 10,
            "value_per_point": 1
        }
    )
    assert response.status_code == 200
    body = response.json()
    assert body["risk_amount"] == 5
    assert body["theoretical_size"] == 0.5
    assert "Not an order instruction" in body["disclaimer"]

def test_risk_preview_rejects_risk_above_one_percent():
    response = client.post(
        "/api/v1/research/risk-preview",
        json={
            "equity": 1000,
            "risk_fraction": 0.02,
            "stop_distance": 10,
            "value_per_point": 1
        }
    )
    assert response.status_code == 422
