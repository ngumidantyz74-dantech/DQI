import os
from datetime import datetime, timezone
from fastapi import FastAPI
from pydantic import BaseModel, Field

app = FastAPI(
    title="DQI Quant Service",
    version="0.1.0",
    description="Phase 1 research-service foundation. No trade execution is implemented."
)

class ServiceStatus(BaseModel):
    status: str
    service: str
    trading_enabled: bool
    timestamp: datetime

class RiskPreviewRequest(BaseModel):
    equity: float = Field(gt=0)
    risk_fraction: float = Field(gt=0, le=0.01)
    stop_distance: float = Field(gt=0)
    value_per_point: float = Field(gt=0)

class RiskPreviewResponse(BaseModel):
    risk_amount: float
    theoretical_size: float
    disclaimer: str

@app.get("/health", response_model=ServiceStatus)
async def health() -> ServiceStatus:
    return ServiceStatus(
        status="ok",
        service="dqi-quant",
        trading_enabled=False,
        timestamp=datetime.now(timezone.utc)
    )

@app.get("/ready")
async def ready() -> dict[str, str]:
    return {"status": "ready"}

@app.post("/api/v1/research/risk-preview", response_model=RiskPreviewResponse)
async def risk_preview(payload: RiskPreviewRequest) -> RiskPreviewResponse:
    risk_amount = payload.equity * payload.risk_fraction
    theoretical_size = risk_amount / (
        payload.stop_distance * payload.value_per_point
    )
    return RiskPreviewResponse(
        risk_amount=round(risk_amount, 8),
        theoretical_size=round(theoretical_size, 8),
        disclaimer=(
            "Research calculation only. Not an order instruction. "
            "Broker contract specifications, fees, slippage and volume constraints "
            "must be independently validated."
        )
    )
