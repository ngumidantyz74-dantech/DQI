# DERIV QUANT INTELLIGENCE (DQI)

Cloud-first quantitative trading research and execution platform foundation.

## Phase 1 scope

- React + TypeScript web application.
- Fastify + TypeScript API.
- FastAPI quantitative service.
- PostgreSQL schema and SQL migration runner.
- Redis connectivity.
- Docker Compose development environment.
- Unit, integration and health tests.
- GitHub Actions CI.

This phase does **not** connect to a live Deriv account or place trades. The API has no live execution endpoint. Deriv credentials must not be added until the dedicated authentication and integration phases.

## Architecture

```text
Browser / Android
       |
       v
 React + Vite web app
       |
       v
 Fastify API -------- PostgreSQL
       |              Redis
       |
       +------------ FastAPI quant service

Future separate integration:
Windows/VPS MT5 terminal <-> authenticated outbound MT5 bridge
```

## Prerequisites

- Docker Desktop / Docker Engine with Compose plugin.
- Node.js 22 LTS and npm 10+ (for running the web/API outside Docker).
- Python 3.12+ (for running the quant service outside Docker).
- Git.

## Quick start (Docker)

1. Copy `.env.example` to `.env`.
2. Replace every development password/secret before exposing any service.
3. Start services:

```bash
docker compose up --build -d
docker compose ps
```

4. Run database migrations:

```bash
docker compose exec api npm run db:migrate
```

5. Verify:

```bash
curl http://localhost:8080/health
curl http://localhost:8000/health
```

Web app: http://localhost:5173  
API: http://localhost:8080  
Quant service: http://localhost:8000  
PostgreSQL: localhost:5432 (development only)  
Redis: localhost:6379 (development only)

## Local development

### API

```bash
cd apps/api
npm install
npm run build
npm run db:migrate
npm run dev
```

### Web

```bash
cd apps/web
npm install
npm run dev
```

### Quant service

```bash
cd services/quant
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/macOS/Termux: source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

Set the environment variables in the root `.env` or export equivalent values for local processes.

## Tests

```bash
# API
cd apps/api && npm install && npm test

# Web
cd apps/web && npm install && npm test

# Quant
cd services/quant
pip install -r requirements.txt
pytest
```

## Database migrations

Migrations are SQL files in `database/migrations`. They are applied in lexical order and recorded in `schema_migrations`. A migration is run once. The migration runner uses a PostgreSQL advisory lock to prevent concurrent migration processes.

## Cloud deployment baseline

For production, use managed PostgreSQL and Redis, a container platform, HTTPS ingress, a secret manager, encrypted backups, centralized logs and alerting. Do not expose PostgreSQL or Redis publicly. The included Compose file is for development and smoke testing, not a complete production hosting configuration.

Recommended deployment units:
- `web`: static frontend behind CDN/HTTPS.
- `api`: private container service behind HTTPS ingress.
- `quant`: private container service reachable only by API/worker network.
- PostgreSQL: managed private database.
- Redis: managed private cache.
- MT5 bridge: separate Windows VPS/PC service, introduced in a later phase.

## Security rules

- Never commit `.env`, API tokens, passwords, OAuth secrets, OTPs or private keys.
- Do not store Deriv account passwords.
- Use separate demo and real credentials and permissions.
- Live execution must remain disabled until separately implemented, reviewed and explicitly authorized.
- Treat market data and model signals as untrusted inputs.
- Do not assume a signal or model confidence is a guarantee of profit.

## Project conventions

- TypeScript strict mode.
- Python type hints.
- UTC timestamps.
- Database migrations are append-only after deployment.
- Every future order command must have an idempotency key and audit record.
- Demo and real account contexts must never share execution credentials.

## License

Private project. Add an appropriate license before public distribution.


## Phase 2 — Deriv connectivity

See `docs/PHASE_2_DERIV_CONNECTIVITY.md` for OAuth registration, environment variables, routes, and operational notes.

Apply the new migration:

```bash
docker compose exec api npm run db:migrate
```

Configure the Phase 2 Deriv OAuth values in `.env` and recreate the API:

```bash
docker compose up --build -d api
```

OAuth uses Authorization Code + PKCE. Deriv access tokens are encrypted with AES-256-GCM and are never sent to the browser. Deriv OAuth does not issue refresh tokens; users must reconnect after expiry.

Phase 2 adds account discovery, balance retrieval, market symbols, tick streaming and historical market data. It deliberately adds no trade execution.

## Phase 3 — Independent Quant Intelligence site

Phase 3 adds a separately hosted quant workspace. See [`docs/PHASE_3_QUANT_INTELLIGENCE.md`](docs/PHASE_3_QUANT_INTELLIGENCE.md) for the full architecture, API reference, security configuration, database migration, testing and deployment guide.

- Main DQI site: `http://localhost:5173`
- Separate Quant site: `http://localhost:5174`
- Quant API (private in production): `http://quant:8000`
- New migration: `database/migrations/0003_quant_intelligence.sql`

The administrator must generate and configure `QUANT_ADMIN_PASSWORD_HASH` and `QUANT_SESSION_SECRET`. The main site opens the independent Quant site; the Quant site itself requires the admin-set password. Phase 3 includes Deriv active-symbol discovery, OHLC history, authenticated live tick streaming, technical analysis, market scanning, multi-timeframe consensus, confidence calibration, backtesting, walk-forward validation, and performance metrics. It does not execute trades.
