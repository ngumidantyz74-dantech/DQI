from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_health_is_healthy_and_non_trading():
    response = client.get("/health")
    assert response.status_code == 200
    body = response.json()
    assert body["status"] == "ok"
    assert body["trading_enabled"] is False

def test_protected_quant_endpoint_requires_login():
    assert client.get("/api/v1/quant/symbols").status_code == 401
