from __future__ import annotations
import asyncio, os, time
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from typing import Any
from fastapi import FastAPI, HTTPException, Request, Response, Depends, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from .security import COOKIE_NAME, create_session, hash_password, require_session, set_session_cookie, verify_password, valid_session
from .engine.analysis import analyze_candles, multi_timeframe, calibrate_confidence, fit_platt_calibration, TIMEFRAMES
from .engine.backtest import BacktestConfig, run_backtest, walk_forward
from .engine.deriv import discover_symbols, fetch_candles, WS_URL
import json
import websockets

DB_POOL: Any = None
SYMBOL_CACHE: dict[str,Any] = {"items":[],"at":0.0}
LOGIN_ATTEMPTS: dict[str,list[float]] = {}

@asynccontextmanager
async def lifespan(_: FastAPI):
    global DB_POOL
    database_url=os.getenv("DATABASE_URL")
    if database_url:
        import asyncpg
        DB_POOL=await asyncpg.create_pool(database_url,min_size=1,max_size=int(os.getenv("QUANT_DB_POOL_MAX","10")))
    yield
    if DB_POOL: await DB_POOL.close(); DB_POOL=None

app=FastAPI(title="DQI Quant Intelligence",version="3.0.0",description="Independent quantitative research and analytics service. Trade execution is intentionally unavailable.",lifespan=lifespan)
origins=[x.strip() for x in os.getenv("QUANT_ALLOWED_ORIGINS","https://quant.example.com").split(",") if x.strip()]
app.add_middleware(CORSMiddleware,allow_origins=origins,allow_credentials=True,allow_methods=["GET","POST"],allow_headers=["Content-Type","X-Requested-With"])

class LoginRequest(BaseModel): password: str = Field(min_length=1,max_length=256)
class AnalyzeRequest(BaseModel): symbol: str = Field(pattern=r"^[A-Za-z0-9_]{2,30}$"); timeframe: str; count: int=Field(default=500,ge=35,le=5000)
class MultiRequest(BaseModel): symbol: str=Field(pattern=r"^[A-Za-z0-9_]{2,30}$"); timeframes: list[str]=Field(default_factory=lambda:["M5","M15","H1"],min_length=1,max_length=7); count: int=Field(default=500,ge=35,le=2000)
class ScanRequest(BaseModel): symbols: list[str]=Field(min_length=1,max_length=2000); timeframe: str="M15"; count: int=Field(default=250,ge=35,le=1000); concurrency: int=Field(default=5,ge=1,le=10)
class BacktestRequest(BaseModel): symbol: str; timeframe: str; count: int=Field(default=1000,ge=36,le=5000); initial_equity: float=Field(default=10000,gt=0); risk_fraction: float=Field(default=0.005,gt=0,le=0.02); fee_rate: float=Field(default=0,ge=0,le=0.05); slippage_bps: float=Field(default=0,ge=0,le=500)
class WalkForwardRequest(BaseModel): symbol: str; timeframe: str; count: int=Field(default=2000,ge=200,le=5000); train_size: int=Field(default=500,ge=100); test_size: int=Field(default=100,ge=20); step: int=Field(default=100,ge=1)
class CalibrationObservation(BaseModel): confidence: float=Field(gt=0,lt=1); outcome: int=Field(ge=0,le=1)
class CalibrationFitRequest(BaseModel): timeframe: str; observations: list[CalibrationObservation]=Field(min_length=30,max_length=10000)
class RiskPreviewRequest(BaseModel): equity: float=Field(gt=0); risk_fraction: float=Field(gt=0,le=0.02); stop_distance: float=Field(gt=0); value_per_point: float=Field(gt=0)

@app.get("/health")
async def health(): return {"status":"ok","service":"dqi-quant","version":"3.0.0","trading_enabled":False,"timestamp":datetime.now(timezone.utc).isoformat()}
@app.get("/ready")
async def ready(): return {"status":"ready","database":bool(DB_POOL)}
@app.get("/api/v1/quant/session")
async def session_status(request: Request): return {"authenticated":valid_session(request.cookies.get(COOKIE_NAME))}
@app.post("/api/v1/quant/auth/login")
async def login(payload: LoginRequest,response: Response,request: Request):
    client_ip=request.headers.get("x-real-ip") or (request.client.host if request.client else "unknown")
    now=time.time()
    recent=[stamp for stamp in LOGIN_ATTEMPTS.get(client_ip,[]) if now-stamp<900]
    if len(recent)>=8:
        raise HTTPException(429,"Too many login attempts. Try again in 15 minutes.")
    encoded=os.getenv("QUANT_ADMIN_PASSWORD_HASH","")
    if not encoded: raise HTTPException(503,"Administrator has not configured the quant-site password")
    if not verify_password(payload.password,encoded):
        # Constant-work dummy PBKDF2 verification reduces user/password timing differences.
        verify_password(payload.password,"pbkdf2_sha256$310000$c2FsdHNhbHRzYWx0c2FsdA==$AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=")
        recent.append(now); LOGIN_ATTEMPTS[client_ip]=recent
        raise HTTPException(401,"Invalid access password")
    LOGIN_ATTEMPTS.pop(client_ip,None)
    set_session_cookie(response,create_session()); return {"authenticated":True,"expires_in":int(os.getenv("QUANT_SESSION_TTL_SECONDS","28800"))}
@app.post("/api/v1/quant/auth/logout")
async def logout(response: Response):
    response.delete_cookie(COOKIE_NAME,path="/",secure=os.getenv("QUANT_COOKIE_SECURE","true").lower()=="true",httponly=True,samesite="lax"); return {"authenticated":False}

@app.get("/api/v1/quant/symbols")
async def symbols(_: None=Depends(require_session),refresh: bool=False):
    if not refresh and SYMBOL_CACHE["items"] and time.time()-SYMBOL_CACHE["at"]<300: return {"symbols":SYMBOL_CACHE["items"],"cached":True}
    try: items=await discover_symbols()
    except Exception as exc: raise HTTPException(502,f"Deriv symbol discovery failed: {str(exc)[:180]}")
    SYMBOL_CACHE.update(items=items,at=time.time())
    if DB_POOL:
        async with DB_POOL.acquire() as conn:
            async with conn.transaction():
                await conn.execute("UPDATE market_symbols SET is_active=false WHERE provider='DERIV'")
                for item in items:
                    code=item.get("symbol")
                    if code: await conn.execute("""INSERT INTO market_symbols(provider,symbol_code,display_name,market_category,is_active,metadata) VALUES('DERIV',$1,$2,$3,true,$4::jsonb) ON CONFLICT(provider,symbol_code) DO UPDATE SET display_name=excluded.display_name,market_category=excluded.market_category,is_active=true,metadata=excluded.metadata""",code,item.get("display_name",code),item.get("market_display_name",item.get("market","UNKNOWN")),__import__('json').dumps(item))
    return {"symbols":items,"cached":False}

async def get_candles(symbol: str,timeframe: str,count: int):
    if timeframe not in TIMEFRAMES: raise HTTPException(422,"Unsupported timeframe")
    try: return await fetch_candles(symbol,TIMEFRAMES[timeframe],count)
    except Exception as exc: raise HTTPException(502,f"Deriv history request failed: {str(exc)[:180]}")

async def get_active_calibration(timeframe: str) -> dict | None:
    if not DB_POOL: return None
    async with DB_POOL.acquire() as conn:
        row=await conn.fetchrow("SELECT slope,intercept FROM quant_calibrations WHERE model_name='dqi_signal_v1' AND timeframe=$1 AND is_active=true",timeframe)
    return {"slope":float(row['slope']),"intercept":float(row['intercept'])} if row else None

@app.post("/api/v1/quant/calibration/fit")
async def fit_calibration(payload: CalibrationFitRequest,_: None=Depends(require_session)):
    if payload.timeframe not in TIMEFRAMES: raise HTTPException(422,"Unsupported timeframe")
    try: fitted=fit_platt_calibration([x.model_dump() for x in payload.observations])
    except ValueError as exc: raise HTTPException(422,str(exc))
    if not DB_POOL: raise HTTPException(503,"Calibration persistence requires the Phase 3 database migration and DATABASE_URL")
    async with DB_POOL.acquire() as conn:
        async with conn.transaction():
            await conn.execute("UPDATE quant_calibrations SET is_active=false WHERE model_name='dqi_signal_v1' AND timeframe=$1",payload.timeframe)
            await conn.execute("INSERT INTO quant_calibrations(model_name,timeframe,slope,intercept,sample_count,brier_score,is_active) VALUES('dqi_signal_v1',$1,$2,$3,$4,$5,true)",payload.timeframe,fitted['slope'],fitted['intercept'],fitted['sample_count'],fitted['brier_score'])
    return {**fitted,"timeframe":payload.timeframe,"status":"ACTIVE","note":"Fit from supplied labelled historical outcomes. Validate on a separate holdout set before relying on the model."}

@app.post("/api/v1/quant/analyze")
async def analyze(payload: AnalyzeRequest,_: None=Depends(require_session)):
    candles=await get_candles(payload.symbol,payload.timeframe,payload.count)
    try: result=analyze_candles(payload.symbol,payload.timeframe,candles)
    except ValueError as exc: raise HTTPException(422,str(exc))
    calibration=await get_active_calibration(payload.timeframe)
    result["calibrated_confidence"]=calibrate_confidence(result["raw_confidence"],calibration)
    result["calibration_status"]="EMPIRICALLY_FITTED" if calibration else "UNTRAINED_RAW_SCORE"
    if DB_POOL:
        async with DB_POOL.acquire() as conn:
            await conn.execute("INSERT INTO quant_signals(provider,symbol_code,timeframe,direction,raw_confidence,calibrated_confidence,score,regime,analysis) VALUES('DERIV',$1,$2,$3,$4,$5,$6,$7,$8::jsonb)",payload.symbol,payload.timeframe,result['direction'],result['raw_confidence'],result['calibrated_confidence'],result['score'],result['regime'],__import__('json').dumps(result))
    return result

@app.post("/api/v1/quant/multi-timeframe")
async def multi(payload: MultiRequest,_: None=Depends(require_session)):
    if any(tf not in TIMEFRAMES for tf in payload.timeframes): raise HTTPException(422,"Unsupported timeframe requested")
    sem=asyncio.Semaphore(4)
    async def one(tf):
        async with sem: return tf,await get_candles(payload.symbol,tf,payload.count)
    data=dict(await asyncio.gather(*(one(tf) for tf in payload.timeframes)))
    try: return multi_timeframe(payload.symbol,data)
    except ValueError as exc: raise HTTPException(422,str(exc))

@app.post("/api/v1/quant/scan")
async def scan(payload: ScanRequest,_: None=Depends(require_session)):
    if payload.timeframe not in TIMEFRAMES: raise HTTPException(422,"Unsupported timeframe")
    sem=asyncio.Semaphore(payload.concurrency)
    async def one(symbol):
        async with sem:
            try:
                candles=await get_candles(symbol,payload.timeframe,payload.count)
                result=analyze_candles(symbol,payload.timeframe,candles)
                calibration=await get_active_calibration(payload.timeframe)
                result['calibrated_confidence']=calibrate_confidence(result['raw_confidence'],calibration)
                result['calibration_status']='EMPIRICALLY_FITTED' if calibration else 'UNTRAINED_RAW_SCORE'
                return result
            except Exception as exc: return {"symbol":symbol,"error":str(exc)[:180]}
    results=await asyncio.gather(*(one(s) for s in dict.fromkeys(payload.symbols)))
    return {"scanned":len(results),"results":sorted(results,key=lambda x:x.get('calibrated_confidence',0),reverse=True)}

@app.post("/api/v1/quant/backtest")
async def backtest(payload: BacktestRequest,_: None=Depends(require_session)):
    candles=await get_candles(payload.symbol,payload.timeframe,payload.count)
    try:
        result=run_backtest(payload.symbol,payload.timeframe,candles,BacktestConfig(payload.initial_equity,payload.risk_fraction,payload.fee_rate,payload.slippage_bps))
    except ValueError as exc: raise HTTPException(422,str(exc))
    if DB_POOL:
        async with DB_POOL.acquire() as conn: await conn.execute("INSERT INTO quant_backtests(symbol_code,timeframe,configuration,metrics,result) VALUES($1,$2,$3::jsonb,$4::jsonb,$5::jsonb)",payload.symbol,payload.timeframe,payload.model_dump_json(),__import__('json').dumps(result['metrics']),__import__('json').dumps(result))
    return result

@app.post("/api/v1/quant/walk-forward")
async def walkforward(payload: WalkForwardRequest,_: None=Depends(require_session)):
    candles=await get_candles(payload.symbol,payload.timeframe,payload.count)
    try: result=walk_forward(payload.symbol,payload.timeframe,candles,payload.train_size,payload.test_size,payload.step)
    except ValueError as exc: raise HTTPException(422,str(exc))
    if DB_POOL:
        async with DB_POOL.acquire() as conn:
            await conn.execute("INSERT INTO quant_walk_forward_runs(symbol_code,timeframe,configuration,result) VALUES($1,$2,$3::jsonb,$4::jsonb)",payload.symbol,payload.timeframe,payload.model_dump_json(),json.dumps(result))
    return result

@app.websocket("/api/v1/quant/stream/{symbol}")
async def tick_stream(websocket: WebSocket, symbol: str):
    if not valid_session(websocket.cookies.get(COOKIE_NAME)):
        await websocket.close(code=4401, reason="Authentication required")
        return
    if not __import__("re").fullmatch(r"[A-Za-z0-9_]{2,30}", symbol):
        await websocket.close(code=4400, reason="Invalid symbol")
        return
    await websocket.accept()
    try:
        async with websockets.connect(WS_URL, open_timeout=10, close_timeout=3, ping_interval=20, ping_timeout=20) as deriv_ws:
            await deriv_ws.send(json.dumps({"ticks":symbol,"subscribe":1}))
            while True:
                try:
                    message=json.loads(await asyncio.wait_for(deriv_ws.recv(),timeout=30))
                    if message.get("error"):
                        await websocket.send_json({"type":"error","message":message["error"].get("message","Deriv stream error")})
                        break
                    if message.get("msg_type")=="tick":
                        tick=message.get("tick",{})
                        payload={"type":"tick","symbol":tick.get("symbol"),"quote":tick.get("quote"),"epoch":tick.get("epoch"),"received_at":datetime.now(timezone.utc).isoformat()}
                        if DB_POOL and payload["quote"] is not None and payload["epoch"] is not None:
                            async with DB_POOL.acquire() as conn:
                                await conn.execute("INSERT INTO market_ticks(provider,symbol_code,quote,epoch) VALUES('DERIV',$1,$2,$3) ON CONFLICT(provider,symbol_code,epoch,quote) DO NOTHING",symbol,float(payload["quote"]),int(payload["epoch"]))
                        await websocket.send_json(payload)
                except asyncio.TimeoutError:
                    await deriv_ws.send(json.dumps({"ping":1}))
    except WebSocketDisconnect:
        pass
    except Exception as exc:
        try: await websocket.send_json({"type":"error","message":str(exc)[:160]})
        except Exception: pass
    finally:
        try: await websocket.close()
        except Exception: pass

@app.post("/api/v1/research/risk-preview")
async def risk_preview(payload: RiskPreviewRequest,_: None=Depends(require_session)):
    risk=payload.equity*payload.risk_fraction
    return {"risk_amount":round(risk,8),"theoretical_size":round(risk/(payload.stop_distance*payload.value_per_point),8),"disclaimer":"Research calculation only. Not an order instruction. Broker contract specifications, fees, slippage and volume constraints must be independently validated."}
