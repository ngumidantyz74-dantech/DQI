import "dotenv/config";
import Fastify from "fastify";
import cors from "@fastify/cors";
import cookie from "@fastify/cookie";
import { registerDerivRoutes } from "./routes/deriv.js";
import { marketFeed } from "./deriv/market.js";
import { config } from "./config.js";
import { registerHealthRoutes } from "./health.js";
import { registerExecutionRoutes } from "./routes/execution.js";
import { pool } from "./db/pool.js";

const app = Fastify({
  logger: {
    level: process.env.LOG_LEVEL ?? "info",
    redact: {
      paths: ["req.headers.authorization", "req.headers.cookie", "req.url"],
      censor: "[REDACTED]"
    }
  },
  requestIdHeader: "x-request-id",
  genReqId: () => crypto.randomUUID()
});

await app.register(cookie, { secret: config.DQI_SESSION_SECRET && config.DQI_SESSION_SECRET.length >= 32 ? config.DQI_SESSION_SECRET : "development-only-cookie-secret-change-me-32chars" });

await app.register(cors, {
  origin: config.WEB_ORIGIN,
  credentials: true
});

await registerHealthRoutes(app);
await registerDerivRoutes(app);
await registerExecutionRoutes(app);

app.get("/api/v1", async () => ({
  name: "Deriv Quant Intelligence API",
  version: "0.6.0",
  phase: 6,
  capabilities: ["health", "readiness", "deriv-oauth", "account-discovery", "account-balance", "market-symbols", "market-ticks", "market-history", "live-proposal", "manual-live-approval", "execution-audit"],
  trading: { enabled: config.DQI_LIVE_TRADING_ENABLED === "true", automationEnabled: false, manualApprovalRequired: true }
}));

const shutdown = async (signal: string) => {
  app.log.info({ signal }, "Shutting down DQI API");
  await marketFeed.stop();
  await app.close();
  await pool.end();
  process.exit(0);
};

process.on("SIGINT", () => void shutdown("SIGINT"));
process.on("SIGTERM", () => void shutdown("SIGTERM"));

try {
  await app.listen({ host: config.API_HOST, port: config.API_PORT });
} catch (error) {
  app.log.error(error);
  await pool.end();
  process.exit(1);
}
