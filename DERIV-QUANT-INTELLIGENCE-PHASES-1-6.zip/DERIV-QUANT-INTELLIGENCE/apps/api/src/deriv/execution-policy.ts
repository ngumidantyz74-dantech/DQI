export type DailyRiskDecision = {
  allowed: boolean;
  lossSoFar: number;
  remainingBudget: number;
  reason: string | null;
};

export function evaluateDailyRisk(
  openingBalance: number,
  currentBalance: number,
  maxDailyLoss: number,
  proposedStake: number,
  halted: boolean
): DailyRiskDecision {
  const values = [openingBalance, currentBalance, maxDailyLoss, proposedStake];
  if (values.some((value) => !Number.isFinite(value)) || openingBalance < 0 || currentBalance < 0 || maxDailyLoss <= 0 || proposedStake <= 0) {
    throw new Error("Invalid daily risk values");
  }
  const lossSoFar = Math.max(0, openingBalance - currentBalance);
  const remainingBudget = Math.max(0, maxDailyLoss - lossSoFar);
  if (halted) return { allowed: false, lossSoFar, remainingBudget, reason: "DAILY_RISK_HALTED" };
  if (remainingBudget <= 0) return { allowed: false, lossSoFar, remainingBudget, reason: "DAILY_LOSS_LIMIT_REACHED" };
  if (proposedStake > remainingBudget) return { allowed: false, lossSoFar, remainingBudget, reason: "STAKE_EXCEEDS_REMAINING_DAILY_RISK" };
  return { allowed: true, lossSoFar, remainingBudget, reason: null };
}

export function isAmbiguousExecutionFailure(message: string): boolean {
  return /timed out|closed|transport|socket|connection reset|econnreset/i.test(message);
}

export function canApproveLiveIntent(input: {
  deploymentEnabled: boolean;
  databaseEnabled: boolean;
  killSwitch: boolean;
  manualApprovalRequired: boolean;
  intentPending: boolean;
  quoteExpiresAt: number;
  now?: number;
}): { allowed: boolean; reason: string | null } {
  if (!input.deploymentEnabled) return { allowed: false, reason: "DEPLOYMENT_DISABLED" };
  if (!input.databaseEnabled) return { allowed: false, reason: "LIVE_DISABLED" };
  if (input.killSwitch) return { allowed: false, reason: "KILL_SWITCH_ACTIVE" };
  if (!input.manualApprovalRequired) return { allowed: false, reason: "MANUAL_APPROVAL_POLICY_REQUIRED" };
  if (!input.intentPending) return { allowed: false, reason: "INTENT_NOT_PENDING" };
  if (input.quoteExpiresAt <= (input.now ?? Date.now())) return { allowed: false, reason: "QUOTE_EXPIRED" };
  return { allowed: true, reason: null };
}
