import type { FastifyInstance } from "fastify";
import { z } from "zod";
import { pool } from "../db/pool.js";
import { config } from "../config.js";
import { requireSession } from "../security/session.js";
import { accessTokenForCredential } from "../deriv/oauth.js";
import { getOwnedAccount } from "../deriv/accounts.js";
import { derivRequest } from "../deriv/rest.js";
import { DerivSocket } from "../deriv/websocket.js";
import { canApproveLiveIntent, evaluateDailyRisk, isAmbiguousExecutionFailure } from "../deriv/execution-policy.js";

const intentSchema = z.object({
  accountId: z.string().uuid(),
  environment: z.literal("REAL"),
  symbol: z.string().regex(/^[A-Za-z0-9_]{2,30}$/),
  contractType: z.enum(["CALL", "PUT", "DIGITOVER", "DIGITUNDER", "DIGITMATCH", "DIGITDIFF", "DIGITEVEN", "DIGITODD"]),
  stake: z.number().positive().max(1_000_000),
  duration: z.number().int().min(30).max(86400),
  durationUnit: z.enum(["s", "m", "h", "d"]).default("s")
});
const approvalSchema = z.object({ confirmation: z.literal("I AUTHORIZE THIS REAL TRADE") });
const rejectionSchema = z.object({ confirmation: z.literal("REJECT THIS LIVE TRADE PROPOSAL") });
const controlSchema = z.object({
  liveEnabled: z.boolean(),
  killSwitch: z.boolean(),
  maxStake: z.number().positive().max(1000),
  maxDailyLoss: z.number().positive().max(10000),
  confirmation: z.literal("ENABLE CONTROLLED LIVE TRADING")
});

async function authenticatedSocket(credentialId: string, ownerUserId: string, externalAccountId: string) {
  const token = await accessTokenForCredential(credentialId, ownerUserId);
  const otp = await derivRequest<{ data?: { url?: string } }>(
    `/trading/v1/options/accounts/${encodeURIComponent(externalAccountId)}/otp`, token, { method: "POST" }
  );
  const url = otp.data?.url;
  if (!url || !url.startsWith("wss://api.derivws.com/trading/v1/options/ws/real?")) {
    throw new Error("Deriv did not return a valid REAL-account WebSocket URL");
  }
  return DerivSocket.connect(url);
}

async function recordEvent(intentId: string | null, ownerUserId: string, eventType: string, outcome: "SUCCESS" | "DENIED" | "ERROR" | "INFO", details: Record<string, unknown>) {
  await pool.query(
    `INSERT INTO live_execution_events(intent_id,owner_user_id,event_type,outcome,details)
     VALUES($1,$2,$3,$4,$5::jsonb)`,
    [intentId, ownerUserId, eventType, outcome, JSON.stringify(details)]
  );
}

export async function registerExecutionRoutes(app: FastifyInstance): Promise<void> {
  app.get("/api/v1/live/control", { preHandler: requireSession }, async () => {
    const result = await pool.query("SELECT live_enabled,automation_enabled,kill_switch,require_manual_approval,max_stake,max_daily_loss,max_open_contracts,updated_at FROM live_execution_control WHERE control_id=1");
    return { control: result.rows[0] ?? null, deployment_gate: config.DQI_LIVE_TRADING_ENABLED === "true", execution: "MANUAL_APPROVAL_ONLY" };
  });

  app.post("/api/v1/live/control", { preHandler: requireSession }, async (request, reply) => {
    const session = (request as any).dqiSession;
    const parsed = controlSchema.safeParse(request.body);
    if (!parsed.success) return reply.code(400).send({ error: "INVALID_LIVE_CONTROL_REQUEST" });
    if (config.DQI_LIVE_TRADING_ENABLED !== "true") return reply.code(423).send({ error: "LIVE_EXECUTION_DISABLED_BY_DEPLOYMENT" });
    if (parsed.data.liveEnabled && parsed.data.killSwitch) return reply.code(422).send({ error: "CANNOT_ENABLE_WHILE_KILL_SWITCH_ACTIVE" });
    if (parsed.data.maxStake > config.DQI_LIVE_MAX_STAKE) return reply.code(422).send({ error: "STAKE_EXCEEDS_DEPLOYMENT_CEILING", deployment_max: config.DQI_LIVE_MAX_STAKE });
    if (parsed.data.maxDailyLoss > config.DQI_LIVE_MAX_DAILY_LOSS) return reply.code(422).send({ error: "DAILY_LOSS_EXCEEDS_DEPLOYMENT_CEILING", deployment_max: config.DQI_LIVE_MAX_DAILY_LOSS });
    const result = await pool.query(
      `UPDATE live_execution_control SET live_enabled=$1,kill_switch=$2,require_manual_approval=true,
       automation_enabled=false,max_stake=$3,max_daily_loss=$4,updated_by=$5,updated_at=now()
       WHERE control_id=1 RETURNING live_enabled,kill_switch,require_manual_approval,max_stake,max_daily_loss,updated_at`,
      [parsed.data.liveEnabled, parsed.data.killSwitch, parsed.data.maxStake, parsed.data.maxDailyLoss, session.owner_user_id]
    );
    await recordEvent(null, session.owner_user_id, "LIVE_CONTROL_CHANGED", "INFO", result.rows[0]);
    return { control: result.rows[0], execution: "MANUAL_APPROVAL_ONLY" };
  });

  app.post("/api/v1/live/kill-switch", { preHandler: requireSession }, async (request) => {
    const session = (request as any).dqiSession;
    await pool.query("UPDATE live_execution_control SET live_enabled=false,kill_switch=true,updated_by=$1,updated_at=now() WHERE control_id=1", [session.owner_user_id]);
    await recordEvent(null, session.owner_user_id, "LIVE_KILL_SWITCH_ACTIVATED", "SUCCESS", { source: "operator_ui" });
    return { live_enabled: false, kill_switch: true, message: "New live approvals are blocked." };
  });

  app.post("/api/v1/live/intents", { preHandler: requireSession }, async (request, reply) => {
    const session = (request as any).dqiSession;
    const parsed = intentSchema.safeParse(request.body);
    if (!parsed.success) return reply.code(400).send({ error: "INVALID_LIVE_INTENT", details: parsed.error.flatten() });
    if (!session.deriv_credential_id) return reply.code(409).send({ error: "DERIV_NOT_CONNECTED" });
    if (config.DQI_LIVE_TRADING_ENABLED !== "true") return reply.code(423).send({ error: "LIVE_EXECUTION_DISABLED_BY_DEPLOYMENT" });
    const control = await pool.query("SELECT * FROM live_execution_control WHERE control_id=1");
    const gate = control.rows[0];
    if (!gate?.live_enabled || gate.kill_switch) return reply.code(423).send({ error: "LIVE_TRADING_PAUSED_OR_KILLED" });
    if (parsed.data.stake > Math.min(Number(gate.max_stake), config.DQI_LIVE_MAX_STAKE)) return reply.code(422).send({ error: "STAKE_LIMIT_EXCEEDED" });
    let account;
    try { account = await getOwnedAccount(parsed.data.accountId, session.owner_user_id, session.deriv_credential_id, "REAL"); }
    catch { return reply.code(404).send({ error: "REAL_ACCOUNT_NOT_FOUND_OR_NOT_OWNED" }); }
    if (account.status !== "CONNECTED") return reply.code(409).send({ error: "DERIV_ACCOUNT_NOT_CONNECTED" });
    if (!account.currency) return reply.code(409).send({ error: "REAL_ACCOUNT_CURRENCY_UNAVAILABLE" });
    const symbolCheck = await pool.query("SELECT 1 FROM market_symbols WHERE provider='DERIV' AND symbol_code=$1 AND is_active=true LIMIT 1", [parsed.data.symbol]);
    if (!symbolCheck.rowCount) return reply.code(422).send({ error: "SYMBOL_NOT_IN_ACTIVE_DERIV_CATALOGUE" });
    const durationMultipliers: Record<string, number> = { s: 1, m: 60, h: 3600, d: 86400 };
    const durationSeconds = parsed.data.duration * durationMultipliers[parsed.data.durationUnit];
    if (durationSeconds > 86400) return reply.code(422).send({ error: "MAXIMUM_CONTRACT_DURATION_IS_24_HOURS" });

    let socket: DerivSocket | undefined;
    try {
      socket = await authenticatedSocket(session.deriv_credential_id, session.owner_user_id, account.external_ref);
      const proposal = await socket.request({
        proposal: 1,
        amount: parsed.data.stake,
        basis: "stake",
        contract_type: parsed.data.contractType,
        currency: account.currency,
        duration: parsed.data.duration,
        duration_unit: parsed.data.durationUnit,
        underlying_symbol: parsed.data.symbol
      });
      const quote = proposal.proposal;
      if (!quote?.id || !Number.isFinite(Number(quote.ask_price)) || Number(quote.ask_price) <= 0) throw new Error("Deriv returned an invalid contract proposal");
      const saved = await pool.query(
        `INSERT INTO live_trade_intents(owner_user_id,credential_id,account_id,environment,symbol_code,contract_type,currency,stake,duration,duration_unit,proposal_id,quoted_price,quoted_payout,quote_expires_at,contract_expires_at,status)
         VALUES($1,$2,$3,'REAL',$4,$5,$6,$7,$8,$9,$10,$11,$12,now()+interval '30 seconds',now()+($13 * interval '1 second'),'PENDING_APPROVAL')
         RETURNING intent_id,status,proposal_id,quoted_price,quoted_payout,quote_expires_at,created_at`,
        [session.owner_user_id,session.deriv_credential_id,account.account_id,parsed.data.symbol,parsed.data.contractType,account.currency,parsed.data.stake,parsed.data.duration,parsed.data.durationUnit,String(quote.id),Number(quote.ask_price),Number(quote.payout ?? 0),durationSeconds]
      );
      await recordEvent(saved.rows[0].intent_id, session.owner_user_id, "LIVE_PROPOSAL_CREATED", "SUCCESS", { accountId: account.account_id, symbol: parsed.data.symbol, contractType: parsed.data.contractType, stake: parsed.data.stake });
      return reply.code(201).send({ intent: saved.rows[0], approval_required: true, expires_in_seconds: 30, warning: "This is a real-money trade proposal. Nothing has been purchased. Review every field before explicitly approving." });
    } catch (error) {
      request.log.warn({ err: error }, "Live proposal failed");
      await recordEvent(null, session.owner_user_id, "LIVE_PROPOSAL_FAILED", "ERROR", { reason: error instanceof Error ? error.message : "unknown" });
      return reply.code(502).send({ error: "DERIV_PROPOSAL_FAILED" });
    } finally { socket?.close(); }
  });

  app.post("/api/v1/live/intents/:intentId/reject", { preHandler: requireSession }, async (request, reply) => {
    const session = (request as any).dqiSession;
    if (!rejectionSchema.safeParse(request.body).success) return reply.code(400).send({ error: "EXPLICIT_REJECTION_PHRASE_REQUIRED" });
    const params = request.params as { intentId: string };
    const result = await pool.query(`UPDATE live_trade_intents SET status='REJECTED',updated_at=now()
      WHERE intent_id=$1 AND owner_user_id=$2 AND status='PENDING_APPROVAL' RETURNING intent_id,status`, [params.intentId,session.owner_user_id]);
    if (!result.rowCount) return reply.code(409).send({ error: "INTENT_NOT_REJECTABLE" });
    await recordEvent(params.intentId, session.owner_user_id, "LIVE_PROPOSAL_REJECTED", "INFO", { reason: "Operator declined proposal" });
    return { intent: result.rows[0] };
  });

  app.post("/api/v1/live/intents/:intentId/approve", { preHandler: requireSession }, async (request, reply) => {
    const session = (request as any).dqiSession;
    const parsed = approvalSchema.safeParse(request.body);
    if (!parsed.success) return reply.code(400).send({ error: "EXPLICIT_APPROVAL_PHRASE_REQUIRED" });
    if (config.DQI_LIVE_TRADING_ENABLED !== "true") return reply.code(423).send({ error: "LIVE_EXECUTION_DISABLED_BY_DEPLOYMENT" });
    const params = request.params as { intentId: string };
    const client = await pool.connect();
    let intent: any;
    try {
      await client.query("BEGIN");
      const gate = await client.query("SELECT * FROM live_execution_control WHERE control_id=1 FOR UPDATE");
      if (!gate.rowCount) { await client.query("ROLLBACK"); return reply.code(423).send({ error: "LIVE_EXECUTION_GATE_CLOSED" }); }
      const selected = await client.query("SELECT * FROM live_trade_intents WHERE intent_id=$1 AND owner_user_id=$2 FOR UPDATE", [params.intentId,session.owner_user_id]);
      if (!selected.rowCount) { await client.query("ROLLBACK"); return reply.code(404).send({ error: "INTENT_NOT_FOUND" }); }
      intent = selected.rows[0];
      const gateDecision = canApproveLiveIntent({ deploymentEnabled: config.DQI_LIVE_TRADING_ENABLED === "true", databaseEnabled: gate.rows[0].live_enabled, killSwitch: gate.rows[0].kill_switch, manualApprovalRequired: gate.rows[0].require_manual_approval, intentPending: intent.status === "PENDING_APPROVAL", quoteExpiresAt: intent.quote_expires_at ? new Date(intent.quote_expires_at).getTime() : 0 });
      if (!gateDecision.allowed) { await client.query("ROLLBACK"); return reply.code(409).send({ error: "INTENT_NOT_APPROVABLE", reason: gateDecision.reason, status: intent.status }); }
      if (Number(intent.stake) > Math.min(Number(gate.rows[0].max_stake), config.DQI_LIVE_MAX_STAKE)) { await client.query("ROLLBACK"); return reply.code(422).send({ error: "STAKE_LIMIT_CHANGED_SINCE_PROPOSAL" }); }
      if (!intent.quote_expires_at || new Date(intent.quote_expires_at).getTime() <= Date.now()) {
        await client.query("UPDATE live_trade_intents SET status='EXPIRED',updated_at=now() WHERE intent_id=$1", [intent.intent_id]);
        await client.query("COMMIT"); return reply.code(409).send({ error: "PROPOSAL_EXPIRED_RECREATE_INTENT" });
      }
      const open = await client.query("SELECT count(*)::int AS count FROM live_trade_intents WHERE account_id=$1 AND status IN ('EXECUTING','EXECUTED','UNKNOWN') AND contract_expires_at > now()", [intent.account_id]);
      if (open.rows[0].count >= Number(gate.rows[0].max_open_contracts)) { await client.query("ROLLBACK"); return reply.code(423).send({ error: "MAX_OPEN_CONTRACTS_REACHED" }); }
      await client.query("UPDATE live_trade_intents SET status='EXECUTING',approved_by=$2,approved_at=now(),updated_at=now() WHERE intent_id=$1", [intent.intent_id,session.owner_user_id]);
      await client.query("COMMIT");
    } catch (error) {
      try { await client.query("ROLLBACK"); } catch { /* transaction already ended */ }
      throw error;
    } finally { client.release(); }

    let socket: DerivSocket | undefined;
    try {
      const account = await getOwnedAccount(intent.account_id, session.owner_user_id, intent.credential_id, "REAL");
      socket = await authenticatedSocket(intent.credential_id, session.owner_user_id, account.external_ref);
      const balanceResponse = await socket.request({ balance: 1 });
      const brokerBalance = balanceResponse.balance;
      const balance = Number(brokerBalance?.balance);
      if (!Number.isFinite(balance) || balance < Number(intent.stake)) throw new Error("Insufficient or unavailable Deriv balance");
      if (brokerBalance?.currency !== intent.currency) throw new Error("Broker balance currency does not match the quoted account currency");
      await pool.query("INSERT INTO account_balance_snapshots(account_id,balance,currency,broker_epoch) VALUES($1,$2,$3,$4)", [intent.account_id,balance,brokerBalance.currency,brokerBalance.epoch ?? null]);
      const risk = await pool.query(`INSERT INTO live_daily_risk_state(account_id,risk_date,opening_balance,max_daily_loss)
        VALUES($1,(now() AT TIME ZONE 'UTC')::date,$2,$3)
        ON CONFLICT(account_id,risk_date) DO UPDATE SET updated_at=now()
        RETURNING opening_balance,max_daily_loss,halted`, [intent.account_id,balance,Number((await pool.query("SELECT max_daily_loss FROM live_execution_control WHERE control_id=1")).rows[0].max_daily_loss)]);
      const dailyRisk = risk.rows[0];
      const riskDecision = evaluateDailyRisk(Number(dailyRisk.opening_balance), balance, Number(dailyRisk.max_daily_loss), Number(intent.stake), Boolean(dailyRisk.halted));
      if (!riskDecision.allowed) {
        await pool.query("UPDATE live_daily_risk_state SET halted=true,updated_at=now() WHERE account_id=$1 AND risk_date=(now() AT TIME ZONE 'UTC')::date", [intent.account_id]);
        throw new Error("Daily loss limit or remaining daily risk budget would be breached; live account execution halted for the UTC day");
      }
      const finalGate = await pool.query("SELECT live_enabled,kill_switch,max_stake FROM live_execution_control WHERE control_id=1");
      if (!finalGate.rowCount || !finalGate.rows[0].live_enabled || finalGate.rows[0].kill_switch || Number(intent.stake) > Math.min(Number(finalGate.rows[0].max_stake), config.DQI_LIVE_MAX_STAKE)) {
        throw new Error("Live execution gate or stake ceiling changed before broker purchase");
      }
      const result = await socket.request({ buy: intent.proposal_id, price: Number(intent.quoted_price) }, 15_000);
      const contract = result.buy;
      if (!contract?.contract_id) throw new Error("Deriv buy response did not contain a contract ID");
      const updated = await pool.query(
        `UPDATE live_trade_intents SET status='EXECUTED',broker_contract_id=$2,broker_transaction_id=$3,execution_response=$4::jsonb,updated_at=now()
         WHERE intent_id=$1 AND status='EXECUTING' RETURNING intent_id,status,broker_contract_id,broker_transaction_id,execution_response`,
        [intent.intent_id,String(contract.contract_id),contract.transaction_id ? String(contract.transaction_id) : null,JSON.stringify({ buy: contract })]
      );
      await recordEvent(intent.intent_id, session.owner_user_id, "LIVE_CONTRACT_PURCHASED", "SUCCESS", { contractId: String(contract.contract_id), transactionId: contract.transaction_id ?? null });
      return { intent: updated.rows[0], warning: "Real-money contract purchased. Monitor its status in Deriv and reconcile the account." };
    } catch (error) {
      // A timeout after sending buy is ambiguous. Mark UNKNOWN; never retry automatically.
      const reason = error instanceof Error ? error.message : "unknown";
      const status = isAmbiguousExecutionFailure(reason) ? "UNKNOWN" : "FAILED";
      await pool.query("UPDATE live_trade_intents SET status=$2,execution_response=$3::jsonb,updated_at=now() WHERE intent_id=$1 AND status='EXECUTING'", [intent.intent_id,status,JSON.stringify({ error: reason.slice(0,300), retry_allowed: false })]);
      await recordEvent(intent.intent_id, session.owner_user_id, "LIVE_CONTRACT_PURCHASE_FAILED", "ERROR", { status, reason: reason.slice(0,250), retry_allowed: false });
      return reply.code(status === "UNKNOWN" ? 202 : 502).send({ error: status === "UNKNOWN" ? "EXECUTION_RESULT_UNKNOWN_RECONCILE_BEFORE_RETRY" : "LIVE_EXECUTION_FAILED", status });
    } finally { socket?.close(); }
  });

  app.get("/api/v1/live/intents", { preHandler: requireSession }, async (request) => {
    const session = (request as any).dqiSession;
    const result = await pool.query("SELECT intent_id,account_id,environment,symbol_code,contract_type,currency,stake,duration,duration_unit,quoted_price,quoted_payout,status,broker_contract_id,contract_expires_at,created_at,approved_at,updated_at FROM live_trade_intents WHERE owner_user_id=$1 ORDER BY created_at DESC LIMIT 100", [session.owner_user_id]);
    return { intents: result.rows };
  });

  app.post("/api/v1/live/reconcile", { preHandler: requireSession }, async (request, reply) => {
    const session = (request as any).dqiSession;
    if (!session.deriv_credential_id) return reply.code(409).send({ error: "DERIV_NOT_CONNECTED" });
    const body = z.object({ accountId: z.string().uuid() }).safeParse(request.body);
    if (!body.success) return reply.code(400).send({ error: "ACCOUNT_ID_REQUIRED" });
    let account;
    try { account = await getOwnedAccount(body.data.accountId, session.owner_user_id, session.deriv_credential_id, "REAL"); }
    catch { return reply.code(404).send({ error: "REAL_ACCOUNT_NOT_FOUND_OR_NOT_OWNED" }); }
    let socket: DerivSocket | undefined;
    try {
      socket = await authenticatedSocket(session.deriv_credential_id, session.owner_user_id, account.external_ref);
      const portfolio = await socket.request({ portfolio: 1 });
      const contracts = Array.isArray(portfolio.portfolio?.contracts) ? portfolio.portfolio.contracts.slice(0, 100) : [];
      const reconciled = [];
      for (const contract of contracts) {
        const contractId = String(contract.contract_id ?? "");
        if (!contractId) continue;
        const detail = await socket.request({ proposal_open_contract: 1, contract_id: Number(contractId) });
        const payload = detail.proposal_open_contract ?? {};
        await pool.query(`INSERT INTO live_contract_reconciliation(owner_user_id,account_id,broker_contract_id,broker_status,broker_payload)
          VALUES($1,$2,$3,$4,$5::jsonb) ON CONFLICT(account_id,broker_contract_id) DO UPDATE SET broker_status=excluded.broker_status,broker_payload=excluded.broker_payload,reconciled_at=now()`,
          [session.owner_user_id,account.account_id,contractId,String(payload.status ?? "UNKNOWN"),JSON.stringify(payload)]);
        reconciled.push({ contractId, status: payload.status ?? "UNKNOWN", buyPrice: payload.buy_price ?? null, sellPrice: payload.sell_price ?? null, profit: payload.profit ?? null });
      }
      await recordEvent(null, session.owner_user_id, "LIVE_PORTFOLIO_RECONCILED", "SUCCESS", { accountId: account.account_id, contracts: reconciled.length });
      return { accountId: account.account_id, environment: "REAL", contracts: reconciled, reconciledAt: new Date().toISOString() };
    } catch (error) {
      request.log.warn({ err: error }, "Live portfolio reconciliation failed");
      await recordEvent(null, session.owner_user_id, "LIVE_PORTFOLIO_RECONCILIATION_FAILED", "ERROR", { reason: error instanceof Error ? error.message : "unknown" });
      return reply.code(502).send({ error: "LIVE_PORTFOLIO_RECONCILIATION_FAILED" });
    } finally { socket?.close(); }
  });

}
