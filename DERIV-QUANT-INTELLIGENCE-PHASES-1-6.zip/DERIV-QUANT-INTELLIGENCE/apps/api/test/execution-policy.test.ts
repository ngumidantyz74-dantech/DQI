import { describe, expect, it } from "vitest";
import { canApproveLiveIntent, evaluateDailyRisk, isAmbiguousExecutionFailure } from "../src/deriv/execution-policy.js";

describe("controlled live execution policy", () => {
  it("rejects execution when deployment flag is off", () => {
    expect(canApproveLiveIntent({ deploymentEnabled:false,databaseEnabled:true,killSwitch:false,manualApprovalRequired:true,intentPending:true,quoteExpiresAt:Date.now()+30000 }).reason).toBe("DEPLOYMENT_DISABLED");
  });
  it("rejects execution while kill switch is active", () => {
    expect(canApproveLiveIntent({ deploymentEnabled:true,databaseEnabled:true,killSwitch:true,manualApprovalRequired:true,intentPending:true,quoteExpiresAt:Date.now()+30000 }).reason).toBe("KILL_SWITCH_ACTIVE");
  });
  it("rejects expired quotes and non-pending intents", () => {
    expect(canApproveLiveIntent({ deploymentEnabled:true,databaseEnabled:true,killSwitch:false,manualApprovalRequired:true,intentPending:true,quoteExpiresAt:1000,now:1001 }).reason).toBe("QUOTE_EXPIRED");
    expect(canApproveLiveIntent({ deploymentEnabled:true,databaseEnabled:true,killSwitch:false,manualApprovalRequired:true,intentPending:false,quoteExpiresAt:3000,now:1000 }).reason).toBe("INTENT_NOT_PENDING");
  });
  it("permits only a valid pending intent behind every gate", () => {
    expect(canApproveLiveIntent({ deploymentEnabled:true,databaseEnabled:true,killSwitch:false,manualApprovalRequired:true,intentPending:true,quoteExpiresAt:3000,now:1000 })).toEqual({allowed:true,reason:null});
  });
  it("limits stake to the remaining daily risk budget", () => {
    expect(evaluateDailyRisk(100,96,5,3,false)).toMatchObject({allowed:false,lossSoFar:4,remainingBudget:1,reason:"STAKE_EXCEEDS_REMAINING_DAILY_RISK"});
    expect(evaluateDailyRisk(100,96,5,1,false).allowed).toBe(true);
  });
  it("fails closed for halted accounts and invalid numbers", () => {
    expect(evaluateDailyRisk(100,100,5,1,true).allowed).toBe(false);
    expect(() => evaluateDailyRisk(100,100,5,Number.NaN,false)).toThrow();
  });
  it("marks uncertain network failures as ambiguous to prevent blind retries", () => {
    expect(isAmbiguousExecutionFailure("Deriv WebSocket request timed out")).toBe(true);
    expect(isAmbiguousExecutionFailure("Insufficient balance")).toBe(false);
  });
});
