import { useEffect, useState } from "react";

type ApiStatus = "checking" | "online" | "offline";
type DerivAccount = { account_id: string; environment: "DEMO" | "REAL"; external_ref: string; currency: string | null; status: string };
type BalanceView = { balance: number; currency: string; capturedAt: string };
type LiveIntent = { intent_id: string; status: string; symbol_code: string; contract_type: string; stake: string; quoted_price: string; quoted_payout: string; quote_expires_at: string };

const API_BASE = import.meta.env.VITE_API_BASE_URL ?? "http://localhost:8080";
const QUANT_SITE_URL = import.meta.env.VITE_QUANT_SITE_URL ?? "http://localhost:5174";

export function App() {
  const [apiStatus, setApiStatus] = useState<ApiStatus>("checking");
  const [accounts, setAccounts] = useState<DerivAccount[]>([]);
  const [derivMessage, setDerivMessage] = useState("Deriv account not connected");
  const [connecting, setConnecting] = useState(false);
  const [balances, setBalances] = useState<Record<string, BalanceView>>({});
  const [balanceLoading, setBalanceLoading] = useState<string | null>(null);
  const [liveGate, setLiveGate] = useState<any>(null);
  const [liveIntents, setLiveIntents] = useState<LiveIntent[]>([]);
  const [liveSymbol, setLiveSymbol] = useState("R_100");
  const [liveContract, setLiveContract] = useState("CALL");
  const [liveStake, setLiveStake] = useState("0.35");
  const [liveDuration, setLiveDuration] = useState("300");
  const [pendingIntent, setPendingIntent] = useState<LiveIntent | null>(null);
  const [approvalPhrase, setApprovalPhrase] = useState("");
  const [liveBusy, setLiveBusy] = useState(false);
  const [liveMessage, setLiveMessage] = useState("");
  const [reconciliation, setReconciliation] = useState<any>(null);

  useEffect(() => {
    let active = true;
    fetch(`${API_BASE}/health`)
      .then((response) => {
        if (!response.ok) throw new Error("API health check failed");
        return response.json();
      })
      .then(() => active && setApiStatus("online"))
      .catch(() => active && setApiStatus("offline"));
    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    fetch(`${API_BASE}/api/v1/deriv/connection`, { credentials: "include" })
      .then((response) => response.ok ? response.json() : { connected: false })
      .then((result) => { if (result.connected) void loadAccounts(); })
      .catch(() => undefined);
  }, []);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get("deriv") === "connected") {
      window.history.replaceState({}, "", window.location.pathname);
      void loadAccounts();
    }
  }, []);

  async function loadAccounts() {
    try {
      const response = await fetch(`${API_BASE}/api/v1/deriv/accounts`, { credentials: "include" });
      if (!response.ok) throw new Error("Could not retrieve authorized accounts");
      const result = await response.json();
      setAccounts(result.accounts ?? []);
      setDerivMessage(`Connected · ${result.accounts?.length ?? 0} account(s) discovered`);
      void loadLiveControl().catch(() => undefined);
    } catch {
      setDerivMessage("Account discovery unavailable. Check OAuth connection and API logs.");
    }
  }

  async function loadBalance(account: DerivAccount) {
    setBalanceLoading(account.account_id);
    try {
      const response = await fetch(`${API_BASE}/api/v1/deriv/accounts/${account.account_id}/balance?environment=${account.environment}`, { credentials: "include" });
      if (!response.ok) throw new Error("Balance unavailable");
      const result = await response.json();
      setBalances((current) => ({ ...current, [account.account_id]: result }));
    } catch {
      setDerivMessage(`Could not retrieve ${account.environment} balance. Check account permissions and connection.`);
    } finally {
      setBalanceLoading(null);
    }
  }


  async function loadLiveControl() {
    const [controlResponse, intentsResponse] = await Promise.all([
      fetch(`${API_BASE}/api/v1/live/control`, { credentials: "include" }),
      fetch(`${API_BASE}/api/v1/live/intents`, { credentials: "include" })
    ]);
    if (controlResponse.ok) setLiveGate(await controlResponse.json());
    if (intentsResponse.ok) setLiveIntents((await intentsResponse.json()).intents ?? []);
  }

  async function reconcileLivePortfolio() {
    const account = accounts.find((item) => item.environment === "REAL");
    if (!account) { setLiveMessage("No owned REAL account is available for reconciliation."); return; }
    setLiveBusy(true); setLiveMessage("");
    try {
      const response = await fetch(`${API_BASE}/api/v1/live/reconcile`, { method: "POST", credentials: "include", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ accountId: account.account_id }) });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Portfolio reconciliation failed");
      setReconciliation(data); setLiveMessage(`Broker portfolio reconciled: ${data.contracts?.length ?? 0} open contract(s) returned.`);
      await loadLiveControl();
    } catch (error) { setLiveMessage((error as Error).message); }
    finally { setLiveBusy(false); }
  }

  async function createLiveIntent() {
    const account = accounts.find((item) => item.environment === "REAL");
    if (!account) { setLiveMessage("Connect Deriv and discover a REAL Options account first."); return; }
    setLiveBusy(true); setLiveMessage(""); setPendingIntent(null);
    try {
      const response = await fetch(`${API_BASE}/api/v1/live/intents`, { method: "POST", credentials: "include", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ accountId: account.account_id, environment: "REAL", symbol: liveSymbol, contractType: liveContract, stake: Number(liveStake), duration: Number(liveDuration), durationUnit: "s" }) });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Could not create live proposal");
      setPendingIntent(data.intent); setLiveMessage("Proposal created. No trade has been purchased. Review the details and explicitly approve if you intend to risk real funds.");
    } catch (error) { setLiveMessage((error as Error).message); }
    finally { setLiveBusy(false); }
  }

  async function triggerLiveKillSwitch() {
    setLiveBusy(true); setLiveMessage("");
    try {
      const response = await fetch(`${API_BASE}/api/v1/live/kill-switch`, { method: "POST", credentials: "include" });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Could not activate kill switch");
      setLiveMessage("Emergency stop activated. New live approvals are blocked."); await loadLiveControl();
    } catch (error) { setLiveMessage((error as Error).message); }
    finally { setLiveBusy(false); }
  }

  async function rejectLiveIntent() {
    if (!pendingIntent) return;
    setLiveBusy(true);
    try {
      const response = await fetch(`${API_BASE}/api/v1/live/intents/${pendingIntent.intent_id}/reject`, { method: "POST", credentials: "include", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ confirmation: "REJECT THIS LIVE TRADE PROPOSAL" }) });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Could not reject proposal");
      setPendingIntent(null); setApprovalPhrase(""); setLiveMessage("Proposal rejected. No contract was purchased."); await loadLiveControl();
    } catch (error) { setLiveMessage((error as Error).message); }
    finally { setLiveBusy(false); }
  }

  async function approveLiveIntent() {
    if (!pendingIntent) return;
    setLiveBusy(true); setLiveMessage("");
    try {
      const response = await fetch(`${API_BASE}/api/v1/live/intents/${pendingIntent.intent_id}/approve`, { method: "POST", credentials: "include", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ confirmation: approvalPhrase }) });
      const data = await response.json();
      if (!response.ok && response.status !== 202) throw new Error(data.error || "Live approval failed");
      setLiveMessage(data.warning || data.error || `Execution status: ${data.status || data.intent?.status}`);
      setPendingIntent(null); setApprovalPhrase(""); await loadLiveControl();
    } catch (error) { setLiveMessage((error as Error).message); }
    finally { setLiveBusy(false); }
  }

  async function connectDeriv() {
    setConnecting(true);
    try {
      const response = await fetch(`${API_BASE}/api/v1/auth/deriv/start`, { credentials: "include" });
      if (!response.ok) throw new Error("Could not start Deriv OAuth");
      const result = await response.json();
      window.location.assign(result.authorizationUrl);
    } catch {
      setDerivMessage("Unable to start Deriv authorization. Check server OAuth configuration.");
      setConnecting(false);
    }
  }

  return (
    <main className="shell">
      <aside className="sidebar">
        <div className="brand"><span className="brand-mark">DQ</span><span>DERIV QUANT<br />INTELLIGENCE</span></div>
        <nav aria-label="Main navigation">
          {["Overview", "Markets", "Trading terminal", "AI signals", "Strategy lab", "Portfolio", "Risk centre", "Trade history", "Developer console"].map((item, index) => (
            <button className={index === 0 ? "nav-item active" : "nav-item"} key={item} type="button">
              <span className="nav-dot" />{item}
            </button>
          ))}
        </nav>
        <div className="sidebar-footer">PHASE 3 · QUANT SITE</div>
      </aside>

      <section className="content">
        <header className="topbar">
          <div><span className="eyebrow">QUANTITATIVE TRADING WORKSPACE</span><h1>Overview</h1></div>
          <div className="top-actions">
            <span className="mode-pill">DEMO-FIRST</span>
            <span className={`status ${apiStatus}`}>API {apiStatus}</span>
            <button className="connect-button" type="button" onClick={() => window.open(QUANT_SITE_URL, "_blank", "noopener,noreferrer")}>Open Quant Site</button>
            <button className="connect-button" type="button" onClick={connectDeriv} disabled={connecting}>{connecting ? "Connecting…" : "Connect Deriv"}</button>
          </div>
        </header>

        <section className="notice">
          <strong>Controlled deployment · real execution locked by default</strong>
          <span>Phase 5 paper automation runs only with virtual funds. Phase 6 live proposals and manual approval are gated by server configuration, account-level risk controls and an emergency stop. The separate Quant site remains the research workspace.</span>
        </section>

        <section className="panel deriv-panel">
          <div className="panel-heading"><div><span className="eyebrow">BROKER CONNECTION</span><h2>Deriv accounts</h2></div><span className="tag">OAUTH · READ ONLY</span></div>
          <p className="deriv-message">{derivMessage}</p>
          {accounts.length > 0 && <div className="account-list">{accounts.map((account) => <div className="account-row" key={account.account_id}><span><b className={account.environment === "REAL" ? "real-label" : "demo-label"}>{account.environment}</b> {account.external_ref}</span><span>{balances[account.account_id] ? `${balances[account.account_id].balance.toLocaleString()} ${balances[account.account_id].currency}` : account.currency ?? "Balance not fetched"}</span><button type="button" className="balance-button" disabled={balanceLoading === account.account_id} onClick={() => void loadBalance(account)}>{balanceLoading === account.account_id ? "Loading…" : "Fetch balance"}</button></div>)}</div>}
        </section>

        <section className="panel deriv-panel">
          <div className="panel-heading"><div><span className="eyebrow">PHASE 6 · CONTROLLED EXECUTION</span><h2>Live execution safety gate</h2></div><span className="tag">MANUAL APPROVAL ONLY</span></div>
          <div className="risk-state"><span className="shield">✓</span><div><strong>{liveGate?.control?.live_enabled && !liveGate?.control?.kill_switch && liveGate?.deployment_gate ? "Deployment gate open" : "Live execution locked"}</strong><p>Deployment flag: {liveGate?.deployment_gate ? "enabled" : "disabled"} · Database gate: {liveGate?.control?.live_enabled ? "enabled" : "disabled"} · Kill switch: {liveGate?.control?.kill_switch ? "ACTIVE" : "inactive"}</p></div></div>
          <p className="deriv-message">A real contract can only be purchased after a fresh Deriv proposal, a second explicit approval, sufficient account balance and server-side risk checks. Unknown execution outcomes are never retried automatically.</p>
          <div className="scan-toolbar"><button className="connect-button" disabled={liveBusy || !accounts.some(a=>a.environment==="REAL")} onClick={reconcileLivePortfolio}>Reconcile Deriv portfolio</button>{liveGate?.deployment_gate && <button className="connect-button" disabled={liveBusy} onClick={triggerLiveKillSwitch}>Emergency stop — disable live approvals</button>}</div>
          {reconciliation && <p className="deriv-message">Last reconciliation: {reconciliation.contracts?.length ?? 0} broker contract(s) · {new Date(reconciliation.reconciledAt).toLocaleString()}</p>}
          <div className="paper-form"><div><label>REAL account</label><select disabled value={accounts.find(a=>a.environment==="REAL")?.account_id||""}><option value={accounts.find(a=>a.environment==="REAL")?.account_id||""}>{accounts.some(a=>a.environment==="REAL")?accounts.find(a=>a.environment==="REAL")?.external_ref:"No real account discovered"}</option></select></div><div><label>Market symbol</label><input value={liveSymbol} onChange={e=>setLiveSymbol(e.target.value)} pattern="[A-Za-z0-9_]{2,30}"/></div><div><label>Contract direction</label><select value={liveContract} onChange={e=>setLiveContract(e.target.value)}><option value="CALL">CALL / Rise</option><option value="PUT">PUT / Fall</option></select></div><div><label>Stake (account currency)</label><input type="number" min="0.01" step="0.01" value={liveStake} onChange={e=>setLiveStake(e.target.value)}/></div><div><label>Duration</label><select value={liveDuration} onChange={e=>setLiveDuration(e.target.value)}><option value="30">30 seconds</option><option value="60">1 minute</option><option value="300">5 minutes</option><option value="900">15 minutes</option><option value="3600">1 hour</option></select></div><button className="connect-button" disabled={liveBusy || !liveGate?.deployment_gate || !liveGate?.control?.live_enabled || liveGate?.control?.kill_switch || !accounts.some(a=>a.environment==="REAL")} onClick={createLiveIntent}>{liveBusy?"Requesting proposal…":"Request live proposal"}</button></div>
          {pendingIntent && <div className="notice"><strong>Approval required · No order placed yet</strong><span>Intent {pendingIntent.intent_id} · {pendingIntent.symbol_code} · {pendingIntent.contract_type} · stake {pendingIntent.stake} · maximum purchase price {pendingIntent.quoted_price} · quote expires {new Date(pendingIntent.quote_expires_at).toLocaleTimeString()}.</span><label>Type exactly: I AUTHORIZE THIS REAL TRADE</label><input value={approvalPhrase} onChange={e=>setApprovalPhrase(e.target.value)} placeholder="I AUTHORIZE THIS REAL TRADE"/><div className="scan-toolbar"><button className="connect-button" disabled={liveBusy || approvalPhrase!=="I AUTHORIZE THIS REAL TRADE"} onClick={approveLiveIntent}>Approve and purchase real contract</button><button className="balance-button" disabled={liveBusy} onClick={rejectLiveIntent}>Reject proposal</button></div></div>}
          {liveMessage && <p className="deriv-message" role="status">{liveMessage}</p>}
          <div className="account-list">{liveIntents.slice(0,5).map(intent=><div className="account-row" key={intent.intent_id}><span>{intent.symbol_code} · {intent.contract_type} · {intent.stake}</span><b>{intent.status}</b><span>{intent.broker_contract_id||"No broker contract ID"}</span></div>)}</div>
          <p className="muted">The environment switch, kill switch and deployment flag are server-controlled. This page cannot turn on live trading. Configure the gate through the protected API only after reviewing the Phase 6 acceptance checklist.</p>
        </section>

        <section className="metric-grid" aria-label="Account metrics">
          {[
            ["Account balance", "—", "Connect account in Phase 2"],
            ["Equity", "—", "Awaiting authorized account data"],
            ["Today's P/L", "—", "No trades recorded"],
            ["Open positions", "0", "Execution not enabled"]
          ].map(([label, value, detail]) => (
            <article className="metric-card" key={label}>
              <span className="muted">{label}</span>
              <strong>{value}</strong>
              <small>{detail}</small>
            </article>
          ))}
        </section>

        <section className="main-grid">
          <article className="panel chart-panel">
            <div className="panel-heading"><div><span className="eyebrow">MARKET WORKSPACE</span><h2>Market intelligence</h2></div><span className="tag">QUANT SITE</span></div>
            <div className="empty-chart">
              <div className="chart-icon">⌁</div>
              <strong>Open the Quant Intelligence workspace</strong>
              <p>The independent Quant site provides Deriv symbols, live ticks, multi-timeframe analysis, scanning and backtesting.</p>
            </div>
          </article>
          <article className="panel">
            <div className="panel-heading"><div><span className="eyebrow">CAPITAL PROTECTION</span><h2>Risk guardian</h2></div><span className="safe">SAFE</span></div>
            <div className="risk-state"><span className="shield">✓</span><div><strong>Execution locked</strong><p>Trading and live trading flags are false.</p></div></div>
            <div className="rule-row"><span>Demo execution</span><b>Disabled</b></div>
            <div className="rule-row"><span>Real execution</span><b>Disabled</b></div>
            <div className="rule-row"><span>Emergency stop</span><b>Armed by default</b></div>
          </article>
        </section>

        <section className="panel bottom-panel">
          <div className="panel-heading"><div><span className="eyebrow">SYSTEM FOUNDATION</span><h2>Service health</h2></div></div>
          <div className="service-grid">
            <div><span className="service-indicator" />Web application <b>Running</b></div>
            <div><span className="service-indicator" />API <b>{apiStatus}</b></div>
            <div><span className="service-indicator pending" />Quant service <b>See service health</b></div>
            <div><span className="service-indicator pending" />Database <b>See API readiness</b></div>
          </div>
        </section>
        <footer>DQI v0.6.0 · Phases 1–6 · Manual approval gated live execution</footer>
      </section>
    </main>
  );
}
