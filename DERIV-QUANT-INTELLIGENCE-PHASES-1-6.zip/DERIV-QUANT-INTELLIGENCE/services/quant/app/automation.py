"""Durable, single-leader paper strategy scheduler. Never accesses live account credentials."""
from __future__ import annotations
import asyncio, json, logging, os, time
from datetime import datetime, timezone
from typing import Any
import websockets
from .engine.analysis import analyze_candles, TIMEFRAMES
from .engine.deriv import fetch_candles, deriv_request
from .engine.paper import validate_paper_order, settle_directional_contract

log = logging.getLogger("dqi.automation")
LOCK_ID = 740031241


def signal_qualifies(direction: str, confidence: float, minimum_confidence: float) -> bool:
    if direction not in ("BUY", "SELL", "NEUTRAL"):
        raise ValueError("Unsupported signal direction")
    if not 0 <= confidence <= 1 or not 0 <= minimum_confidence <= 1:
        raise ValueError("Confidence values must be between zero and one")
    return direction in ("BUY", "SELL") and confidence >= minimum_confidence

async def _settle_expired(pool: Any) -> int:
    settled = 0
    async with pool.acquire() as conn:
        rows = await conn.fetch("""SELECT p.position_id,p.symbol_code,p.direction,p.entry_price,p.stake,
            p.payout_multiplier,p.expires_at,p.paper_account_id FROM paper_positions p
            WHERE p.status='OPEN' AND p.expires_at <= now() ORDER BY p.expires_at LIMIT 50""")
    for candidate in rows:
        try:
            response = await deriv_request({"ticks": candidate["symbol_code"]}, timeout=12)
            tick = response.get("tick", {})
            exit_price = float(tick.get("quote")); epoch = int(tick.get("epoch", 0))
            if epoch < int(candidate["expires_at"].timestamp()) or not exit_price > 0:
                continue
            result = settle_directional_contract(direction=candidate["direction"],
                entry_price=float(candidate["entry_price"]), exit_price=exit_price,
                stake=float(candidate["stake"]), payout_multiplier=float(candidate["payout_multiplier"]))
            async with pool.acquire() as conn:
                async with conn.transaction():
                    row = await conn.fetchrow("""SELECT p.*,a.current_equity,a.reserved_stake FROM paper_positions p
                        JOIN paper_accounts a ON a.paper_account_id=p.paper_account_id
                        WHERE p.position_id=$1 AND p.status='OPEN' FOR UPDATE OF p,a""", candidate["position_id"])
                    if not row: continue
                    await conn.execute("UPDATE paper_positions SET exit_price=$2,settled_at=now(),status=$3,profit_loss=$4,settlement=$5::jsonb WHERE position_id=$1 AND status='OPEN'", row["position_id"], exit_price, result["status"], result["profit_loss"], json.dumps(result))
                    await conn.execute("UPDATE paper_accounts SET current_equity=current_equity+$2,reserved_stake=GREATEST(0,reserved_stake-$3),updated_at=now() WHERE paper_account_id=$1", row["paper_account_id"], result["profit_loss"], row["stake"])
                    account = await conn.fetchrow("SELECT current_equity,reserved_stake FROM paper_accounts WHERE paper_account_id=$1", row["paper_account_id"])
                    await conn.execute("INSERT INTO paper_equity_snapshots(paper_account_id,equity,reserved_stake) VALUES($1,$2,$3)", row["paper_account_id"], account["current_equity"], account["reserved_stake"])
                    settled += 1
        except Exception:
            log.exception("Paper settlement failed for position %s", candidate["position_id"])
    return settled

async def _evaluate_strategy(pool: Any, strategy: Any) -> dict[str, Any]:
    strategy_id = int(strategy["strategy_id"]); symbol = strategy["symbol_code"]
    timeframe = strategy["timeframe"]
    if not symbol or timeframe not in TIMEFRAMES:
        return {"strategy_id": strategy_id, "status": "SKIPPED", "reason": "INVALID_CONFIGURATION"}
    candles = await fetch_candles(symbol, TIMEFRAMES[timeframe], 250)
    analysis = analyze_candles(symbol, timeframe, candles)
    epoch = int(analysis["as_of_epoch"]); direction = analysis["direction"]
    confidence = float(analysis["raw_confidence"])
    async with pool.acquire() as conn:
        async with conn.transaction():
            inserted = await conn.fetchval("""INSERT INTO quant_strategy_runs
                (strategy_id,symbol_code,timeframe,candle_epoch,direction,confidence,outcome,details)
                VALUES($1,$2,$3,$4,$5,$6,'SKIPPED',$7::jsonb)
                ON CONFLICT(strategy_id,symbol_code,timeframe,candle_epoch) DO NOTHING
                RETURNING run_id""", strategy_id, symbol, timeframe, epoch, direction, confidence, json.dumps({"analysis": analysis}))
            if inserted is None:
                return {"strategy_id": strategy_id, "status": "DUPLICATE_CANDLE"}
            min_confidence = float(strategy["min_confidence"])
            cooldown = await conn.fetchval("SELECT max(opened_at) FROM paper_positions WHERE strategy_id=$1 AND opened_at > now()-($2 * interval '1 second')", strategy_id, int(strategy["cooldown_seconds"]))
            if cooldown is not None:
                await conn.execute("UPDATE quant_strategy_runs SET details=details || $2::jsonb WHERE run_id=$1", inserted, json.dumps({"skip_reason":"STRATEGY_COOLDOWN_ACTIVE"}))
                return {"strategy_id": strategy_id, "status": "COOLDOWN_ACTIVE"}
            if not signal_qualifies(direction, confidence, min_confidence):
                return {"strategy_id": strategy_id, "status": "NO_QUALIFYING_SIGNAL", "direction": direction, "confidence": confidence}
            account = await conn.fetchrow("SELECT * FROM paper_accounts WHERE is_active=true FOR UPDATE")
            if not account:
                await conn.execute("UPDATE quant_strategy_runs SET details=details || $2::jsonb WHERE run_id=$1", inserted, json.dumps({"skip_reason":"NO_PAPER_ACCOUNT"}))
                return {"strategy_id": strategy_id, "status": "NO_PAPER_ACCOUNT"}
            open_count = await conn.fetchval("SELECT count(*) FROM paper_positions WHERE paper_account_id=$1 AND status='OPEN'", account["paper_account_id"])
            daily_pnl = await conn.fetchval("""SELECT COALESCE(sum(profit_loss),0) FROM paper_positions
                WHERE paper_account_id=$1 AND settled_at >= date_trunc('day',now() AT TIME ZONE 'UTC') AT TIME ZONE 'UTC'
                AND status IN ('WON','LOST')""", account["paper_account_id"])
            equity = float(account["current_equity"]); stake = round(equity * float(strategy["risk_fraction"]), 8)
            try:
                risk = validate_paper_order(equity=equity, available_balance=equity-float(account["reserved_stake"]),
                    stake=stake, expiry_seconds=int(strategy["expiry_seconds"]), open_positions=int(open_count), daily_realized_pnl=float(daily_pnl))
            except ValueError as exc:
                await conn.execute("UPDATE quant_strategy_runs SET details=details || $2::jsonb WHERE run_id=$1", inserted, json.dumps({"skip_reason":str(exc)}))
                return {"strategy_id": strategy_id, "status": "RISK_REJECTED", "reason": str(exc)}
            quote = await deriv_request({"ticks": symbol}, timeout=12)
            entry = float(quote.get("tick", {}).get("quote", 0))
            if not entry > 0:
                raise RuntimeError("Invalid Deriv entry quote")
            from datetime import timedelta
            expires = datetime.now(timezone.utc) + timedelta(seconds=int(strategy["expiry_seconds"]))
            position = await conn.fetchrow("""INSERT INTO paper_positions
                (paper_account_id,strategy_id,symbol_code,timeframe,direction,stake,payout_multiplier,entry_price,expires_at,signal_snapshot)
                VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10::jsonb) RETURNING position_id""",
                account["paper_account_id"], strategy_id, symbol, timeframe, direction, stake,
                float(strategy["payout_multiplier"]), entry, expires, json.dumps(analysis))
            await conn.execute("UPDATE paper_accounts SET reserved_stake=reserved_stake+$2,updated_at=now() WHERE paper_account_id=$1", account["paper_account_id"], stake)
            await conn.execute("UPDATE quant_strategy_runs SET outcome='OPENED',paper_position_id=$2,details=details || $3::jsonb WHERE run_id=$1", inserted, position["position_id"], json.dumps({"entry_price":entry,"stake":stake,"risk":risk}))
            return {"strategy_id": strategy_id, "status": "PAPER_POSITION_OPENED", "position_id": position["position_id"], "direction": direction, "confidence": confidence}

async def automation_cycle(pool: Any) -> dict[str, Any]:
    async with pool.acquire() as conn:
        acquired = await conn.fetchval("SELECT pg_try_advisory_lock($1)", LOCK_ID)
        if not acquired:
            return {"leader": False}
        try:
            control = await conn.fetchrow("SELECT enabled,kill_switch FROM quant_automation_control WHERE control_id=1")
            await conn.execute("INSERT INTO quant_worker_heartbeat(worker_name,status,details) VALUES('paper-automation','RUNNING','{}'::jsonb) ON CONFLICT(worker_name) DO UPDATE SET last_seen_at=now(),status='RUNNING'")
            strategies = [] if not control or not control["enabled"] or control["kill_switch"] else await conn.fetch("SELECT * FROM paper_strategies WHERE enabled=true AND auto_enabled=true AND execution_mode='PAPER' ORDER BY strategy_id LIMIT 50")
        finally:
            await conn.execute("SELECT pg_advisory_unlock($1)", LOCK_ID)
    outcomes = []
    for strategy in strategies:
        try:
            outcomes.append(await _evaluate_strategy(pool, strategy))
        except Exception as exc:
            log.exception("Strategy evaluation failed: %s", strategy["strategy_id"])
            outcomes.append({"strategy_id": int(strategy["strategy_id"]), "status":"ERROR", "reason":str(exc)[:180]})
            async with pool.acquire() as conn:
                await conn.execute("INSERT INTO quant_alerts(severity,alert_code,message,details) VALUES('WARNING','STRATEGY_EVALUATION_FAILED',$1,$2::jsonb)", str(exc)[:500], json.dumps({"strategy_id":int(strategy["strategy_id"])}))
    settled = await _settle_expired(pool)
    return {"leader": True, "enabled": bool(control and control["enabled"] and not control["kill_switch"]), "evaluated": len(outcomes), "settled": settled, "outcomes": outcomes}

async def automation_worker(pool: Any, stop: asyncio.Event) -> None:
    interval = max(5, int(os.getenv("QUANT_AUTOMATION_INTERVAL_SECONDS", "15")))
    while not stop.is_set():
        try:
            await automation_cycle(pool)
        except Exception:
            log.exception("Automation cycle failed")
            try:
                async with pool.acquire() as conn:
                    await conn.execute("INSERT INTO quant_worker_heartbeat(worker_name,status,details) VALUES('paper-automation','DEGRADED','{}'::jsonb) ON CONFLICT(worker_name) DO UPDATE SET last_seen_at=now(),status='DEGRADED'")
            except Exception:
                pass
        try:
            await asyncio.wait_for(stop.wait(), timeout=interval)
        except asyncio.TimeoutError:
            continue
