import pytest
from app.automation import signal_qualifies


def test_only_directional_signals_over_threshold_qualify():
    assert signal_qualifies("BUY", 0.70, 0.65)
    assert signal_qualifies("SELL", 0.65, 0.65)
    assert not signal_qualifies("BUY", 0.64, 0.65)
    assert not signal_qualifies("NEUTRAL", 0.99, 0.65)


def test_invalid_direction_or_confidence_fails_closed():
    with pytest.raises(ValueError):
        signal_qualifies("CALL", 0.9, 0.6)
    with pytest.raises(ValueError):
        signal_qualifies("BUY", 1.1, 0.6)
    with pytest.raises(ValueError):
        signal_qualifies("BUY", 0.9, -0.1)
