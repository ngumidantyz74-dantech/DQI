# DQI Phase 5–6 Acceptance Summary

## Phase 5
- [x] PostgreSQL scheduler control, kill switch, strategy run ledger, alerts and heartbeat schema.
- [x] Paper-only automated signal evaluation from Deriv public candles.
- [x] Duplicate candle prevention and scheduler leader lock.
- [x] Per-strategy cooldown and risk policy enforcement.
- [x] Background paper settlement worker.
- [x] Quant UI for scheduler status, strategy creation/toggle, alerts and emergency stop.
- [ ] Full multi-replica integration test against PostgreSQL.
- [ ] Live Deriv feed and restart/failover test in deployment.

## Phase 6
- [x] Separate main API execution control plane.
- [x] Deployment feature flag and independent database kill switch.
- [x] REAL account ownership/environment validation.
- [x] Deriv proposal creation and short-lived approval intent.
- [x] Exact second-stage manual approval phrase.
- [x] Balance, stake ceiling, remaining daily risk budget and concurrent contract checks.
- [x] Deriv authenticated OTP WebSocket purchase flow.
- [x] Ambiguous outcomes marked UNKNOWN without automatic retry.
- [x] Execution event ledger and portfolio reconciliation endpoint.
- [x] Main-site approval interface.
- [ ] Full TypeScript build and Vitest execution in dependency-complete environment.
- [ ] PostgreSQL migration and live broker integration tests.
- [ ] Independent security review and operational sign-off.

## Deployment default
`DQI_LIVE_TRADING_ENABLED=false`; `live_execution_control.live_enabled=false`; `live_execution_control.kill_switch=true`; `automation_enabled=false`; `require_manual_approval=true`.
