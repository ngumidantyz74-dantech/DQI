# DQI Phases 5–6 — Strategy Automation, Reliability and Controlled Live Deployment

## Architecture and separation

The repository remains a single versioned monorepo with separately deployed applications:

- `apps/web`: primary DQI application, Deriv OAuth/account entry point and Phase 6 manual-approval screen.
- `apps/quant-web`: independent Quant Intelligence web application, hosted on its own hostname and protected by its own administrator-configured password.
- `services/quant`: Python quantitative research and paper-only automation service. It does not receive Deriv OAuth access tokens and has no real execution adapter.
- `apps/api`: Node API, OAuth credential vault, account ownership enforcement and isolated live execution control plane.
- PostgreSQL: durable strategy, automation, approval, execution and reconciliation records.

Suggested production DNS:

- `app.example.com` → `apps/web`
- `quant.example.com` → `apps/quant-web`
- API host remains private behind the reverse proxy, with only required HTTPS routes exposed.

The main site links to the separate Quant site. Keep the Quant service and database private; expose the Quant frontend only through HTTPS. The separate Quant administrator password does not replace the main DQI session and Deriv OAuth authorization required by Phase 6.

## Phase 5 — Strategy Automation & Reliability

### Components

- PostgreSQL-backed global paper automation control row.
- Explicit global scheduler enable and independent emergency kill switch.
- Per-strategy `enabled` and `auto_enabled` switches.
- `execution_mode='PAPER'` database constraint; automation queries only PAPER strategies.
- One scheduler leader selected using a PostgreSQL advisory lock.
- Unique strategy/symbol/timeframe/candle-epoch key prevents duplicate processing of a candle.
- Candle-based evaluation from Deriv public history; only BUY/SELL signals meeting the configured raw-score threshold can open a simulated position.
- Per-strategy cooldown, maximum 2% paper-equity stake fraction, daily 5% realized-loss stop, maximum five open positions, and expiry bounds.
- Expired paper positions are settled by a fresh Deriv public tick whose epoch is at or after the expiry boundary.
- Worker heartbeat, alert records, strategy run history, and error isolation.
- Settlement continues while new strategy evaluation is paused; emergency stop prevents new entries, not settlement of already-open virtual positions.

### Quant API endpoints

- `GET /api/v1/automation/status`
- `POST /api/v1/automation/control`
- `POST /api/v1/automation/strategies/{strategy_id}/toggle`
- `POST /api/v1/automation/run-once`
- `GET /api/v1/automation/alerts`
- `POST /api/v1/automation/alerts/{alert_id}/acknowledge`

All endpoints require the Quant administrator session. The scheduler is paused by default. Create/initialize the paper account by visiting the Paper Trading tab before enabling strategies. Strategy automation only creates paper positions and never calls the authenticated Deriv account endpoint.

### Phase 5 migration

`database/migrations/0005_strategy_automation.sql`

## Phase 6 — Controlled Live Deployment

### Execution boundary

Live execution is implemented only in the main Node API. The Quant Python service and its separate browser frontend do not possess Deriv OAuth access tokens and cannot submit real orders.

The flow is deliberately two-stage:

1. The authenticated DQI session selects an owned REAL Deriv Options account and requests a Deriv price proposal.
2. DQI stores a short-lived `PENDING_APPROVAL` intent. No contract has been bought.
3. The operator reviews the instrument, contract, stake, quote and expiry.
4. The operator submits the exact confirmation phrase `I AUTHORIZE THIS REAL TRADE`.
5. The API locks the intent and global control row, checks the deployment flag, kill switch, account ownership/environment, quote expiry, max stake, open-contract limit and daily risk budget.
6. The API fetches a fresh one-time OTP, connects to the REAL account WebSocket, checks the live balance and submits the Deriv `buy` request using the proposal ID and maximum quoted price.
7. The broker contract ID and transaction ID are persisted with an audit event.
8. Ambiguous network failures become `UNKNOWN`; DQI does not blindly retry a possibly successful purchase.
9. The operator can reconcile the broker portfolio using `POST /api/v1/live/reconcile`.

### Phase 6 safeguards

- Deployment feature flag `DQI_LIVE_TRADING_ENABLED=false` by default.
- Database `live_enabled=false` and `kill_switch=true` by default.
- Manual approval is mandatory; live automation is forced off.
- Only owned REAL accounts can be used. DEMO accounts are rejected by the live intent route.
- Proposal quotes expire after 30 seconds.
- Stake is limited by both deployment and database ceilings; stake and daily-loss limits are denominated in the selected account currency.
- Daily loss budget is measured against the account's first observed balance for the UTC date; each proposed stake must fit within the remaining daily risk budget.
- Maximum concurrent contracts is capped at five and defaults to one.
- A kill switch prevents any further approval.
- All proposal, approval, purchase, failure and reconciliation events are persisted.
- Unknown purchase outcomes require broker reconciliation before any further manual action.
- No deposits, withdrawals, transfers, wallet operations, MT5 execution, copy trading or strategy-driven unattended real-money execution are included.

### Main API endpoints

- `GET /api/v1/live/control`
- `POST /api/v1/live/control`
- `POST /api/v1/live/kill-switch`
- `POST /api/v1/live/intents`
- `POST /api/v1/live/intents/{intentId}/approve`
- `POST /api/v1/live/intents/{intentId}/reject`
- `GET /api/v1/live/intents`
- `POST /api/v1/live/reconcile`

### Phase 6 migration

`database/migrations/0006_controlled_live_execution.sql`

## Environment configuration

New settings in `.env.example`:

```dotenv
DQI_LIVE_TRADING_ENABLED=false
DQI_LIVE_MAX_STAKE=1
DQI_LIVE_MAX_DAILY_LOSS=5
QUANT_AUTOMATION_INTERVAL_SECONDS=15
```

Keep the live feature flag false during build, migration, integration and demo acceptance. `DQI_LIVE_MAX_STAKE` and `DQI_LIVE_MAX_DAILY_LOSS` are hard deployment ceilings; database settings cannot exceed them.

## Apply migrations

Migrations are ordered and cumulative:

```bash
docker compose config
docker compose up --build -d
docker compose exec api npm run db:migrate
```

Ensure the migration runner applies migrations 0001 through 0006 in order. Back up PostgreSQL before applying these migrations to a database with existing user data.

## Controlled live enablement

Do not enable the deployment flag until the complete acceptance checklist is passed. If and only if live execution is deliberately authorized by the account owner/operator:

1. Configure `DQI_LIVE_TRADING_ENABLED=true` in the secret-managed deployment environment, keeping the stake and daily loss ceilings conservative.
2. Restart/redeploy the API.
3. From an authenticated main DQI session, call `POST /api/v1/live/control` with:

```json
{
  "liveEnabled": true,
  "killSwitch": false,
  "maxStake": 1,
  "maxDailyLoss": 5,
  "confirmation": "ENABLE CONTROLLED LIVE TRADING"
}
```

4. Verify the gate using `GET /api/v1/live/control`.
5. Create a proposal first. Review the exact quoted values and expiry. Only then use the second approval phrase to authorize the purchase.
6. Test the kill switch immediately after the controlled acceptance test.

The API's deployment flag and database control are independent gates. Both must be enabled. Setting the environment variable alone does not enable trading.

## Acceptance checklist before production

### Required technical verification

- Apply migrations 0001–0006 to a disposable PostgreSQL database and verify all constraints/indexes.
- Install dependencies from lockfiles and run full API `npm run build` and `npm test`.
- Run Python `pytest -q` and Python static/type checks.
- Build all Docker images and inspect the final Compose configuration.
- Verify TLS, reverse-proxy routing, cookie SameSite/Secure behavior, CSRF protections, CORS allowlists, secret-manager injection, log redaction and backup/restore.
- Test Deriv OAuth, demo account discovery, balance, public symbols, history and reconnect behavior.
- Test paper scheduler failover with multiple quant service replicas, duplicate candle delivery, process restart, database outage, Deriv outage, expired OTP and worker heartbeat expiry.
- Test that the paper worker cannot import or reach live credential storage or authenticated trading WebSockets.
- Test live proposal and purchase only on a Deriv DEMO account in a separate test harness; production live endpoint still requires REAL account classification and deployment gate.
- Test explicit manual approval, stale proposal, duplicate approval, insufficient balance, account ownership mismatch, demo-vs-real mismatch, daily loss stop, stake ceiling, open-contract ceiling, emergency stop and ambiguous WebSocket timeout.
- Verify reconciliation against Deriv portfolio and open-contract responses.
- Perform a restore drill and incident-response/kill-switch drill.

### Strategy promotion gates

- No look-ahead leakage in historical tests.
- Fees, payout, slippage and quote timing assumptions are documented and stress-tested.
- Walk-forward and holdout validation completed on data not used for fitting.
- Positive out-of-sample expectancy after realistic costs; confidence intervals and sample size reported.
- Calibration is evaluated on independent outcomes using Brier score and reliability bins.
- Paper operation is stable over a pre-agreed observation period and enough independent trades.
- Demo broker contract proposals and settlements reconcile with actual Deriv behavior.
- No strategy is promoted solely because of win rate or in-sample return.

## Known limitations and operational warnings

- Phase 5 paper options settlement remains a simplified directional fixed-payout model. It is not a broker quote/settlement replica.
- Phase 6 supports the Deriv Options WebSocket contract types enumerated in the API schema, not MT5 or Deriv Wallet products.
- Daily risk baselines are initialized on the first approved DQI live trade of each UTC date. External deposits/withdrawals or activity outside DQI can affect this balance-based control and should be reconciled operationally.
- `UNKNOWN` execution intents are intentionally not retried. Reconcile with Deriv and inspect broker transaction history before taking further action.
- The implementation has not been certified by Deriv, independently audited, or verified against live credentials in this development environment.
- No strategy, signal or bot can guarantee profit or prevent losses.
